# ---------------------------------------------------------------- Room
-keep class androidx.room.** { *; }
-keep @androidx.room.Entity class * { *; }
-dontwarn androidx.room.paging.**

# Entity ها، مدل‌های دامنه و انواع رمزشده
# (نام فیلدها نباید عوض شود چون Room و مبدل‌ها به آن‌ها تکیه می‌کنند)
-keep class com.ninjatech.oiltrading.data.entity.** { *; }
-keep class com.ninjatech.oiltrading.data.crypto.** { *; }
-keep class com.ninjatech.oiltrading.domain.** { *; }

# مبدل‌های TypeConverter با انعکاس ساخته می‌شوند
-keep class com.ninjatech.oiltrading.data.db.CryptoConverters { *; }
-keep class com.ninjatech.oiltrading.data.db.** { *; }

# ---------------------------------------------------------------- WorkManager
# Worker ها با نام کلاس و از طریق انعکاس ساخته می‌شوند
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
-keep class com.ninjatech.oiltrading.alerts.** { *; }

# ---------------------------------------------------------------- Kotlin
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
