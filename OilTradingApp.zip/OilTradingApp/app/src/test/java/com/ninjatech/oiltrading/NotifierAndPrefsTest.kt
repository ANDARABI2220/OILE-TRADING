package com.ninjatech.oiltrading

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.ninjatech.oiltrading.alerts.TradeNotifier
import com.ninjatech.oiltrading.data.entity.TradeAlert
import com.ninjatech.oiltrading.data.entity.TradeKind
import com.ninjatech.oiltrading.util.AppPrefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

/** اعلان‌رسان واقعی و تنظیمات کاربر */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class NotifierAndPrefsTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    private fun alert(
        id: Long = 1,
        kind: TradeKind = TradeKind.PURCHASE,
        dueDate: Long
    ) = TradeAlert(
        id = id,
        tradeKind = kind.dbValue,
        tradeId = id,
        dueDate = dueDate,
        counterparty = "حاجی عبدالله",
        amount = 580_000.0,
        currency = "AFN"
    )

    // ---------------------------------------------------------------- اعلان

    @Test
    fun `کانال اعلان هنگام ساخت اعلان‌رسان ایجاد می‌شود`() {
        TradeNotifier(context)

        // از API واقعی خوانده می‌شود، نه از shadow — همان چیزی که اندروید می‌بیند
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
                as android.app.NotificationManager
        assertNotNull(
            "کانال باید ساخته شده باشد",
            manager.getNotificationChannel(TradeNotifier.CHANNEL_ID)
        )
    }

    @Test
    fun `بدون مجوز اعلان ارسال نمی‌شود`() {
        val notifier = TradeNotifier(context)
        // روی اندروید ۱۳ مجوز POST_NOTIFICATIONS به‌صورت پیش‌فرض داده نشده است
        val now = System.currentTimeMillis()

        val sent = notifier.notify(alert(dueDate = now + TimeUnit.DAYS.toMillis(20)), now)

        assertEquals(
            "نتیجهٔ ارسال باید با وضعیت مجوز هم‌خوان باشد",
            notifier.canPostNotifications(),
            sent
        )
    }

    @Test
    fun `با مجوز داده‌شده اعلان ارسال و ثبت می‌شود`() {
        shadowOf(context as android.app.Application)
            .grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)

        val notifier = TradeNotifier(context)
        val now = System.currentTimeMillis()

        val sent = notifier.notify(alert(dueDate = now + TimeUnit.DAYS.toMillis(20)), now)

        assertTrue("با مجوز باید ارسال شود", sent)
        val manager = shadowOf(
            context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        )
        assertEquals(1, manager.size())
    }

    @Test
    fun `متن اعلان برای معاملهٔ عقب‌افتاده فرق می‌کند`() {
        shadowOf(context as android.app.Application)
            .grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)

        val notifier = TradeNotifier(context)
        val now = System.currentTimeMillis()

        // یکی داخل پنجره، یکی از سررسید گذشته
        notifier.notify(alert(id = 1, dueDate = now + TimeUnit.DAYS.toMillis(20)), now)
        notifier.notify(alert(id = 2, dueDate = now - TimeUnit.DAYS.toMillis(5)), now)

        val manager = shadowOf(
            context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        )
        assertEquals("هر هشدار اعلان جدا دارد", 2, manager.size())
    }

    @Test
    fun `اعلان فروش هم ساخته می‌شود`() {
        shadowOf(context as android.app.Application)
            .grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)

        val notifier = TradeNotifier(context)
        val now = System.currentTimeMillis()

        assertTrue(
            notifier.notify(
                alert(kind = TradeKind.SALE, dueDate = now + TimeUnit.DAYS.toMillis(10)),
                now
            )
        )
    }

    // ---------------------------------------------------------------- تنظیمات

    @Test
    fun `مقادیر پیش‌فرض تنظیمات درست است`() {
        val prefs = AppPrefs(context)

        assertEquals(AppPrefs.DEFAULT_LITERS_PER_TON, prefs.litersPerTon, 0.001)
        assertEquals(AppPrefs.DEFAULT_CURRENCY, prefs.currency)
        assertEquals(AppPrefs.DEFAULT_BUSINESS, prefs.businessName)
    }

    @Test
    fun `تنظیمات ذخیره و دوباره خوانده می‌شوند`() {
        val prefs = AppPrefs(context)

        prefs.litersPerTon = 1333.0
        prefs.currency = "USD"
        prefs.businessName = "تجارت‌خانهٔ مزار"

        val reopened = AppPrefs(context)
        assertEquals(1333.0, reopened.litersPerTon, 0.001)
        assertEquals("USD", reopened.currency)
        assertEquals("تجارت‌خانهٔ مزار", reopened.businessName)
    }
}
