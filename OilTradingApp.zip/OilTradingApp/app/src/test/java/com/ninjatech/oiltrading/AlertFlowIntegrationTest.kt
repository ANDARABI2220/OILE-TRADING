package com.ninjatech.oiltrading

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.ninjatech.oiltrading.data.crypto.InMemoryAesEncryptor
import com.ninjatech.oiltrading.data.db.OilDatabase
import com.ninjatech.oiltrading.data.entity.AlertType
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.entity.TradeKind
import com.ninjatech.oiltrading.data.repo.AlertRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository.TradeInput
import com.ninjatech.oiltrading.util.AppPrefs
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

/**
 * تست یکپارچهٔ جریان کامل سیستم هشدار:
 * ثبت معامله → اسکن → ساخت هشدار → ارسال اعلان → جلوگیری از تکرار.
 */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class AlertFlowIntegrationTest {

    private lateinit var db: OilDatabase
    private lateinit var trades: TradeRepository
    private lateinit var alerts: AlertRepository

    private val now = 1_789_000_000_000L
    private fun days(n: Long) = TimeUnit.DAYS.toMillis(n)

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = TestDatabaseFactory.inMemory(context, InMemoryAesEncryptor())
        trades = TradeRepository(
            purchaseDao = db.purchaseDao(),
            saleDao = db.saleDao(),
            assetDao = db.assetDao(),
            alertDao = db.alertDao(),
            prefs = AppPrefs(context)
        )
        alerts = AlertRepository(
            purchaseDao = db.purchaseDao(),
            saleDao = db.saleDao(),
            alertDao = db.alertDao()
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    private suspend fun addPurchase(
        counterparty: String = "حاجی عبدالله",
        followUpDate: Long?,
        total: Double = 580_000.0
    ): Long = trades.addPurchase(
        TradeInput(
            counterparty = counterparty,
            assetId = Asset.DIESEL,
            quantity = 10_000.0,
            unit = OilUnit.LITER,
            pricePerUnit = total / 10_000.0,
            currency = "AFN",
            tradedAt = now - days(60),
            followUpDate = followUpDate,
            referenceNo = "",
            note = ""
        )
    )

    // ---------------------------------------------------------------- ساخت هشدار

    @Test
    fun `معامله‌ای که ۲۸ روز تا سررسیدش مانده هشدار می‌گیرد`() = runTest {
        val tradeId = addPurchase(followUpDate = now + days(28))

        val created = alerts.scanAndCreateAlerts(now)

        assertEquals(1, created.size)
        val alert = created.single()
        assertEquals(TradeKind.PURCHASE.dbValue, alert.tradeKind)
        assertEquals(tradeId, alert.tradeId)
        assertEquals(AlertType.FOLLOW_UP_DUE.dbValue, alert.alertType)
        assertEquals("حاجی عبدالله", alert.counterparty)
        assertEquals(580_000.0, alert.amount, 0.001)
        assertEquals("AFN", alert.currency)
        assertTrue("هشدار تازه نباید اعلان‌شده باشد", alert.isPending)
    }

    @Test
    fun `معامله‌ای که ۲۹ روز تا سررسیدش مانده هنوز هشدار نمی‌گیرد`() = runTest {
        addPurchase(followUpDate = now + days(29))

        assertTrue(alerts.scanAndCreateAlerts(now).isEmpty())
        assertEquals(0, db.alertDao().count())
    }

    @Test
    fun `معامله بدون تاریخ سررسید هرگز هشدار نمی‌گیرد`() = runTest {
        addPurchase(followUpDate = null)

        assertTrue(alerts.scanAndCreateAlerts(now).isEmpty())
    }

    @Test
    fun `فروش هم اگر سررسید داشته باشد هشدار می‌گیرد`() = runTest {
        trades.addSale(
            TradeInput(
                counterparty = "شرکت نفت مزار",
                assetId = Asset.DIESEL,
                quantity = 500.0,
                unit = OilUnit.LITER,
                pricePerUnit = 70.0,
                currency = "AFN",
                tradedAt = now - days(10),
                followUpDate = now + days(20),
                referenceNo = "",
                note = ""
            )
        )

        val created = alerts.scanAndCreateAlerts(now)

        assertEquals(1, created.size)
        assertEquals(TradeKind.SALE.dbValue, created.single().tradeKind)
    }

    // ---------------------------------------------------------------- جلوگیری از تکرار

    @Test
    fun `اجرای دوبارهٔ اسکن هشدار تکراری نمی‌سازد`() = runTest {
        addPurchase(followUpDate = now + days(20))

        assertEquals(1, alerts.scanAndCreateAlerts(now).size)
        assertEquals(0, alerts.scanAndCreateAlerts(now).size)
        assertEquals(0, alerts.scanAndCreateAlerts(now + days(1)).size)

        assertEquals("فقط یک هشدار باید در پایگاه داده باشد", 1, db.alertDao().count())
    }

    @Test
    fun `اسکن‌های پیاپی در طول زمان هم تکراری نمی‌سازند`() = runTest {
        addPurchase(followUpDate = now + days(28))

        // شبیه‌سازی اجرای روزانهٔ سرویس پس‌زمینه در ۳۰ روز
        repeat(30) { day ->
            alerts.scanAndCreateAlerts(now + days(day.toLong()))
        }

        assertEquals(1, db.alertDao().count())
    }

    @Test
    fun `ایندکس یکتا جلوی درج مستقیم تکراری را می‌گیرد`() = runTest {
        val tradeId = addPurchase(followUpDate = now + days(20))
        alerts.scanAndCreateAlerts(now)

        assertEquals(
            1,
            db.alertDao().countFor(TradeKind.PURCHASE.dbValue, tradeId, AlertType.FOLLOW_UP_DUE.dbValue)
        )
    }

    // ---------------------------------------------------------------- ثبت وضعیت اعلان

    @Test
    fun `وضعیت ارسال اعلان در پایگاه داده ثبت می‌شود`() = runTest {
        addPurchase(followUpDate = now + days(20))
        alerts.scanAndCreateAlerts(now)

        val pending = alerts.pendingNotifications()
        assertEquals(1, pending.size)

        alerts.markNotified(pending, now)

        assertTrue("بعد از ارسال نباید چیزی در صف بماند", alerts.pendingNotifications().isEmpty())
        val stored = db.alertDao().findById(pending.single().id)!!
        assertNotNull(stored.notifiedAt)
        assertEquals(now, stored.notifiedAt)
        assertFalse(stored.isPending)
    }

    @Test
    fun `هشدار اعلان‌شده دوباره در صف ارسال قرار نمی‌گیرد`() = runTest {
        addPurchase(followUpDate = now + days(20))
        alerts.scanAndCreateAlerts(now)
        alerts.markNotified(alerts.pendingNotifications(), now)

        // روز بعد سرویس دوباره اجرا می‌شود
        alerts.scanAndCreateAlerts(now + days(1))

        assertTrue(alerts.pendingNotifications().isEmpty())
    }

    // ---------------------------------------------------------------- بستن هشدار

    @Test
    fun `بستن هشدار آن را از فهرست فعال خارج می‌کند`() = runTest {
        addPurchase(followUpDate = now + days(20))
        val alert = alerts.scanAndCreateAlerts(now).single()

        assertEquals(1, alerts.activeAlerts.first().size)

        alerts.acknowledge(alert.id)

        assertTrue(alerts.activeAlerts.first().isEmpty())
        assertEquals("رکورد باید بماند، فقط بسته شود", 1, db.alertDao().count())
    }

    @Test
    fun `بستن همه هیچ هشدار فعالی باقی نمی‌گذارد`() = runTest {
        addPurchase(counterparty = "احمد", followUpDate = now + days(10))
        addPurchase(counterparty = "محمود", followUpDate = now + days(20))
        alerts.scanAndCreateAlerts(now)

        assertEquals(2, alerts.activeAlerts.first().size)

        alerts.acknowledgeAll()

        assertTrue(alerts.activeAlerts.first().isEmpty())
    }

    // ---------------------------------------------------------------- چرخهٔ عمر معامله

    @Test
    fun `حذف معامله هشدارهایش را هم پاک می‌کند`() = runTest {
        val tradeId = addPurchase(followUpDate = now + days(20))
        alerts.scanAndCreateAlerts(now)
        assertEquals(1, db.alertDao().count())

        trades.deletePurchase(db.purchaseDao().findById(tradeId)!!)

        assertEquals("هشدار معاملهٔ حذف‌شده نباید بماند", 0, db.alertDao().count())
    }

    @Test
    fun `تغییر تاریخ سررسید هشدار قدیمی را باطل می‌کند`() = runTest {
        val tradeId = addPurchase(followUpDate = now + days(20))
        alerts.scanAndCreateAlerts(now)
        assertEquals(1, db.alertDao().count())

        // کاربر سررسید را به آینده‌ای دور می‌برد
        trades.updatePurchaseById(
            tradeId,
            TradeInput(
                counterparty = "حاجی عبدالله",
                assetId = Asset.DIESEL,
                quantity = 10_000.0,
                unit = OilUnit.LITER,
                pricePerUnit = 58.0,
                currency = "AFN",
                tradedAt = now - days(60),
                followUpDate = now + days(200),
                referenceNo = "",
                note = ""
            )
        )

        assertEquals("هشدار سررسید قدیمی باید پاک شود", 0, db.alertDao().count())
        assertTrue("سررسید جدید خارج از پنجره است", alerts.scanAndCreateAlerts(now).isEmpty())
    }

    @Test
    fun `معاملهٔ عقب‌افتاده هم هشدار می‌گیرد`() = runTest {
        // دستگاه چند هفته خاموش بوده و سرویس اجرا نشده
        addPurchase(followUpDate = now - days(15))

        val created = alerts.scanAndCreateAlerts(now)

        assertEquals(1, created.size)
    }

    @Test
    fun `چند معاملهٔ سررسیددار هرکدام هشدار جدا می‌گیرند`() = runTest {
        addPurchase(counterparty = "احمد", followUpDate = now + days(5))
        addPurchase(counterparty = "محمود", followUpDate = now + days(15))
        addPurchase(counterparty = "کریم", followUpDate = now + days(25))
        addPurchase(counterparty = "بدون سررسید", followUpDate = null)
        addPurchase(counterparty = "خیلی دور", followUpDate = now + days(120))

        val created = alerts.scanAndCreateAlerts(now)

        assertEquals(3, created.size)
        assertEquals(
            setOf("احمد", "محمود", "کریم"),
            created.map { it.counterparty }.toSet()
        )
    }
}
