package com.ninjatech.oiltrading

import com.ninjatech.oiltrading.data.crypto.Secret
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale
import com.ninjatech.oiltrading.domain.ProfitCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfitCalculatorTest {

    private val day = 24L * 60 * 60 * 1000

    private fun purchase(
        id: Long,
        liters: Double,
        pricePerLiter: Double,
        dayIndex: Long
    ) = Purchase(
        id = id,
        sellerName = Secret("فروشنده $id"),
        quantity = liters,
        unit = OilUnit.LITER.dbValue,
        quantityLiters = liters,
        pricePerUnit = pricePerLiter,
        totalPrice = liters * pricePerLiter,
        tradedAt = dayIndex * day,
        createdAt = dayIndex * day
    )

    private fun sale(
        id: Long,
        liters: Double,
        pricePerLiter: Double,
        dayIndex: Long
    ) = Sale(
        id = id,
        buyerName = Secret("خریدار $id"),
        quantity = liters,
        unit = OilUnit.LITER.dbValue,
        quantityLiters = liters,
        pricePerUnit = pricePerLiter,
        totalPrice = liters * pricePerLiter,
        tradedAt = dayIndex * day,
        createdAt = dayIndex * day
    )

    @Test
    fun `خرید بدون فروش نباید ضرر نشان دهد`() {
        val result = ProfitCalculator.calculate(
            purchases = listOf(purchase(1, 1000.0, 50.0, 1)),
            sales = emptyList()
        )

        assertEquals(0.0, result.summary.totalProfit, 0.001)
        assertEquals(1000.0, result.summary.stockLiters, 0.001)
        assertEquals(50_000.0, result.summary.inventoryValue, 0.001)
        assertEquals(50.0, result.summary.averageCostPerLiter, 0.001)
    }

    @Test
    fun `مفاد یک فروش ساده درست محاسبه می‌شود`() {
        val result = ProfitCalculator.calculate(
            purchases = listOf(purchase(1, 1000.0, 50.0, 1)),
            sales = listOf(sale(1, 400.0, 65.0, 2))
        )

        val saleResult = result.salesWithProfit.single()
        // بهای تمام‌شده = ۴۰۰ × ۵۰ = ۲۰٬۰۰۰ ؛ فروش = ۴۰۰ × ۶۵ = ۲۶٬۰۰۰
        assertEquals(20_000.0, saleResult.costOfGoodsSold, 0.001)
        assertEquals(6_000.0, saleResult.profit, 0.001)
        assertEquals(600.0, result.summary.stockLiters, 0.001)
        assertEquals(30_000.0, result.summary.inventoryValue, 0.001)
    }

    @Test
    fun `میانگین متحرک پس از خرید دوم به‌روز می‌شود`() {
        // ۱۰۰۰ لیتر به ۵۰ + ۱۰۰۰ لیتر به ۷۰ → میانگین ۶۰
        val result = ProfitCalculator.calculate(
            purchases = listOf(
                purchase(1, 1000.0, 50.0, 1),
                purchase(2, 1000.0, 70.0, 2)
            ),
            sales = listOf(sale(1, 500.0, 80.0, 3))
        )

        val saleResult = result.salesWithProfit.single()
        assertEquals(60.0, saleResult.unitCostPerLiter, 0.001)
        assertEquals(30_000.0, saleResult.costOfGoodsSold, 0.001)
        assertEquals(10_000.0, saleResult.profit, 0.001)
        assertEquals(1500.0, result.summary.stockLiters, 0.001)
    }

    @Test
    fun `خرید و فروش در یک روز به ترتیب درست پردازش می‌شوند`() {
        // اگر فروش پیش از خرید پردازش شود، موجودی منفی و مفاد غلط می‌شود.
        val result = ProfitCalculator.calculate(
            purchases = listOf(purchase(1, 500.0, 40.0, 5)),
            sales = listOf(sale(1, 500.0, 55.0, 5))
        )

        val saleResult = result.salesWithProfit.single()
        assertFalse("نباید فروش بیش از موجودی تشخیص داده شود", saleResult.oversold)
        assertEquals(20_000.0, saleResult.costOfGoodsSold, 0.001)
        assertEquals(7_500.0, saleResult.profit, 0.001)
        assertEquals(0.0, result.summary.stockLiters, 0.001)
    }

    @Test
    fun `فروش بیش از موجودی علامت‌گذاری می‌شود`() {
        val result = ProfitCalculator.calculate(
            purchases = listOf(purchase(1, 100.0, 50.0, 1)),
            sales = listOf(sale(1, 300.0, 60.0, 2))
        )

        assertTrue(result.salesWithProfit.single().oversold)
        assertTrue(result.summary.hasOversell)
    }

    @Test
    fun `مفاد کل برابر مجموع مفاد تک‌تک فروش‌هاست`() {
        val result = ProfitCalculator.calculate(
            purchases = listOf(
                purchase(1, 1000.0, 50.0, 1),
                purchase(2, 2000.0, 55.0, 4)
            ),
            sales = listOf(
                sale(1, 400.0, 65.0, 2),
                sale(2, 900.0, 70.0, 5),
                sale(3, 300.0, 62.0, 6)
            )
        )

        val sumOfParts = result.salesWithProfit.sumOf { it.profit }
        assertEquals(sumOfParts, result.summary.totalProfit, 0.001)
    }

    @Test
    fun `معاملات تن و لیتر با هم جمع می‌شوند`() {
        // ۱ تن = ۱۱۹۰ لیتر (نرمال‌سازی هنگام ثبت انجام می‌شود)
        val tonPurchase = Purchase(
            id = 1,
            sellerName = Secret("حیرتان"),
            quantity = 1.0,
            unit = OilUnit.TON.dbValue,
            quantityLiters = 1190.0,
            pricePerUnit = 59_500.0,
            totalPrice = 59_500.0,
            tradedAt = day,
            createdAt = day
        )

        val result = ProfitCalculator.calculate(
            purchases = listOf(tonPurchase, purchase(2, 810.0, 50.0, 2)),
            sales = emptyList()
        )

        assertEquals(2000.0, result.summary.stockLiters, 0.001)
        assertEquals(100_000.0, result.summary.inventoryValue, 0.001)
        assertEquals(50.0, result.summary.averageCostPerLiter, 0.001)
    }

    @Test
    fun `جمع‌بندی طرف‌های حساب درست است`() {
        val purchases = listOf(
            purchase(1, 1000.0, 50.0, 1).copy(sellerName = Secret("احمد")),
            purchase(2, 500.0, 52.0, 2).copy(sellerName = Secret("احمد")),
            purchase(3, 800.0, 51.0, 3).copy(sellerName = Secret("محمود"))
        )

        val sellers = ProfitCalculator.sellerTotals(purchases)
        assertEquals(2, sellers.size)

        val ahmad = sellers.first { it.name == "احمد" }
        assertEquals(2, ahmad.transactionCount)
        assertEquals(1500.0, ahmad.totalLiters, 0.001)
        assertEquals(76_000.0, ahmad.totalAmount, 0.001)

        // مرتب‌سازی نزولی بر اساس مبلغ
        assertEquals("احمد", sellers.first().name)
    }

    @Test
    fun `فروش وقتی انبار خالی است از آخرین قیمت تمام‌شده استفاده می‌کند`() {
        // خرید، سپس فروش کل موجودی، سپس یک فروش دیگر بدون خرید جدید
        val result = ProfitCalculator.calculate(
            purchases = listOf(purchase(1, 1000.0, 50.0, 1)),
            sales = listOf(
                sale(1, 1000.0, 60.0, 2),
                sale(2, 500.0, 60.0, 3)
            )
        )

        val second = result.salesWithProfit.first { it.sale.id == 2L }
        assertEquals("باید آخرین قیمت تمام‌شده مبنا باشد", 50.0, second.unitCostPerLiter, 0.001)
        assertTrue(second.oversold)
        assertEquals(-500.0, result.summary.stockLiters, 0.001)
    }

    @Test
    fun `فروش بدون هیچ خریدی قیمت تمام‌شدهٔ صفر می‌گیرد`() {
        val result = ProfitCalculator.calculate(
            purchases = emptyList(),
            sales = listOf(sale(1, 100.0, 60.0, 1))
        )

        val only = result.salesWithProfit.single()
        assertEquals(0.0, only.costOfGoodsSold, 0.001)
        assertEquals(6_000.0, only.profit, 0.001)
        assertTrue(only.oversold)
    }

    @Test
    fun `بدون هیچ معامله‌ای همهٔ مقادیر صفر است`() {
        val result = ProfitCalculator.calculate(emptyList(), emptyList())

        assertEquals(0.0, result.summary.stockLiters, 0.001)
        assertEquals(0.0, result.summary.totalProfit, 0.001)
        assertEquals(0, result.summary.purchaseCount)
        assertEquals(0, result.summary.saleCount)
        assertFalse(result.summary.hasOversell)
        assertTrue(result.salesWithProfit.isEmpty())
    }

    @Test
    fun `فروش‌ها به ترتیب نزولی تاریخ برمی‌گردند`() {
        val result = ProfitCalculator.calculate(
            purchases = listOf(purchase(1, 5000.0, 50.0, 1)),
            sales = listOf(
                sale(1, 100.0, 60.0, 2),
                sale(2, 100.0, 60.0, 8),
                sale(3, 100.0, 60.0, 5)
            )
        )

        assertEquals(listOf(2L, 3L, 1L), result.salesWithProfit.map { it.sale.id })
    }

    @Test
    fun `جمع‌بندی خریداران مفاد هر طرف حساب را نگه می‌دارد`() {
        val result = ProfitCalculator.calculate(
            purchases = listOf(purchase(1, 2000.0, 50.0, 1)),
            sales = listOf(
                sale(1, 500.0, 70.0, 2).copy(buyerName = Secret("شرکت الف")),
                sale(2, 500.0, 60.0, 3).copy(buyerName = Secret("شرکت الف")),
                sale(3, 300.0, 80.0, 4).copy(buyerName = Secret("شرکت ب"))
            )
        )

        val buyers = ProfitCalculator.buyerTotals(result.salesWithProfit)

        assertEquals(2, buyers.size)
        val alef = buyers.first { it.name == "شرکت الف" }
        assertEquals(2, alef.transactionCount)
        assertEquals(1000.0, alef.totalLiters, 0.001)
        assertEquals(65_000.0, alef.totalAmount, 0.001)
        assertEquals(15_000.0, alef.profit, 0.001)
    }
}
