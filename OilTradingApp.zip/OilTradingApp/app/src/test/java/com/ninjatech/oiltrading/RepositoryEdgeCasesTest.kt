package com.ninjatech.oiltrading

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.ninjatech.oiltrading.data.crypto.InMemoryAesEncryptor
import com.ninjatech.oiltrading.data.db.OilDatabase
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.repo.TradeRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository.TradeInput
import com.ninjatech.oiltrading.util.AppPrefs
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

/** مسیرهای کم‌تر پیموده‌شدهٔ ریپازیتوری: کالاها، بازهٔ زمانی، ویرایش و پاک‌سازی */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class RepositoryEdgeCasesTest {

    private lateinit var context: Context
    private lateinit var db: OilDatabase
    private lateinit var repository: TradeRepository

    private val now = 1_789_000_000_000L
    private fun days(n: Long) = TimeUnit.DAYS.toMillis(n)

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = TestDatabaseFactory.inMemory(context, InMemoryAesEncryptor())
        repository = TradeRepository(
            purchaseDao = db.purchaseDao(),
            saleDao = db.saleDao(),
            assetDao = db.assetDao(),
            alertDao = db.alertDao(),
            prefs = AppPrefs(context)
        )
    }

    @After
    fun tearDown() = db.close()

    private fun input(
        name: String = "طرف حساب",
        assetId: String = Asset.DIESEL,
        quantity: Double = 100.0,
        unit: OilUnit = OilUnit.LITER,
        price: Double = 50.0,
        tradedAt: Long = now,
        followUpDate: Long? = null
    ) = TradeInput(
        counterparty = name,
        assetId = assetId,
        quantity = quantity,
        unit = unit,
        pricePerUnit = price,
        currency = "AFN",
        tradedAt = tradedAt,
        followUpDate = followUpDate,
        referenceNo = "",
        note = ""
    )

    // ---------------------------------------------------------------- کالاها

    @Test
    fun `فهرست کالاها خوانده می‌شود`() = runTest {
        assertEquals(4, repository.allAssets().size)
        assertNotNull(repository.findAsset(Asset.DIESEL))
        assertNull(repository.findAsset("کالای ناموجود"))
    }

    @Test
    fun `کالای جدید ذخیره می‌شود و در معامله قابل استفاده است`() = runTest {
        repository.saveAsset(
            Asset(id = "jet_a1", name = "تیل طیاره", grade = "Jet A-1", litersPerTon = 1250.0)
        )

        assertEquals(5, repository.allAssets().size)
        assertEquals(1250.0, repository.findAsset("jet_a1")!!.litersPerTon, 0.001)

        val id = repository.addPurchase(
            input(assetId = "jet_a1", quantity = 2.0, unit = OilUnit.TON)
        )
        assertEquals(2500.0, db.purchaseDao().findById(id)!!.quantityLiters, 0.001)
    }

    @Test
    fun `فقط کالاهای فعال در جریان نمایش می‌آیند`() = runTest {
        repository.saveAsset(
            Asset(id = "old_fuel", name = "کالای قدیمی", litersPerTon = 1000.0, active = false)
        )

        val active = repository.assets.first()
        assertEquals(4, active.size)
        assertTrue(active.none { it.id == "old_fuel" })
    }

    // ---------------------------------------------------------------- بازهٔ زمانی

    @Test
    fun `فیلتر بازهٔ زمانی فقط معاملات داخل بازه را می‌دهد`() = runTest {
        repository.addPurchase(input(name = "قدیمی", tradedAt = now - days(60)))
        repository.addPurchase(input(name = "داخل بازه", tradedAt = now - days(5)))
        repository.addPurchase(input(name = "جدید", tradedAt = now + days(5)))

        val inRange = repository.purchasesBetween(now - days(10), now).first()

        assertEquals(1, inRange.size)
        assertEquals("داخل بازه", inRange.single().sellerName.value)
    }

    @Test
    fun `بازهٔ زمانی فروش‌ها هم کار می‌کند`() = runTest {
        repository.addSale(input(name = "فروش قدیمی", tradedAt = now - days(60)))
        repository.addSale(input(name = "فروش تازه", tradedAt = now - days(2)))

        val inRange = repository.salesBetween(now - days(10), now).first()

        assertEquals(1, inRange.size)
        assertEquals("فروش تازه", inRange.single().buyerName.value)
    }

    // ---------------------------------------------------------------- ویرایش و حذف

    @Test
    fun `ویرایش فروش مقادیر جدید را ذخیره می‌کند`() = runTest {
        val id = repository.addSale(input(name = "خریدار اول"))

        repository.updateSaleById(
            id,
            input(name = "خریدار دوم", quantity = 200.0, price = 75.0)
        )

        val updated = db.saleDao().findById(id)!!
        assertEquals("خریدار دوم", updated.buyerName.value)
        assertEquals(15_000.0, updated.totalPrice, 0.001)
        assertTrue("زمان ویرایش باید به‌روز شود", updated.updatedAt >= updated.createdAt)
    }

    @Test
    fun `حذف فروش رکورد را پاک می‌کند`() = runTest {
        val id = repository.addSale(input())
        repository.deleteSale(db.saleDao().findById(id)!!)

        assertEquals(0, db.saleDao().count())
    }

    @Test
    fun `ویرایش معاملهٔ ناموجود خطا می‌دهد`() = runTest {
        assertTrue(runCatching { repository.updatePurchaseById(999, input()) }.isFailure)
        assertTrue(runCatching { repository.updateSaleById(999, input()) }.isFailure)
    }

    @Test
    fun `پاک‌سازی کامل همهٔ جدول‌ها را خالی می‌کند`() = runTest {
        repository.addPurchase(input(followUpDate = now + days(10)))
        repository.addSale(input())
        assertEquals(1, db.purchaseDao().count())

        repository.clearAll()

        assertEquals(0, db.purchaseDao().count())
        assertEquals(0, db.saleDao().count())
        assertEquals(0, db.alertDao().count())
        assertEquals("کالاها نباید پاک شوند", 4, repository.allAssets().size)
    }

    // ---------------------------------------------------------------- نام طرف حساب

    @Test
    fun `نام خریداران مرتب و بدون تکرار است`() = runTest {
        repository.addSale(input(name = "محمود"))
        repository.addSale(input(name = "احمد"))
        repository.addSale(input(name = "محمود"))

        assertEquals(listOf("احمد", "محمود"), repository.buyerNames.first())
    }

    @Test
    fun `نام خالی در فهرست پیشنهاد نمی‌آید`() = runTest {
        repository.addPurchase(input(name = "احمد"))
        repository.addPurchase(input(name = "   "))

        assertEquals(listOf("احمد"), repository.sellerNames.first())
    }

    @Test
    fun `فاصلهٔ اضافی نام هنگام ذخیره حذف می‌شود`() = runTest {
        val id = repository.addPurchase(input(name = "  حاجی عبدالله  "))
        assertEquals("حاجی عبدالله", db.purchaseDao().findById(id)!!.sellerName.value)
    }
}
