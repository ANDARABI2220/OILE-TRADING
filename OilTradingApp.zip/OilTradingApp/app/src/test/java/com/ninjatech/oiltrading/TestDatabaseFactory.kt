package com.ninjatech.oiltrading

import android.content.Context
import androidx.room.Room
import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.crypto.InMemoryAesEncryptor
import com.ninjatech.oiltrading.data.db.CryptoConverters
import com.ninjatech.oiltrading.data.db.AssetSeedCallback
import com.ninjatech.oiltrading.data.db.OilDatabase

/**
 * ساخت پایگاه داده برای تست‌های یکپارچه.
 *
 * هر دو سازنده همان مبدل‌ها، همان مهاجرت‌ها و همان callback مقداردهی اولیهٔ
 * نسخهٔ تولید را به کار می‌برند؛ تنها تفاوت، کلید رمزنگاری است که از حافظه
 * می‌آید چون Android Keystore روی JVM وجود ندارد.
 */
object TestDatabaseFactory {

    /**
     * پایگاه دادهٔ درون‌حافظه‌ای — برای تست منطق.
     *
     * همان `AssetSeedCallback` نسخهٔ تولید اضافه می‌شود تا کالاهای پیش‌فرض ساخته
     * شوند و کلید خارجی معاملات معتبر باشد.
     */
    fun inMemory(
        context: Context,
        encryptor: FieldEncryptor = InMemoryAesEncryptor()
    ): OilDatabase =
        Room.inMemoryDatabaseBuilder(context, OilDatabase::class.java)
            .addTypeConverter(CryptoConverters(encryptor))
            .addCallback(AssetSeedCallback)
            .allowMainThreadQueries()
            .build()

    /**
     * پایگاه دادهٔ روی دیسک — برای تست مهاجرت که به فایل واقعی نیاز دارد.
     *
     * مستقیماً سازندهٔ نسخهٔ تولید را صدا می‌زند تا تست هرگز روی پیکربندی
     * موازی اجرا نشود.
     */
    fun onDisk(
        context: Context,
        name: String,
        encryptor: FieldEncryptor
    ): OilDatabase = OilDatabase.build(context, encryptor, name)

    /** اسکیمای نسخهٔ ۱ — برای ساختن پایگاه دادهٔ قدیمی در تست مهاجرت */
    val V1_SCHEMA: List<String> = listOf(
        """
        CREATE TABLE IF NOT EXISTS `purchases` (
            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            `seller_name` TEXT NOT NULL,
            `quantity` REAL NOT NULL,
            `unit` TEXT NOT NULL,
            `quantity_liters` REAL NOT NULL,
            `price_per_unit` REAL NOT NULL,
            `total_price` REAL NOT NULL,
            `purchase_date` INTEGER NOT NULL,
            `note` TEXT NOT NULL,
            `created_at` INTEGER NOT NULL
        )
        """.trimIndent(),
        "CREATE INDEX IF NOT EXISTS `index_purchases_purchase_date` ON `purchases` (`purchase_date`)",
        "CREATE INDEX IF NOT EXISTS `index_purchases_seller_name` ON `purchases` (`seller_name`)",
        """
        CREATE TABLE IF NOT EXISTS `sales` (
            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            `buyer_name` TEXT NOT NULL,
            `quantity` REAL NOT NULL,
            `unit` TEXT NOT NULL,
            `quantity_liters` REAL NOT NULL,
            `price_per_unit` REAL NOT NULL,
            `total_price` REAL NOT NULL,
            `sale_date` INTEGER NOT NULL,
            `note` TEXT NOT NULL,
            `created_at` INTEGER NOT NULL
        )
        """.trimIndent(),
        "CREATE INDEX IF NOT EXISTS `index_sales_sale_date` ON `sales` (`sale_date`)",
        "CREATE INDEX IF NOT EXISTS `index_sales_buyer_name` ON `sales` (`buyer_name`)"
    )
}
