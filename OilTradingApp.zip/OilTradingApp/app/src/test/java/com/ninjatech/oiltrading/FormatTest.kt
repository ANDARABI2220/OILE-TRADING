package com.ninjatech.oiltrading

import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.parseAmountOrNull
import com.ninjatech.oiltrading.util.toLatinDigits
import com.ninjatech.oiltrading.util.toPersianDigits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** قالب‌بندی اعداد، مبالغ و خواندن ورودی کاربر */
class FormatTest {

    // ---------------------------------------------------------------- اعداد

    @Test
    fun `هزارگان جدا می‌شود`() {
        assertEquals("1,000", Format.number(1000.0, persianDigits = false))
        assertEquals("580,000", Format.number(580_000.0, persianDigits = false))
        assertEquals("1,234,567", Format.number(1_234_567.0, persianDigits = false))
        assertEquals("999", Format.number(999.0, persianDigits = false))
    }

    @Test
    fun `صفر همیشه یک رقم است`() {
        assertEquals("0", Format.number(0.0, persianDigits = false))
        assertEquals("۰", Format.number(0.0))
        assertEquals("0", Format.number(0.0, decimals = 3, persianDigits = false))
    }

    @Test
    fun `اعشار اضافی حذف و بقیه گرد می‌شود`() {
        assertEquals("12.5", Format.number(12.5, persianDigits = false))
        assertEquals("12", Format.number(12.0, persianDigits = false))
        assertEquals("12.35", Format.number(12.345, persianDigits = false))
        assertEquals("12", Format.number(12.345, decimals = 0, persianDigits = false))
    }

    @Test
    fun `عدد منفی علامت خود را نگه می‌دارد`() {
        assertEquals("-1,500", Format.number(-1500.0, persianDigits = false))
    }

    @Test
    fun `مقدار نامعتبر خط تیره می‌دهد`() {
        assertEquals("—", Format.number(Double.NaN))
        assertEquals("—", Format.number(Double.POSITIVE_INFINITY))
        assertEquals("—", Format.number(Double.NEGATIVE_INFINITY))
    }

    @Test
    fun `ارقام فارسی به‌صورت پیش‌فرض استفاده می‌شوند`() {
        assertEquals("۱٬۰۰۰".replace("٬", ","), Format.number(1000.0))
    }

    // ---------------------------------------------------------------- مبلغ و درصد

    @Test
    fun `مبلغ با واحد پول نمایش داده می‌شود`() {
        assertEquals("580,000 AFN", Format.money(580_000.0, "AFN", persianDigits = false))
        assertEquals("1,000 افغانی", Format.money(1000.0, "افغانی", persianDigits = false))
    }

    @Test
    fun `مقدار با واحد اندازه‌گیری نمایش داده می‌شود`() {
        assertEquals("10,000 لیتر", Format.quantity(10_000.0, "لیتر", persianDigits = false))
        assertEquals("2.5 تن", Format.quantity(2.5, "تن", persianDigits = false))
    }

    @Test
    fun `درصد یک رقم اعشار دارد`() {
        assertEquals("12.5٪", Format.percent(12.54, persianDigits = false))
        assertEquals("0٪", Format.percent(0.0, persianDigits = false))
    }

    @Test
    fun `مفاد و ضرر علامت‌دار نمایش داده می‌شوند`() {
        assertEquals("+1,000 AFN", Format.signed(1000.0, "AFN", persianDigits = false))
        assertEquals("−1,000 AFN", Format.signed(-1000.0, "AFN", persianDigits = false))
        assertEquals("0 AFN", Format.signed(0.0, "AFN", persianDigits = false))
    }

    // ---------------------------------------------------------------- ورودی کاربر

    @Test
    fun `عدد لاتین ساده خوانده می‌شود`() {
        assertEquals(1000.0, "1000".parseAmountOrNull()!!, 0.001)
        assertEquals(12.5, "12.5".parseAmountOrNull()!!, 0.001)
    }

    @Test
    fun `ارقام فارسی و عربی خوانده می‌شوند`() {
        assertEquals(1405.0, "۱۴۰۵".parseAmountOrNull()!!, 0.001)
        assertEquals(12345.0, "١٢٣٤٥".parseAmountOrNull()!!, 0.001)
    }

    @Test
    fun `جداکنندهٔ هزارگان و فاصله تحمل می‌شود`() {
        assertEquals(580000.0, "580,000".parseAmountOrNull()!!, 0.001)
        assertEquals(580000.0, "۵۸۰٬۰۰۰".parseAmountOrNull()!!, 0.001)
        assertEquals(1000.0, " 1 000 ".parseAmountOrNull()!!, 0.001)
    }

    @Test
    fun `ورودی نامعتبر null می‌دهد`() {
        assertNull("".parseAmountOrNull())
        assertNull("   ".parseAmountOrNull())
        assertNull("سلام".parseAmountOrNull())
        assertNull("12.5.5".parseAmountOrNull())
    }

    @Test
    fun `تبدیل ارقام رفت و برگشتی است`() {
        val latin = "0123456789"
        assertEquals("۰۱۲۳۴۵۶۷۸۹", latin.toPersianDigits())
        assertEquals(latin, latin.toPersianDigits().toLatinDigits())
    }

    @Test
    fun `حروف غیرعددی دست‌نخورده می‌مانند`() {
        assertEquals("سال ۱۴۰۵", "سال 1405".toPersianDigits())
        assertEquals("A-1024", "A-1024".toLatinDigits())
    }
}
