package com.ninjatech.oiltrading

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.crypto.InMemoryAesEncryptor
import com.ninjatech.oiltrading.data.db.OilDatabase
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.repo.TradeRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository.TradeInput
import com.ninjatech.oiltrading.util.AppPrefs
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

/**
 * تست یکپارچهٔ ماژول معاملات: از فرم تا پایگاه داده و برگشت.
 *
 * مسیر واقعی برنامه سنجیده می‌شود — Room، مبدل رمزنگاری، کلید خارجی کالا و
 * ریپازیتوری — نه نسخهٔ ساختگی آن‌ها.
 */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class TradeModuleIntegrationTest {

    private lateinit var db: OilDatabase
    private lateinit var repository: TradeRepository
    private lateinit var encryptor: FieldEncryptor

    private val now = System.currentTimeMillis()
    private fun days(n: Long) = TimeUnit.DAYS.toMillis(n)

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        encryptor = InMemoryAesEncryptor()
        db = TestDatabaseFactory.inMemory(context, encryptor)
        repository = TradeRepository(
            purchaseDao = db.purchaseDao(),
            saleDao = db.saleDao(),
            assetDao = db.assetDao(),
            alertDao = db.alertDao(),
            prefs = AppPrefs(context)
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun purchaseInput(
        counterparty: String = "حاجی عبدالله",
        assetId: String = Asset.DIESEL,
        quantity: Double = 10_000.0,
        unit: OilUnit = OilUnit.LITER,
        price: Double = 58.0,
        currency: String = "AFN",
        tradedAt: Long = now,
        followUpDate: Long? = null,
        referenceNo: String = "A-1024",
        note: String = "تحویل در بندر حیرتان"
    ) = TradeInput(
        counterparty, assetId, quantity, unit, price,
        currency, tradedAt, followUpDate, referenceNo, note
    )

    // ---------------------------------------------------------------- ثبت و بازخوانی

    @Test
    fun `همهٔ فیلدهای یک خرید ذخیره و درست بازخوانی می‌شوند`() = runTest {
        val followUp = now + days(40)
        val id = repository.addPurchase(
            purchaseInput(tradedAt = now, followUpDate = followUp)
        )
        assertTrue("شناسهٔ معتبر برنگشت", id > 0)

        val saved = db.purchaseDao().findById(id)!!

        assertEquals("حاجی عبدالله", saved.sellerName.value)
        assertEquals(Asset.DIESEL, saved.assetId)
        assertEquals(10_000.0, saved.quantity, 0.001)
        assertEquals(OilUnit.LITER.dbValue, saved.unit)
        assertEquals(10_000.0, saved.quantityLiters, 0.001)
        assertEquals(58.0, saved.pricePerUnit, 0.001)
        assertEquals(580_000.0, saved.totalPrice, 0.001)
        assertEquals("AFN", saved.currency)
        assertEquals(now, saved.tradedAt)
        assertEquals(followUp, saved.followUpDate)
        assertEquals("A-1024", saved.referenceNo.value)
        assertEquals("تحویل در بندر حیرتان", saved.note.value)
        assertTrue(saved.createdAt > 0)
        assertTrue(saved.updatedAt > 0)
    }

    @Test
    fun `ساعت دقیق معامله حفظ می‌شود`() = runTest {
        // ۱۴:۳۷:۰۰ — نه فقط تاریخ
        val exact = 1_789_000_000_000L
        val id = repository.addPurchase(purchaseInput(tradedAt = exact))

        assertEquals(exact, db.purchaseDao().findById(id)!!.tradedAt)
    }

    @Test
    fun `فیلدهای حساس روی دیسک رمز شده‌اند`() = runTest {
        repository.addPurchase(purchaseInput(counterparty = "حاجی عبدالله", note = "محرمانه"))

        // خواندن مستقیم از SQLite، بدون عبور از مبدل Room
        db.openHelper.readableDatabase
            .query("SELECT seller_name, note, reference_no, total_price FROM purchases")
            .use { cursor ->
                assertTrue(cursor.moveToFirst())
                val rawName = cursor.getString(0)
                val rawNote = cursor.getString(1)
                val rawRef = cursor.getString(2)
                val rawTotal = cursor.getDouble(3)

                assertTrue("نام باید رمز شده باشد", FieldEncryptor.isEncrypted(rawName))
                assertTrue("توضیحات باید رمز شده باشد", FieldEncryptor.isEncrypted(rawNote))
                assertTrue("شمارهٔ سند باید رمز شده باشد", FieldEncryptor.isEncrypted(rawRef))

                assertFalse("متن اصلی نباید روی دیسک دیده شود", rawName.contains("عبدالله"))
                assertFalse(rawNote.contains("محرمانه"))

                // مبالغ عمداً رمز نمی‌شوند تا پایگاه داده بتواند روی آن‌ها کار کند
                assertEquals(580_000.0, rawTotal, 0.001)

                assertEquals("حاجی عبدالله", encryptor.decrypt(rawName))
            }
    }

    @Test
    fun `ویرایش معامله مقادیر جدید را ذخیره می‌کند`() = runTest {
        val id = repository.addPurchase(purchaseInput())

        repository.updatePurchaseById(
            id,
            purchaseInput(
                counterparty = "شرکت سپین غر",
                quantity = 2.0,
                unit = OilUnit.TON,
                price = 70_000.0,
                referenceNo = "B-99",
                note = "ویرایش شد"
            )
        )

        val updated = db.purchaseDao().findById(id)!!
        assertEquals("شرکت سپین غر", updated.sellerName.value)
        assertEquals(OilUnit.TON.dbValue, updated.unit)
        assertEquals(140_000.0, updated.totalPrice, 0.001)
        assertEquals("ویرایش شد", updated.note.value)
    }

    @Test
    fun `حذف معامله رکورد را از پایگاه داده پاک می‌کند`() = runTest {
        val id = repository.addPurchase(purchaseInput())
        val saved = db.purchaseDao().findById(id)!!

        repository.deletePurchase(saved)

        assertNull(db.purchaseDao().findById(id))
        assertEquals(0, db.purchaseDao().count())
    }

    // ---------------------------------------------------------------- کالا و واحد

    @Test
    fun `کالاهای پیش‌فرض هنگام ساخت پایگاه داده ایجاد می‌شوند`() = runTest {
        val assets = db.assetDao().getAll()

        assertEquals(4, assets.size)
        assertNotNull(assets.firstOrNull { it.id == Asset.DIESEL })
        assertNotNull(assets.firstOrNull { it.id == Asset.PETROL })
        assertEquals(1190.0, db.assetDao().findById(Asset.DIESEL)!!.litersPerTon, 0.001)
    }

    @Test
    fun `تبدیل تن به لیتر از چگالی همان کالا استفاده می‌کند`() = runTest {
        val dieselId = repository.addPurchase(
            purchaseInput(assetId = Asset.DIESEL, quantity = 1.0, unit = OilUnit.TON)
        )
        val petrolId = repository.addPurchase(
            purchaseInput(assetId = Asset.PETROL, quantity = 1.0, unit = OilUnit.TON)
        )

        // دیزل چگال‌تر از پترول است، پس یک تن دیزل لیتر کمتری می‌شود
        assertEquals(1190.0, db.purchaseDao().findById(dieselId)!!.quantityLiters, 0.001)
        assertEquals(1333.0, db.purchaseDao().findById(petrolId)!!.quantityLiters, 0.001)
    }

    @Test
    fun `معامله با کالای ناموجود رد می‌شود`() = runTest {
        val failure = runCatching {
            repository.addPurchase(purchaseInput(assetId = "کالای وجود ندارد"))
        }
        assertTrue("کلید خارجی باید جلوی این را بگیرد", failure.isFailure)
    }

    // ---------------------------------------------------------------- جریان‌ها

    @Test
    fun `فهرست نام فروشندگان از مقادیر رمزگشایی‌شده ساخته می‌شود`() = runTest {
        repository.addPurchase(purchaseInput(counterparty = "احمد"))
        repository.addPurchase(purchaseInput(counterparty = "محمود"))
        repository.addPurchase(purchaseInput(counterparty = "احمد"))

        val names = repository.sellerNames.first()

        assertEquals(listOf("احمد", "محمود"), names)
    }

    @Test
    fun `موجودی و مفاد از روی داده‌های ذخیره‌شده درست محاسبه می‌شود`() = runTest {
        repository.addPurchase(
            purchaseInput(quantity = 1000.0, price = 50.0, tradedAt = now - days(5))
        )
        repository.addSale(
            TradeInput(
                counterparty = "شرکت نفت مزار",
                assetId = Asset.DIESEL,
                quantity = 400.0,
                unit = OilUnit.LITER,
                pricePerUnit = 65.0,
                currency = "AFN",
                tradedAt = now - days(2),
                followUpDate = null,
                referenceNo = "",
                note = ""
            )
        )

        val result = repository.calculation.first()

        assertEquals(600.0, result.summary.stockLiters, 0.001)
        assertEquals(6_000.0, result.summary.totalProfit, 0.001)
        assertEquals(1, result.salesWithProfit.size)
        assertEquals(20_000.0, result.salesWithProfit.single().costOfGoodsSold, 0.001)
    }

    @Test
    fun `فروش هم ذخیره و هم رمز می‌شود`() = runTest {
        val id = repository.addSale(
            TradeInput(
                counterparty = "شرکت نفت مزار",
                assetId = Asset.DIESEL,
                quantity = 500.0,
                unit = OilUnit.LITER,
                pricePerUnit = 70.0,
                currency = "USD",
                tradedAt = now,
                followUpDate = now + days(30),
                referenceNo = "S-77",
                note = "پرداخت نقدی"
            )
        )

        val saved = db.saleDao().findById(id)!!
        assertEquals("شرکت نفت مزار", saved.buyerName.value)
        assertEquals("USD", saved.currency)
        assertEquals(35_000.0, saved.totalPrice, 0.001)
        assertEquals("S-77", saved.referenceNo.value)

        db.openHelper.readableDatabase.query("SELECT buyer_name FROM sales").use { cursor ->
            assertTrue(cursor.moveToFirst())
            assertTrue(FieldEncryptor.isEncrypted(cursor.getString(0)))
        }
    }
}
