package com.ninjatech.oiltrading

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import com.ninjatech.oiltrading.alerts.AlertNotifier
import com.ninjatech.oiltrading.alerts.FollowUpWorker
import com.ninjatech.oiltrading.data.crypto.InMemoryAesEncryptor
import com.ninjatech.oiltrading.data.db.OilDatabase
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.entity.TradeAlert
import com.ninjatech.oiltrading.data.repo.AlertRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository.TradeInput
import com.ninjatech.oiltrading.util.AppPrefs
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

/**
 * تست یکپارچهٔ سرویس پس‌زمینه — از اجرای Worker تا ثبت وضعیت اعلان.
 *
 * سرویس واقعی اجرا می‌شود (نه شبیه‌سازی منطقش)؛ فقط اعلان‌رسان ساختگی است
 * تا بتوان شمرد چند اعلان و برای کدام هشدار فرستاده شده.
 */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class FollowUpWorkerIntegrationTest {

    /** اعلان‌رسان ساختگی که فقط ثبت می‌کند چه چیزی فرستاده شده */
    private class RecordingNotifier(
        private val allowed: Boolean = true
    ) : AlertNotifier {
        val sent = mutableListOf<TradeAlert>()
        override fun canPostNotifications(): Boolean = allowed
        override fun notify(alert: TradeAlert, now: Long): Boolean {
            if (!allowed) return false
            sent += alert
            return true
        }
    }

    private lateinit var context: Context
    private lateinit var db: OilDatabase
    private lateinit var trades: TradeRepository
    private lateinit var alerts: AlertRepository

    private fun days(n: Long) = TimeUnit.DAYS.toMillis(n)

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = TestDatabaseFactory.inMemory(context, InMemoryAesEncryptor())
        trades = TradeRepository(
            purchaseDao = db.purchaseDao(),
            saleDao = db.saleDao(),
            assetDao = db.assetDao(),
            alertDao = db.alertDao(),
            prefs = AppPrefs(context)
        )
        alerts = AlertRepository(
            purchaseDao = db.purchaseDao(),
            saleDao = db.saleDao(),
            alertDao = db.alertDao()
        )
    }

    @After
    fun tearDown() {
        FollowUpWorker.resetDependencyProvider()
        db.close()
    }

    private fun runWorker(notifier: AlertNotifier): ListenableWorker.Result {
        FollowUpWorker.dependencyProvider = { FollowUpWorker.Dependencies(alerts, notifier) }
        val worker = TestListenableWorkerBuilder<FollowUpWorker>(context).build()
        return runBlocking { worker.doWork() }
    }

    /** خریدی که سررسیدش داخل پنجرهٔ هشدار است */
    private suspend fun addDuePurchase(name: String = "حاجی عبدالله", inDays: Long = 20) {
        trades.addPurchase(
            TradeInput(
                counterparty = name,
                assetId = Asset.DIESEL,
                quantity = 10_000.0,
                unit = OilUnit.LITER,
                pricePerUnit = 58.0,
                currency = "AFN",
                tradedAt = System.currentTimeMillis() - days(30),
                followUpDate = System.currentTimeMillis() + days(inDays),
                referenceNo = "",
                note = ""
            )
        )
    }

    // ----------------------------------------------------------------

    @Test
    fun `سرویس هشدار می‌سازد و اعلان می‌فرستد`() = runTest {
        addDuePurchase()
        val notifier = RecordingNotifier()

        val result = runWorker(notifier)

        assertTrue(result is ListenableWorker.Result.Success)
        val output = (result as ListenableWorker.Result.Success).outputData
        assertEquals(1, output.getInt(FollowUpWorker.KEY_CREATED, -1))
        assertEquals(1, output.getInt(FollowUpWorker.KEY_NOTIFIED, -1))

        assertEquals(1, notifier.sent.size)
        assertEquals("حاجی عبدالله", notifier.sent.single().counterparty)
    }

    @Test
    fun `اجرای دوبارهٔ سرویس اعلان تکراری نمی‌فرستد`() = runTest {
        addDuePurchase()
        val notifier = RecordingNotifier()

        runWorker(notifier)
        runWorker(notifier)
        runWorker(notifier)

        assertEquals("فقط یک اعلان باید فرستاده شده باشد", 1, notifier.sent.size)
        assertEquals(1, db.alertDao().count())
    }

    @Test
    fun `بدون معاملهٔ سررسیددار هیچ اعلانی فرستاده نمی‌شود`() = runTest {
        trades.addPurchase(
            TradeInput(
                counterparty = "بدون سررسید",
                assetId = Asset.DIESEL,
                quantity = 100.0,
                unit = OilUnit.LITER,
                pricePerUnit = 50.0,
                currency = "AFN",
                tradedAt = System.currentTimeMillis(),
                followUpDate = null,
                referenceNo = "",
                note = ""
            )
        )
        val notifier = RecordingNotifier()

        val result = runWorker(notifier)

        assertTrue(result is ListenableWorker.Result.Success)
        assertTrue(notifier.sent.isEmpty())
        assertEquals(0, db.alertDao().count())
    }

    @Test
    fun `اگر مجوز اعلان نباشد هشدار می‌ماند تا دفعهٔ بعد`() = runTest {
        addDuePurchase()
        val blocked = RecordingNotifier(allowed = false)

        val result = runWorker(blocked)

        assertTrue(result is ListenableWorker.Result.Success)
        assertTrue("هیچ اعلانی نباید فرستاده شود", blocked.sent.isEmpty())

        // هشدار ساخته شده و همچنان منتظر ارسال است — در برنامه دیده می‌شود
        assertEquals(1, db.alertDao().count())
        assertEquals(1, alerts.pendingNotifications().size)

        // بعد از دادن مجوز، اجرای بعدی اعلان را می‌فرستد
        val allowed = RecordingNotifier(allowed = true)
        runWorker(allowed)
        assertEquals(1, allowed.sent.size)
        assertNotNull(db.alertDao().findById(allowed.sent.single().id)!!.notifiedAt)
    }

    @Test
    fun `چند معاملهٔ سررسیددار در یک اجرا پردازش می‌شوند`() = runTest {
        addDuePurchase(name = "احمد", inDays = 3)
        addDuePurchase(name = "محمود", inDays = 15)
        addDuePurchase(name = "کریم", inDays = 27)
        val notifier = RecordingNotifier()

        val result = runWorker(notifier) as ListenableWorker.Result.Success

        assertEquals(3, result.outputData.getInt(FollowUpWorker.KEY_CREATED, -1))
        assertEquals(3, notifier.sent.size)
    }

    @Test
    fun `خطای پایگاه داده باعث تلاش دوباره می‌شود نه شکست`() = runTest {
        // یک DAO که خطا می‌دهد؛ بستن پایگاه دادهٔ درون‌حافظه‌ای کافی نیست
        // چون Room آن را دوباره (و خالی) باز می‌کند.
        val failing = AlertRepository(
            purchaseDao = ThrowingPurchaseDao(),
            saleDao = db.saleDao(),
            alertDao = db.alertDao()
        )
        FollowUpWorker.dependencyProvider = {
            FollowUpWorker.Dependencies(failing, RecordingNotifier())
        }
        val worker = TestListenableWorkerBuilder<FollowUpWorker>(context).build()

        val result = runBlocking { worker.doWork() }

        assertTrue(
            "سرویس باید دوباره تلاش کند، نه اینکه بی‌سروصدا شکست بخورد",
            result is ListenableWorker.Result.Retry
        )
    }

    @Test
    fun `بعد از چند تلاش ناموفق سرویس تسلیم می‌شود`() = runTest {
        val failing = AlertRepository(
            purchaseDao = ThrowingPurchaseDao(),
            saleDao = db.saleDao(),
            alertDao = db.alertDao()
        )
        FollowUpWorker.dependencyProvider = {
            FollowUpWorker.Dependencies(failing, RecordingNotifier())
        }
        // تلاش چهارم — از سقف گذشته است
        val worker = TestListenableWorkerBuilder<FollowUpWorker>(context)
            .setRunAttemptCount(3)
            .build()

        val result = runBlocking { worker.doWork() }

        assertTrue(
            "نباید برای همیشه تلاش کند",
            result is ListenableWorker.Result.Failure
        )
    }

    @Test
    fun `سرویس بدون وابستگی بی‌سروصدا موفق برمی‌گردد`() = runTest {
        FollowUpWorker.dependencyProvider = { null }
        val worker = TestListenableWorkerBuilder<FollowUpWorker>(context).build()

        val result = runBlocking { worker.doWork() }

        assertTrue(result is ListenableWorker.Result.Success)
    }

    @Test
    fun `پیکربندی زمان‌بندی دوره‌ای درست است`() {
        assertEquals("بررسی باید روزانه باشد", 24L, FollowUpWorker.REPEAT_INTERVAL_HOURS)
        assertEquals("follow_up_periodic_scan", FollowUpWorker.PERIODIC_WORK_NAME)
        assertEquals("follow_up_immediate_scan", FollowUpWorker.ONE_SHOT_WORK_NAME)
    }
}

/**
 * DAO ای که هر پرس‌وجو را با خطا رد می‌کند — برای سنجیدن مسیر خطای سرویس.
 *
 * عمداً پیاده‌سازی کامل نوشته شده تا اگر روزی متدی به [PurchaseDao] اضافه شود،
 * کامپایلر اینجا هم به ما یادآوری کند.
 */
private class ThrowingPurchaseDao : com.ninjatech.oiltrading.data.dao.PurchaseDao {

    private fun boom(): Nothing = throw IllegalStateException("پایگاه داده در دسترس نیست")

    override suspend fun insert(purchase: com.ninjatech.oiltrading.data.entity.Purchase): Long = boom()
    override suspend fun update(purchase: com.ninjatech.oiltrading.data.entity.Purchase) = boom()
    override suspend fun delete(purchase: com.ninjatech.oiltrading.data.entity.Purchase) = boom()
    override fun observeAll() = boom()
    override fun observeChronological() = boom()
    override suspend fun findById(id: Long) = boom()
    override fun observeBetween(from: Long, to: Long) = boom()
    override suspend fun findDueForFollowUp(from: Long, to: Long, alertType: String) = boom()
    override suspend fun count(): Int = boom()
    override suspend fun deleteAll() = boom()
}
