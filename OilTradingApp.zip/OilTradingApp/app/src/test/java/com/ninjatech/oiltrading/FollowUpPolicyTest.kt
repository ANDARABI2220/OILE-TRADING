package com.ninjatech.oiltrading

import com.ninjatech.oiltrading.domain.FollowUpPolicy
import com.ninjatech.oiltrading.domain.TradeType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

/** قاعدهٔ «۲۸ روز تا سررسید» — هستهٔ زمان‌بندی سیستم هشدار */
class FollowUpPolicyTest {

    private val now = 1_700_000_000_000L
    private fun days(n: Long) = TimeUnit.DAYS.toMillis(n)

    @Test
    fun `پنجرهٔ هشدار دقیقاً ۲۸ روز است`() {
        assertEquals(28L, FollowUpPolicy.ALERT_WINDOW_DAYS)
        assertEquals(days(28), FollowUpPolicy.windowMillis)
    }

    @Test
    fun `سررسید دقیقاً ۲۸ روز بعد هشدار می‌گیرد`() {
        assertTrue(FollowUpPolicy.shouldAlert(now + days(28), now))
    }

    @Test
    fun `سررسید ۲۹ روز بعد هنوز هشدار نمی‌گیرد`() {
        assertFalse(FollowUpPolicy.shouldAlert(now + days(29), now))
    }

    @Test
    fun `سررسید داخل پنجره هشدار می‌گیرد`() {
        listOf(0L, 1L, 7L, 14L, 27L).forEach { d ->
            assertTrue("سررسید $d روز بعد باید هشدار بگیرد",
                FollowUpPolicy.shouldAlert(now + days(d), now))
        }
    }

    @Test
    fun `سررسید خیلی دور هشدار نمی‌گیرد`() {
        listOf(30L, 60L, 180L, 365L).forEach { d ->
            assertFalse("سررسید $d روز بعد نباید هشدار بگیرد",
                FollowUpPolicy.shouldAlert(now + days(d), now))
        }
    }

    @Test
    fun `معاملهٔ عقب‌افتاده داخل مهلت هنوز هشدار می‌گیرد`() {
        // دستگاه خاموش بوده و سرویس اجرا نشده — نباید هشدار برای همیشه از بین برود
        assertTrue(FollowUpPolicy.shouldAlert(now - days(10), now))
        assertTrue(FollowUpPolicy.shouldAlert(now - days(89), now))
    }

    @Test
    fun `معاملهٔ بسیار قدیمی دیگر هشدار نمی‌گیرد`() {
        assertFalse(FollowUpPolicy.shouldAlert(now - days(91), now))
    }

    @Test
    fun `سررسید تعیین‌نشده هرگز هشدار نمی‌گیرد`() {
        assertFalse(FollowUpPolicy.shouldAlert(null, now))
    }

    @Test
    fun `شمارش روز تا سررسید درست است`() {
        assertEquals(28L, FollowUpPolicy.daysUntil(now + days(28), now))
        assertEquals(1L, FollowUpPolicy.daysUntil(now + days(1), now))
        assertEquals(0L, FollowUpPolicy.daysUntil(now, now))
        assertEquals(-5L, FollowUpPolicy.daysUntil(now - days(5), now))
    }

    @Test
    fun `روز جاری به بالا گرد می‌شود نه پایین`() {
        // ۲۷ روز و ۱۲ ساعت باید «۲۸ روز» گزارش شود، نه «۲۷ روز»
        val dueDate = now + days(27) + TimeUnit.HOURS.toMillis(12)
        assertEquals(28L, FollowUpPolicy.daysUntil(dueDate, now))
    }

    @Test
    fun `سررسید پیشنهادی بیرون از پنجرهٔ هشدار است`() {
        // اگر پیشنهاد دقیقاً ۲۸ روز باشد، هشدار همان لحظهٔ ثبت فعال می‌شود
        val suggested = FollowUpPolicy.suggestedFollowUpDate(now)
        assertFalse(
            "سررسید پیشنهادی نباید بلافاصله هشدار بسازد",
            FollowUpPolicy.shouldAlert(suggested, now)
        )
        assertEquals(now + days(56), suggested)
    }

    @Test
    fun `کران‌های پنجره درست محاسبه می‌شوند`() {
        val window = FollowUpPolicy.alertWindow(now)
        assertEquals(now - days(90), window.first)
        assertEquals(now + days(28), window.last)
    }

    @Test
    fun `نوع معامله از مقدار پایگاه داده درست خوانده می‌شود`() {
        assertEquals(TradeType.PURCHASE, TradeType.fromDb("purchase"))
        assertEquals(TradeType.SALE, TradeType.fromDb("sale"))
        assertEquals(TradeType.PURCHASE, TradeType.fromDb("چیز نامعتبر"))
        assertEquals(TradeType.PURCHASE, TradeType.fromDb(null))
    }
}
