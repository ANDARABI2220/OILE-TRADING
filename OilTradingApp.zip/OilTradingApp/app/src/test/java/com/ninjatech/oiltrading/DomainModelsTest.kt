package com.ninjatech.oiltrading

import com.ninjatech.oiltrading.data.crypto.Secret
import com.ninjatech.oiltrading.data.entity.AlertType
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale
import com.ninjatech.oiltrading.data.entity.TradeAlert
import com.ninjatech.oiltrading.data.entity.TradeKind
import com.ninjatech.oiltrading.domain.PartyTotals
import com.ninjatech.oiltrading.domain.SaleWithProfit
import com.ninjatech.oiltrading.domain.TradeSummary
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** محاسبات مشتق‌شده روی مدل‌های دامنه و موجودیت‌ها */
class DomainModelsTest {

    // ---------------------------------------------------------------- TradeSummary

    @Test
    fun `حاشیهٔ مفاد از درآمد فروش محاسبه می‌شود`() {
        val summary = TradeSummary(totalSaleRevenue = 1_000_000.0, totalProfit = 125_000.0)
        assertEquals(12.5, summary.marginPercent, 0.001)
    }

    @Test
    fun `بدون فروش حاشیهٔ مفاد صفر است نه تقسیم بر صفر`() {
        assertEquals(0.0, TradeSummary().marginPercent, 0.001)
    }

    @Test
    fun `موجودی به تن با ضریب داده‌شده تبدیل می‌شود`() {
        val summary = TradeSummary(stockLiters = 2380.0)
        assertEquals(2.0, summary.stockInTons(1190.0), 0.001)
    }

    @Test
    fun `ضریب صفر باعث تقسیم بر صفر نمی‌شود`() {
        val summary = TradeSummary(stockLiters = 1000.0)
        assertEquals(0.0, summary.stockInTons(0.0), 0.001)
        assertEquals(0.0, summary.stockInTons(-5.0), 0.001)
    }

    // ---------------------------------------------------------------- SaleWithProfit

    private fun sale(total: Double) = Sale(
        id = 1,
        buyerName = Secret("خریدار"),
        quantity = 100.0,
        unit = OilUnit.LITER.dbValue,
        quantityLiters = 100.0,
        pricePerUnit = total / 100.0,
        totalPrice = total,
        tradedAt = 0L
    )

    @Test
    fun `حاشیهٔ مفاد هر فروش درست است`() {
        val item = SaleWithProfit(
            sale = sale(100_000.0),
            costOfGoodsSold = 80_000.0,
            profit = 20_000.0,
            unitCostPerLiter = 800.0,
            oversold = false
        )
        assertEquals(20.0, item.marginPercent, 0.001)
    }

    @Test
    fun `فروش با مبلغ صفر حاشیهٔ صفر می‌دهد`() {
        val item = SaleWithProfit(sale(0.0), 0.0, 0.0, 0.0, false)
        assertEquals(0.0, item.marginPercent, 0.001)
    }

    @Test
    fun `ضرر حاشیهٔ منفی می‌دهد`() {
        val item = SaleWithProfit(sale(100_000.0), 120_000.0, -20_000.0, 1200.0, false)
        assertEquals(-20.0, item.marginPercent, 0.001)
    }

    // ---------------------------------------------------------------- Asset

    @Test
    fun `کالاهای پیش‌فرض شناسهٔ یکتا و چگالی معتبر دارند`() {
        val defaults = Asset.defaults()

        assertEquals(4, defaults.size)
        assertEquals(defaults.size, defaults.map { it.id }.toSet().size)
        assertTrue("همهٔ کالاها باید ضریب تبدیل مثبت داشته باشند",
            defaults.all { it.litersPerTon > 0 })
        assertTrue(defaults.all { it.active })
    }

    @Test
    fun `نام نمایشی کالا درجه را وقتی هست نشان می‌دهد`() {
        assertEquals("دیزل", Asset(Asset.DIESEL, "دیزل", litersPerTon = 1190.0).displayName)
        assertEquals(
            "دیزل (L-0.2-62)",
            Asset(Asset.DIESEL, "دیزل", grade = "L-0.2-62", litersPerTon = 1190.0).displayName
        )
    }

    @Test
    fun `پترول سبک‌تر از دیزل است`() {
        val byId = Asset.defaults().associateBy { it.id }
        assertTrue(byId[Asset.PETROL]!!.litersPerTon > byId[Asset.DIESEL]!!.litersPerTon)
    }

    // ---------------------------------------------------------------- TradeAlert

    private fun alert(notifiedAt: Long? = null) = TradeAlert(
        id = 7,
        tradeKind = TradeKind.PURCHASE.dbValue,
        tradeId = 3,
        dueDate = 1_000L,
        counterparty = "احمد",
        amount = 500.0,
        currency = "AFN",
        notifiedAt = notifiedAt
    )

    @Test
    fun `هشدار بدون زمان ارسال در انتظار است`() {
        assertTrue(alert().isPending)
        assertFalse(alert(notifiedAt = 123L).isPending)
    }

    @Test
    fun `نوع و گونهٔ هشدار از مقدار متنی خوانده می‌شود`() {
        assertEquals(TradeKind.PURCHASE, alert().kind)
        assertEquals(AlertType.FOLLOW_UP_DUE, alert().type)
    }

    @Test
    fun `مقدار نامعتبر به گونهٔ پیش‌فرض برمی‌گردد`() {
        assertEquals(TradeKind.PURCHASE, TradeKind.fromDb("نامعتبر"))
        assertEquals(TradeKind.PURCHASE, TradeKind.fromDb(null))
        assertEquals(TradeKind.SALE, TradeKind.fromDb("sale"))
        assertEquals(AlertType.FOLLOW_UP_DUE, AlertType.fromDb(null))
        assertEquals(AlertType.FOLLOW_UP_DUE, AlertType.fromDb("follow_up_due"))
    }

    // ---------------------------------------------------------------- OilUnit

    @Test
    fun `واحد از مقدار پایگاه داده و از برچسب خوانده می‌شود`() {
        assertEquals(OilUnit.TON, OilUnit.fromDb("ton"))
        assertEquals(OilUnit.LITER, OilUnit.fromDb("liter"))
        assertEquals(OilUnit.LITER, OilUnit.fromDb("نامعتبر"))
        assertEquals(OilUnit.LITER, OilUnit.fromDb(null))

        assertEquals(OilUnit.TON, OilUnit.fromLabel("تن"))
        assertEquals(OilUnit.LITER, OilUnit.fromLabel("لیتر"))
        assertEquals(OilUnit.LITER, OilUnit.fromLabel(null))
    }

    @Test
    fun `موجودیت معامله واحدش را درست گزارش می‌کند`() {
        val purchase = Purchase(
            sellerName = Secret("احمد"),
            quantity = 1.0,
            unit = OilUnit.TON.dbValue,
            quantityLiters = 1190.0,
            pricePerUnit = 1.0,
            totalPrice = 1.0,
            tradedAt = 0L
        )
        assertEquals(OilUnit.TON, purchase.oilUnit)
        assertEquals(OilUnit.LITER, sale(100.0).oilUnit)
    }

    // ---------------------------------------------------------------- PartyTotals

    @Test
    fun `جمع‌بندی طرف حساب مقادیرش را نگه می‌دارد`() {
        val totals = PartyTotals("احمد", 3, 1500.0, 76_000.0, profit = 4_000.0)
        assertEquals("احمد", totals.name)
        assertEquals(3, totals.transactionCount)
        assertEquals(4_000.0, totals.profit, 0.001)
    }
}
