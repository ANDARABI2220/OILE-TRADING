package com.ninjatech.oiltrading

import com.ninjatech.oiltrading.util.JalaliCalendar
import com.ninjatech.oiltrading.util.JalaliDate
import com.ninjatech.oiltrading.util.toLatinDigits
import com.ninjatech.oiltrading.util.toPersianDigits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class JalaliCalendarTest {

    @Test
    fun `تبدیل میلادی به شمسی برای تاریخ‌های مرجع درست است`() {
        val cases = listOf(
            Triple(2026, 9, 13) to Triple(1405, 6, 22),
            Triple(2026, 3, 21) to Triple(1405, 1, 1),
            Triple(2026, 3, 20) to Triple(1404, 12, 29),
            Triple(2025, 3, 21) to Triple(1404, 1, 1),
            Triple(2024, 3, 20) to Triple(1403, 1, 1),
            Triple(2024, 9, 22) to Triple(1403, 7, 1),
            Triple(1979, 2, 11) to Triple(1357, 11, 22),
            Triple(2000, 1, 1) to Triple(1378, 10, 11),
            Triple(2021, 3, 21) to Triple(1400, 1, 1)
        )

        cases.forEach { (gregorian, expected) ->
            val (gy, gm, gd) = gregorian
            val actual = JalaliCalendar.gregorianToJalali(gy, gm, gd)
            assertEquals(
                "تبدیل $gy/$gm/$gd اشتباه است",
                expected,
                Triple(actual.year, actual.month, actual.day)
            )
        }
    }

    @Test
    fun `تبدیل رفت و برگشت تاریخ را تغییر نمی‌دهد`() {
        for (year in 1395..1415) {
            for (month in 1..12) {
                val lastDay = JalaliCalendar.monthLength(year, month)
                for (day in listOf(1, 15, lastDay)) {
                    val (gy, gm, gd) = JalaliCalendar.jalaliToGregorian(year, month, day)
                    val back = JalaliCalendar.gregorianToJalali(gy, gm, gd)
                    assertEquals(
                        "رفت‌وبرگشت $year/$month/$day شکست خورد",
                        Triple(year, month, day),
                        Triple(back.year, back.month, back.day)
                    )
                }
            }
        }
    }

    @Test
    fun `سال‌های کبیسه درست تشخیص داده می‌شوند`() {
        assertTrue(JalaliCalendar.isLeapYear(1399))
        assertTrue(JalaliCalendar.isLeapYear(1403))
        assertFalse(JalaliCalendar.isLeapYear(1404))
        assertFalse(JalaliCalendar.isLeapYear(1405))
    }

    @Test
    fun `طول ماه‌ها مطابق تقویم شمسی است`() {
        (1..6).forEach { assertEquals(31, JalaliCalendar.monthLength(1404, it)) }
        (7..11).forEach { assertEquals(30, JalaliCalendar.monthLength(1404, it)) }
        assertEquals(29, JalaliCalendar.monthLength(1404, 12))
        assertEquals(30, JalaliCalendar.monthLength(1403, 12))
    }

    @Test
    fun `نام ماه‌های افغانی درست برگردانده می‌شوند`() {
        assertEquals("حمل", JalaliCalendar.monthName(1))
        assertEquals("سنبله", JalaliCalendar.monthName(6))
        assertEquals("حوت", JalaliCalendar.monthName(12))
    }

    @Test
    fun `تبدیل ارقام فارسی و لاتین دوطرفه کار می‌کند`() {
        assertEquals("۱۴۰۵/۰۶/۲۲", "1405/06/22".toPersianDigits())
        assertEquals("1405/06/22", "۱۴۰۵/۰۶/۲۲".toLatinDigits())
        assertEquals("12345", "١٢٣٤٥".toLatinDigits())
    }

    @Test
    fun `قالب‌بندی عددی و بلند تاریخ درست است`() {
        val date = JalaliDate(1405, 6, 22)

        assertEquals("1405/06/22", date.formatNumeric(persianDigits = false))
        assertEquals("۱۴۰۵/۰۶/۲۲", date.formatNumeric())
        assertEquals("22 سنبله 1405", date.formatLong(persianDigits = false))
        assertEquals("۲۲ سنبله ۱۴۰۵", date.formatLong())
        assertEquals("۱۴۰۵/۰۶/۲۲", date.toString())
    }

    @Test
    fun `شمارهٔ روز در سال درست محاسبه می‌شود`() {
        assertEquals(1, JalaliDate(1405, 1, 1).dayOfYear)
        assertEquals(31, JalaliDate(1405, 1, 31).dayOfYear)
        assertEquals(186, JalaliDate(1405, 6, 31).dayOfYear)
        assertEquals(187, JalaliDate(1405, 7, 1).dayOfYear)
        assertEquals(365, JalaliDate(1405, 12, 29).dayOfYear)
    }

    @Test
    fun `تبدیل به timestamp و برگشت همان تاریخ را می‌دهد`() {
        val date = JalaliDate(1405, 6, 22)
        val restored = JalaliCalendar.fromTimestamp(date.toTimestamp())

        assertEquals(date, restored)
    }

    @Test
    fun `امروز تاریخ معتبری برمی‌گرداند`() {
        val today = JalaliCalendar.today()

        assertTrue(today.year in 1390..1450)
        assertTrue(today.month in 1..12)
        assertTrue(today.day in 1..JalaliCalendar.monthLength(today.year, today.month))
    }

    @Test
    fun `نام روز هفته از فهرست معتبر است`() {
        val name = JalaliCalendar.weekDayName(JalaliDate(1405, 6, 22).toTimestamp())
        assertTrue("«$name» باید یکی از روزهای هفته باشد", name in JalaliCalendar.WEEK_DAYS)
    }

    @Test
    fun `هر هفت روز پیاپی نام متفاوت دارند`() {
        val start = JalaliDate(1405, 6, 1).toTimestamp()
        val dayMillis = 24L * 60 * 60 * 1000
        val names = (0..6).map { JalaliCalendar.weekDayName(start + it * dayMillis) }

        assertEquals("هفت روز پیاپی باید هفت نام متفاوت بدهند", 7, names.toSet().size)
    }

    @Test
    fun `سال خارج از محدوده رد می‌شود`() {
        val failure = runCatching { JalaliCalendar.isLeapYear(5000) }
        assertTrue(failure.isFailure)
    }
}
