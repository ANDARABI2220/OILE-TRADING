package com.ninjatech.oiltrading

import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.crypto.InMemoryAesEncryptor
import com.ninjatech.oiltrading.data.crypto.Secret
import com.ninjatech.oiltrading.data.crypto.asSecret
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** رمزنگاری AES-256-GCM فیلدهای حساس */
class FieldEncryptorTest {

    private val encryptor = InMemoryAesEncryptor()

    @Test
    fun `متن رمزشده دوباره به همان متن باز می‌گردد`() {
        listOf(
            "حاجی عبدالله",
            "شرکت نفت مزار شریف",
            "Invoice #A-1024/2026",
            "تحویل در بندر حیرتان — پرداخت نقدی",
            "۱۲۳۴۵"
        ).forEach { plain ->
            val encrypted = encryptor.encrypt(plain)
            assertEquals("رمزگشایی «$plain» اشتباه است", plain, encryptor.decrypt(encrypted))
        }
    }

    @Test
    fun `متن رمزشده شبیه متن اصلی نیست`() {
        val plain = "حاجی عبدالله"
        val encrypted = encryptor.encrypt(plain)

        assertNotEquals(plain, encrypted)
        assertFalse("متن اصلی نباید در خروجی دیده شود", encrypted.contains(plain))
        assertTrue(FieldEncryptor.isEncrypted(encrypted))
    }

    @Test
    fun `رمزنگاری دوبارهٔ یک متن خروجی متفاوت می‌دهد`() {
        // IV تازه در هر عملیات — الزام امنیتی GCM
        val plain = "حاجی عبدالله"
        val first = encryptor.encrypt(plain)
        val second = encryptor.encrypt(plain)

        assertNotEquals("دو بار رمزنگاری نباید خروجی یکسان بدهد", first, second)
        assertEquals(plain, encryptor.decrypt(first))
        assertEquals(plain, encryptor.decrypt(second))
    }

    @Test
    fun `رشتهٔ خالی دست‌نخورده می‌ماند`() {
        assertEquals("", encryptor.encrypt(""))
        assertEquals("", encryptor.decrypt(""))
    }

    @Test
    fun `دادهٔ رمزنشدهٔ قدیمی همان‌طور خوانده می‌شود`() {
        // رکوردهای نسخهٔ ۱ که هنوز مهاجرت نکرده‌اند نباید خراب شوند
        assertEquals("متن ساده", encryptor.decrypt("متن ساده"))
    }

    @Test
    fun `دادهٔ دستکاری‌شده به‌جای کرش مقدار جایگزین می‌دهد`() {
        val encrypted = encryptor.encrypt("حاجی عبدالله")
        val tampered = encrypted.dropLast(4) + "0000"

        assertEquals(FieldEncryptor.FALLBACK, encryptor.decrypt(tampered))
    }

    @Test
    fun `قالب خراب باعث کرش نمی‌شود`() {
        assertEquals(FieldEncryptor.FALLBACK, encryptor.decrypt(FieldEncryptor.PREFIX + "بدون جداکننده"))
        assertEquals(FieldEncryptor.FALLBACK, encryptor.decrypt(FieldEncryptor.PREFIX + ":::"))
    }

    @Test
    fun `کلید دیگر نمی‌تواند داده را باز کند`() {
        val encrypted = encryptor.encrypt("حاجی عبدالله")
        val otherDevice = InMemoryAesEncryptor()

        assertEquals(
            "بدون کلید همان دستگاه نباید قابل خواندن باشد",
            FieldEncryptor.FALLBACK,
            otherDevice.decrypt(encrypted)
        )
    }

    @Test
    fun `Secret مقدارش را حفظ می‌کند`() {
        assertEquals("احمد", "احمد".asSecret().value)
        assertEquals("احمد", Secret("احمد").toString())
        assertEquals(Secret("احمد"), Secret("احمد"))
        assertEquals("", Secret.EMPTY.value)
    }
}
