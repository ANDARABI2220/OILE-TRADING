package com.ninjatech.oiltrading

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.crypto.InMemoryAesEncryptor
import com.ninjatech.oiltrading.data.db.OilDatabase
import com.ninjatech.oiltrading.data.entity.Asset
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

/**
 * مهاجرت نسخهٔ ۱ به ۲ روی یک پایگاه دادهٔ واقعیِ نسخهٔ ۱.
 *
 * مهم‌ترین چیزی که سنجیده می‌شود: **دادهٔ کاربر نباید از بین برود** و
 * مقادیر متن‌سادهٔ قبلی باید رمز شوند.
 */
@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class MigrationV1ToV2Test {

    private val dbName = "migration_test.db"
    private lateinit var context: Context
    private lateinit var encryptor: FieldEncryptor
    private var db: OilDatabase? = null

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        encryptor = InMemoryAesEncryptor()
        context.deleteDatabase(dbName)
    }

    @After
    fun tearDown() {
        db?.close()
        context.deleteDatabase(dbName)
    }

    /** پایگاه دادهٔ نسخهٔ ۱ با داده‌های متن‌ساده می‌سازد */
    private fun createV1Database() {
        val raw = context.openOrCreateDatabase(dbName, Context.MODE_PRIVATE, null)
        raw.beginTransaction()
        try {
            TestDatabaseFactory.V1_SCHEMA.forEach { raw.execSQL(it) }

            raw.execSQL(
                """
                INSERT INTO purchases
                (seller_name, quantity, unit, quantity_liters, price_per_unit,
                 total_price, purchase_date, note, created_at)
                VALUES ('حاجی عبدالله', 10000, 'liter', 10000, 58, 580000,
                        1700000000000, 'تحویل در حیرتان', 1700000000000)
                """.trimIndent()
            )
            raw.execSQL(
                """
                INSERT INTO purchases
                (seller_name, quantity, unit, quantity_liters, price_per_unit,
                 total_price, purchase_date, note, created_at)
                VALUES ('شرکت سپین غر', 2, 'ton', 2380, 70000, 140000,
                        1700100000000, '', 1700100000000)
                """.trimIndent()
            )
            raw.execSQL(
                """
                INSERT INTO sales
                (buyer_name, quantity, unit, quantity_liters, price_per_unit,
                 total_price, sale_date, note, created_at)
                VALUES ('شرکت نفت مزار', 4000, 'liter', 4000, 65, 260000,
                        1700200000000, 'پرداخت نقدی', 1700200000000)
                """.trimIndent()
            )

            raw.execSQL("PRAGMA user_version = 1")
            raw.setTransactionSuccessful()
        } finally {
            raw.endTransaction()
            raw.close()
        }
    }

    private fun openMigrated(): OilDatabase =
        TestDatabaseFactory.onDisk(context, dbName, encryptor).also { db = it }

    // ----------------------------------------------------------------

    @Test
    fun `مهاجرت بدون خطا اجرا می‌شود و داده‌ها می‌مانند`() = runTest {
        createV1Database()

        val migrated = openMigrated()

        assertEquals("هر دو خرید باید بمانند", 2, migrated.purchaseDao().count())
        assertEquals("فروش باید بماند", 1, migrated.saleDao().count())
    }

    @Test
    fun `مقادیر متن‌سادهٔ قدیمی رمز می‌شوند`() = runTest {
        createV1Database()
        val migrated = openMigrated()

        // از دید برنامه همان متن قبلی خوانده می‌شود
        val purchases = migrated.purchaseDao().observeChronological()
        val first = migrated.purchaseDao().findById(1)!!
        assertEquals("حاجی عبدالله", first.sellerName.value)
        assertEquals("تحویل در حیرتان", first.note.value)

        // ولی روی دیسک رمز شده است
        migrated.openHelper.readableDatabase
            .query("SELECT seller_name, note FROM purchases WHERE id = 1")
            .use { cursor ->
                assertTrue(cursor.moveToFirst())
                val rawName = cursor.getString(0)
                assertTrue("نام باید رمز شده باشد", FieldEncryptor.isEncrypted(rawName))
                assertFalse(rawName.contains("عبدالله"))
            }
        assertNotNull(purchases)
    }

    @Test
    fun `مبالغ و تاریخ‌ها دست‌نخورده می‌مانند`() = runTest {
        createV1Database()
        val migrated = openMigrated()

        val first = migrated.purchaseDao().findById(1)!!
        assertEquals(10_000.0, first.quantity, 0.001)
        assertEquals(10_000.0, first.quantityLiters, 0.001)
        assertEquals(58.0, first.pricePerUnit, 0.001)
        assertEquals(580_000.0, first.totalPrice, 0.001)
        assertEquals(1_700_000_000_000L, first.tradedAt)

        val second = migrated.purchaseDao().findById(2)!!
        assertEquals(2.0, second.quantity, 0.001)
        assertEquals(2380.0, second.quantityLiters, 0.001)
        assertEquals("ton", second.unit)
    }

    @Test
    fun `ستون‌های جدید مقدار پیش‌فرض معتبر می‌گیرند`() = runTest {
        createV1Database()
        val migrated = openMigrated()

        val first = migrated.purchaseDao().findById(1)!!
        assertEquals("کالای پیش‌فرض باید دیزل باشد", Asset.DIESEL, first.assetId)
        assertEquals("AFN", first.currency)
        assertNull("سررسید معاملات قدیمی باید خالی بماند", first.followUpDate)
        assertEquals("", first.referenceNo.value)
        assertEquals(first.createdAt, first.updatedAt)
    }

    @Test
    fun `جدول کالاها ساخته و پر می‌شود`() = runTest {
        createV1Database()
        val migrated = openMigrated()

        val assets = migrated.assetDao().getAll()
        assertEquals(4, assets.size)
        assertNotNull(migrated.assetDao().findById(Asset.DIESEL))
    }

    @Test
    fun `جدول هشدارها ساخته می‌شود و خالی است`() = runTest {
        createV1Database()
        val migrated = openMigrated()

        assertEquals(0, migrated.alertDao().count())
    }

    @Test
    fun `فروش هم درست مهاجرت می‌کند`() = runTest {
        createV1Database()
        val migrated = openMigrated()

        val sale = migrated.saleDao().findById(1)!!
        assertEquals("شرکت نفت مزار", sale.buyerName.value)
        assertEquals("پرداخت نقدی", sale.note.value)
        assertEquals(260_000.0, sale.totalPrice, 0.001)
        assertEquals(1_700_200_000_000L, sale.tradedAt)
        assertEquals(Asset.DIESEL, sale.assetId)
    }

    @Test
    fun `بعد از مهاجرت می‌توان معاملهٔ جدید ثبت کرد`() = runTest {
        createV1Database()
        val migrated = openMigrated()

        val id = migrated.purchaseDao().insert(
            migrated.purchaseDao().findById(1)!!.copy(id = 0)
        )

        assertTrue(id > 0)
        assertEquals(3, migrated.purchaseDao().count())
    }

    @Test
    fun `پایگاه دادهٔ نصب تازه بدون مهاجرت هم درست ساخته می‌شود`() = runTest {
        // بدون ساختن نسخهٔ ۱ — مسیر onCreate
        val fresh = openMigrated()

        assertEquals(0, fresh.purchaseDao().count())
        assertEquals(4, fresh.assetDao().getAll().size)
    }
}
