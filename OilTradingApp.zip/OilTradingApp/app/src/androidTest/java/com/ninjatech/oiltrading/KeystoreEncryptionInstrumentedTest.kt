package com.ninjatech.oiltrading

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import com.ninjatech.oiltrading.data.crypto.AndroidKeystoreEncryptor
import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.db.AssetSeedCallback
import com.ninjatech.oiltrading.data.db.CryptoConverters
import com.ninjatech.oiltrading.data.db.OilDatabase
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.repo.AlertRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository.TradeInput
import com.ninjatech.oiltrading.util.AppPrefs
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.TimeUnit

/**
 * تست روی دستگاه/شبیه‌ساز واقعی.
 *
 * تنها چیزی که روی JVM قابل سنجش نیست همین است: [AndroidKeystoreEncryptor]
 * به Android Keystore واقعی نیاز دارد. اینجا تأیید می‌شود که کلید ساخته
 * می‌شود، رمزنگاری کار می‌کند و داده‌های حساس روی دیسکِ دستگاه واقعاً
 * ناخوانا هستند.
 */
@RunWith(AndroidJUnit4::class)
@LargeTest
class KeystoreEncryptionInstrumentedTest {

    private val keyAlias = "oil_trading_test_key"
    private val dbName = "instrumented_test.db"

    private lateinit var encryptor: FieldEncryptor
    private lateinit var db: OilDatabase
    private lateinit var repository: TradeRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        context.deleteDatabase(dbName)

        encryptor = AndroidKeystoreEncryptor(keyAlias)
        db = Room.databaseBuilder(context, OilDatabase::class.java, dbName)
            .addTypeConverter(CryptoConverters(encryptor))
            .addCallback(AssetSeedCallback)
            .build()
        repository = TradeRepository(
            purchaseDao = db.purchaseDao(),
            saleDao = db.saleDao(),
            assetDao = db.assetDao(),
            alertDao = db.alertDao(),
            prefs = AppPrefs(context)
        )
    }

    @After
    fun tearDown() {
        db.close()
        ApplicationProvider.getApplicationContext<android.content.Context>()
            .deleteDatabase(dbName)
    }

    @Test
    fun keystoreEncryptionRoundTripsOnDevice() {
        val plain = "حاجی عبدالله — بندر حیرتان"

        val encrypted = encryptor.encrypt(plain)

        assertTrue("باید با طرح ما رمز شده باشد", FieldEncryptor.isEncrypted(encrypted))
        assertNotEquals(plain, encrypted)
        assertEquals(plain, encryptor.decrypt(encrypted))
    }

    @Test
    fun keystoreProducesFreshIvEachTime() {
        val plain = "حاجی عبدالله"

        assertNotEquals(encryptor.encrypt(plain), encryptor.encrypt(plain))
    }

    @Test
    fun sensitiveFieldsAreUnreadableOnDeviceStorage() = runBlocking {
        repository.addPurchase(
            TradeInput(
                counterparty = "حاجی عبدالله",
                assetId = Asset.DIESEL,
                quantity = 10_000.0,
                unit = OilUnit.LITER,
                pricePerUnit = 58.0,
                currency = "AFN",
                tradedAt = System.currentTimeMillis(),
                followUpDate = null,
                referenceNo = "A-1024",
                note = "محرمانه"
            )
        )

        db.openHelper.readableDatabase
            .query("SELECT seller_name, note, reference_no FROM purchases")
            .use { cursor ->
                assertTrue(cursor.moveToFirst())
                (0..2).forEach { column ->
                    val raw = cursor.getString(column)
                    assertTrue("ستون $column باید رمز شده باشد", FieldEncryptor.isEncrypted(raw))
                }
                assertFalse(cursor.getString(0).contains("عبدالله"))
                assertFalse(cursor.getString(1).contains("محرمانه"))
            }
    }

    @Test
    fun fullAlertFlowWorksOnDevice() = runBlocking {
        val now = System.currentTimeMillis()
        repository.addPurchase(
            TradeInput(
                counterparty = "شرکت سپین غر",
                assetId = Asset.DIESEL,
                quantity = 2.0,
                unit = OilUnit.TON,
                pricePerUnit = 70_000.0,
                currency = "AFN",
                tradedAt = now - TimeUnit.DAYS.toMillis(30),
                followUpDate = now + TimeUnit.DAYS.toMillis(20),
                referenceNo = "",
                note = ""
            )
        )

        val alerts = AlertRepository(db.purchaseDao(), db.saleDao(), db.alertDao())

        val created = alerts.scanAndCreateAlerts(now)
        assertEquals(1, created.size)
        assertEquals("شرکت سپین غر", created.single().counterparty)

        // اجرای دوباره نباید تکراری بسازد
        assertTrue(alerts.scanAndCreateAlerts(now).isEmpty())

        alerts.markNotified(alerts.pendingNotifications(), now)
        assertTrue(alerts.pendingNotifications().isEmpty())
    }

    @Test
    fun tonToLiterUsesAssetDensityOnDevice() = runBlocking {
        val id = repository.addPurchase(
            TradeInput(
                counterparty = "تست",
                assetId = Asset.PETROL,
                quantity = 1.0,
                unit = OilUnit.TON,
                pricePerUnit = 1.0,
                currency = "AFN",
                tradedAt = System.currentTimeMillis(),
                followUpDate = null,
                referenceNo = "",
                note = ""
            )
        )

        assertEquals(1333.0, db.purchaseDao().findById(id)!!.quantityLiters, 0.001)
    }
}
