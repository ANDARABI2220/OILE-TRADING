package com.ninjatech.oiltrading.util

import java.math.BigDecimal
import java.math.RoundingMode

private const val PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
private const val ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"

/** تبدیل ارقام لاتین به فارسی/دری: 1404 → ۱۴۰۴ */
fun String.toPersianDigits(): String = buildString(length) {
    for (ch in this@toPersianDigits) {
        append(if (ch in '0'..'9') PERSIAN_DIGITS[ch - '0'] else ch)
    }
}

/** تبدیل ارقام فارسی/عربی به لاتین — برای خواندن ورودی کاربر */
fun String.toLatinDigits(): String = buildString(length) {
    for (ch in this@toLatinDigits) {
        val pi = PERSIAN_DIGITS.indexOf(ch)
        val ai = ARABIC_DIGITS.indexOf(ch)
        append(
            when {
                pi >= 0 -> '0' + pi
                ai >= 0 -> '0' + ai
                else -> ch
            }
        )
    }
}

/**
 * عددی که کاربر وارد کرده را به [Double] تبدیل می‌کند.
 * ارقام فارسی، کامای جداکنندهٔ هزارگان و فاصله‌ها را تحمل می‌کند.
 */
fun String.parseAmountOrNull(): Double? {
    val cleaned = trim()
        .toLatinDigits()
        .replace(",", "")
        .replace("٬", "")
        .replace("\u200c", "")
        .replace(" ", "")
    if (cleaned.isEmpty()) return null
    return cleaned.toDoubleOrNull()
}

object Format {

    /** جداکردن هزارگان با حداکثر [decimals] رقم اعشار؛ صفرهای انتهایی حذف می‌شوند. */
    fun number(value: Double, decimals: Int = 2, persianDigits: Boolean = true): String {
        if (value.isNaN() || value.isInfinite()) return "—"
        val rounded = BigDecimal(value).setScale(decimals, RoundingMode.HALF_UP).stripTrailingZeros()
        if (rounded.signum() == 0) return if (persianDigits) "۰" else "0"
        val negative = rounded.signum() < 0
        val plain = rounded.abs().toPlainString()

        val intPart = plain.substringBefore('.')
        val fracPart = plain.substringAfter('.', "")

        val grouped = intPart.reversed().chunked(3).joinToString(",").reversed()
        val out = buildString {
            if (negative) append('-')
            append(grouped)
            if (fracPart.isNotEmpty()) {
                append('.')
                append(fracPart)
            }
        }
        return if (persianDigits) out.toPersianDigits() else out
    }

    /** مبلغ همراه با واحد پول، مثلاً «۱۲۵٬۰۰۰ افغانی» */
    fun money(value: Double, currency: String, persianDigits: Boolean = true): String =
        "${number(value, decimals = 2, persianDigits = persianDigits)} $currency"

    /** مقدار همراه با واحد، مثلاً «۱۲٫۵ تن» */
    fun quantity(value: Double, unit: String, persianDigits: Boolean = true): String =
        "${number(value, decimals = 3, persianDigits = persianDigits)} $unit"

    /** درصد، مثلاً «۱۲٫۴٪» */
    fun percent(value: Double, persianDigits: Boolean = true): String =
        "${number(value, decimals = 1, persianDigits = persianDigits)}٪"

    /** علامت + یا − پیش از عدد؛ برای نمایش مفاد/ضرر */
    fun signed(value: Double, currency: String, persianDigits: Boolean = true): String {
        val sign = if (value > 0) "+" else if (value < 0) "−" else ""
        return "$sign${number(kotlin.math.abs(value), 2, persianDigits)} $currency"
    }
}
