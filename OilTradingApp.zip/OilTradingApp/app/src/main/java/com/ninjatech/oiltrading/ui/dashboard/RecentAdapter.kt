package com.ninjatech.oiltrading.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.databinding.ItemRecentBinding
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.JalaliCalendar

/** یک ردیف در فهرست «آخرین معاملات» داشبورد */
data class RecentEntry(
    val id: Long,
    val isPurchase: Boolean,
    val name: String,
    val date: Long,
    val quantity: Double,
    val unitLabel: String,
    val amount: Double
) {
    /** کلید یکتا میان خریدها و فروش‌ها */
    val key: String get() = if (isPurchase) "p$id" else "s$id"
}

class RecentAdapter(
    private val currency: () -> String
) : ListAdapter<RecentEntry, RecentAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRecentBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemRecentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: RecentEntry) = with(binding) {
            val context = root.context

            tvName.text = item.name
            tvAmount.text = Format.money(item.amount, currency())

            ivIcon.setImageResource(
                if (item.isPurchase) R.drawable.ic_purchase else R.drawable.ic_sale
            )
            badge.setBackgroundResource(
                if (item.isPurchase) R.drawable.bg_badge_primary else R.drawable.bg_badge_stock
            )

            val kind = context.getString(
                if (item.isPurchase) R.string.nav_purchases else R.string.nav_sales
            )
            val date = JalaliCalendar.fromTimestamp(item.date).formatLong()
            val quantity = Format.quantity(item.quantity, item.unitLabel)
            tvSubtitle.text = "$kind • $date • $quantity"
        }
    }

    private companion object {
        val DIFF = object : DiffUtil.ItemCallback<RecentEntry>() {
            override fun areItemsTheSame(oldItem: RecentEntry, newItem: RecentEntry) =
                oldItem.key == newItem.key

            override fun areContentsTheSame(oldItem: RecentEntry, newItem: RecentEntry) =
                oldItem == newItem
        }
    }
}
