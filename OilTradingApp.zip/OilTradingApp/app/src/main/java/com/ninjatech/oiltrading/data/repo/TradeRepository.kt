package com.ninjatech.oiltrading.data.repo

import com.ninjatech.oiltrading.data.crypto.Secret
import com.ninjatech.oiltrading.data.dao.AssetDao
import com.ninjatech.oiltrading.data.dao.PurchaseDao
import com.ninjatech.oiltrading.data.dao.SaleDao
import com.ninjatech.oiltrading.data.dao.TradeAlertDao
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale
import com.ninjatech.oiltrading.data.entity.TradeKind
import com.ninjatech.oiltrading.domain.ProfitCalculator
import com.ninjatech.oiltrading.util.AppPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * تنها منبع حقیقت برای داده‌های معاملات.
 *
 * جریان‌های خرید و فروش را با هم ترکیب می‌کند تا موجودی و مفاد همیشه با
 * آخرین وضعیت پایگاه داده هماهنگ باشد.
 *
 * چون نام طرف حساب رمزشده ذخیره می‌شود، گروه‌بندی و فهرست پیشنهاد نام‌ها
 * اینجا و روی مقادیر رمزگشایی‌شده ساخته می‌شود، نه با `SELECT DISTINCT`.
 */
class TradeRepository(
    private val purchaseDao: PurchaseDao,
    private val saleDao: SaleDao,
    private val assetDao: AssetDao,
    private val alertDao: TradeAlertDao,
    private val prefs: AppPrefs
) {

    /** یک معامله در قالب ورودی — مشترک میان ثبت و ویرایش */
    data class TradeInput(
        val counterparty: String,
        val assetId: String,
        val quantity: Double,
        val unit: OilUnit,
        val pricePerUnit: Double,
        val currency: String,
        /** تاریخ و ساعت دقیق انجام معامله */
        val tradedAt: Long,
        val followUpDate: Long?,
        val referenceNo: String,
        val note: String
    )

    // ------------------------------------------------------------ جریان‌ها

    val purchases: Flow<List<Purchase>> = purchaseDao.observeAll()

    val sales: Flow<List<Sale>> = saleDao.observeAll()

    val assets: Flow<List<Asset>> = assetDao.observeActive()

    /** نام فروشندگان قبلی — از مقادیر رمزگشایی‌شده ساخته می‌شود */
    val sellerNames: Flow<List<String>> = purchases.map { list ->
        list.map { it.sellerName.value.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sorted()
    }

    val buyerNames: Flow<List<String>> = sales.map { list ->
        list.map { it.buyerName.value.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sorted()
    }

    /** خلاصهٔ کامل (موجودی، مفاد، ارزش انبار) — محاسبه روی ترد پس‌زمینه */
    val calculation: Flow<ProfitCalculator.Result> = combine(
        purchaseDao.observeChronological(),
        saleDao.observeChronological()
    ) { purchases, sales ->
        ProfitCalculator.calculate(purchases, sales)
    }.flowOn(Dispatchers.Default)

    /** فروش‌ها به‌همراه مفاد هر کدام */
    val salesWithProfit = calculation.map { it.salesWithProfit }

    fun purchasesBetween(from: Long, to: Long): Flow<List<Purchase>> =
        purchaseDao.observeBetween(from, to)

    fun salesBetween(from: Long, to: Long): Flow<List<Sale>> =
        saleDao.observeBetween(from, to)

    // ------------------------------------------------------------ کالاها

    suspend fun allAssets(): List<Asset> = withContext(Dispatchers.IO) { assetDao.getAll() }

    suspend fun findAsset(id: String): Asset? = withContext(Dispatchers.IO) { assetDao.findById(id) }

    suspend fun saveAsset(asset: Asset) = withContext(Dispatchers.IO) { assetDao.upsert(asset) }

    // ------------------------------------------------------------ ثبت خرید

    suspend fun addPurchase(input: TradeInput): Long = withContext(Dispatchers.IO) {
        purchaseDao.insert(
            Purchase(
                sellerName = Secret(input.counterparty.trim()),
                assetId = input.assetId,
                quantity = input.quantity,
                unit = input.unit.dbValue,
                quantityLiters = toLiters(input.quantity, input.unit, input.assetId),
                pricePerUnit = input.pricePerUnit,
                totalPrice = input.quantity * input.pricePerUnit,
                currency = input.currency,
                tradedAt = input.tradedAt,
                followUpDate = input.followUpDate,
                referenceNo = Secret(input.referenceNo.trim()),
                note = Secret(input.note.trim())
            )
        )
    }

    /**
     * ویرایش بر اساس شناسه.
     *
     * اگر تاریخ سررسید عوض شود، هشدارهای قبلی همان معامله پاک می‌شوند تا برای
     * سررسید جدید دوباره هشدار ساخته شود.
     */
    suspend fun updatePurchaseById(id: Long, input: TradeInput) = withContext(Dispatchers.IO) {
        val original = purchaseDao.findById(id)
            ?: throw IllegalStateException("خرید با شناسهٔ $id پیدا نشد")

        purchaseDao.update(
            original.copy(
                sellerName = Secret(input.counterparty.trim()),
                assetId = input.assetId,
                quantity = input.quantity,
                unit = input.unit.dbValue,
                quantityLiters = toLiters(input.quantity, input.unit, input.assetId),
                pricePerUnit = input.pricePerUnit,
                totalPrice = input.quantity * input.pricePerUnit,
                currency = input.currency,
                tradedAt = input.tradedAt,
                followUpDate = input.followUpDate,
                referenceNo = Secret(input.referenceNo.trim()),
                note = Secret(input.note.trim()),
                updatedAt = System.currentTimeMillis()
            )
        )

        if (original.followUpDate != input.followUpDate) {
            alertDao.deleteForTrade(TradeKind.PURCHASE.dbValue, id)
        }
    }

    suspend fun deletePurchase(purchase: Purchase) = withContext(Dispatchers.IO) {
        purchaseDao.delete(purchase)
        alertDao.deleteForTrade(TradeKind.PURCHASE.dbValue, purchase.id)
    }

    // ------------------------------------------------------------ ثبت فروش

    suspend fun addSale(input: TradeInput): Long = withContext(Dispatchers.IO) {
        saleDao.insert(
            Sale(
                buyerName = Secret(input.counterparty.trim()),
                assetId = input.assetId,
                quantity = input.quantity,
                unit = input.unit.dbValue,
                quantityLiters = toLiters(input.quantity, input.unit, input.assetId),
                pricePerUnit = input.pricePerUnit,
                totalPrice = input.quantity * input.pricePerUnit,
                currency = input.currency,
                tradedAt = input.tradedAt,
                followUpDate = input.followUpDate,
                referenceNo = Secret(input.referenceNo.trim()),
                note = Secret(input.note.trim())
            )
        )
    }

    suspend fun updateSaleById(id: Long, input: TradeInput) = withContext(Dispatchers.IO) {
        val original = saleDao.findById(id)
            ?: throw IllegalStateException("فروش با شناسهٔ $id پیدا نشد")

        saleDao.update(
            original.copy(
                buyerName = Secret(input.counterparty.trim()),
                assetId = input.assetId,
                quantity = input.quantity,
                unit = input.unit.dbValue,
                quantityLiters = toLiters(input.quantity, input.unit, input.assetId),
                pricePerUnit = input.pricePerUnit,
                totalPrice = input.quantity * input.pricePerUnit,
                currency = input.currency,
                tradedAt = input.tradedAt,
                followUpDate = input.followUpDate,
                referenceNo = Secret(input.referenceNo.trim()),
                note = Secret(input.note.trim()),
                updatedAt = System.currentTimeMillis()
            )
        )

        if (original.followUpDate != input.followUpDate) {
            alertDao.deleteForTrade(TradeKind.SALE.dbValue, id)
        }
    }

    suspend fun deleteSale(sale: Sale) = withContext(Dispatchers.IO) {
        saleDao.delete(sale)
        alertDao.deleteForTrade(TradeKind.SALE.dbValue, sale.id)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        alertDao.deleteAll()
        purchaseDao.deleteAll()
        saleDao.deleteAll()
    }

    // ------------------------------------------------------------ کمکی

    /**
     * تبدیل مقدار به لیتر.
     *
     * ضریب از خودِ کالا خوانده می‌شود (چگالی هر نوع تیل فرق دارد)؛ اگر کالا
     * پیدا نشد، ضریب عمومیِ تنظیمات به‌عنوان پشتیبان به کار می‌رود.
     */
    private suspend fun toLiters(quantity: Double, unit: OilUnit, assetId: String): Double =
        when (unit) {
            OilUnit.LITER -> quantity
            OilUnit.TON -> quantity * (assetDao.findById(assetId)?.litersPerTon ?: prefs.litersPerTon)
        }
}
