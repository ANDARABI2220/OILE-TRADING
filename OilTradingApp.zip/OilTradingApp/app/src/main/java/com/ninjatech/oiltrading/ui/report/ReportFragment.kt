package com.ninjatech.oiltrading.ui.report

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.ninjatech.oiltrading.OilTradingApplication
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.databinding.FragmentReportBinding
import com.ninjatech.oiltrading.domain.FinancialReport
import com.ninjatech.oiltrading.ui.common.JalaliDatePickerDialog
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModel
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModelFactory
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.JalaliCalendar
import com.ninjatech.oiltrading.util.JalaliDate

/** گزارش مالی بر اساس بازهٔ زمانی، با تفکیک فروشندگان و خریداران */
class ReportFragment : Fragment() {

    private var _binding: FragmentReportBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TradeViewModel by activityViewModels {
        val app = requireActivity().application as OilTradingApplication
        TradeViewModelFactory(app.repository, app.alertRepository, app.prefs)
    }

    private lateinit var sellerAdapter: PartyAdapter
    private lateinit var buyerAdapter: PartyAdapter

    private var customFrom: Long? = null
    private var customTo: Long? = null
    private var latestReport: FinancialReport? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReportBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupLists()
        setupRangeChips()
        setupCustomRangePickers()

        binding.btnShare.setOnClickListener { shareReport() }

        viewModel.report.observe(viewLifecycleOwner) { report ->
            latestReport = report
            render(report)
        }
    }

    private fun setupLists() {
        sellerAdapter = PartyAdapter(currency = { viewModel.currency }, showProfit = false)
        buyerAdapter = PartyAdapter(currency = { viewModel.currency }, showProfit = true)

        binding.rvSellers.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = sellerAdapter
            isNestedScrollingEnabled = false
        }
        binding.rvBuyers.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = buyerAdapter
            isNestedScrollingEnabled = false
        }
    }

    // ---------------------------------------------------------------- بازهٔ زمانی

    private fun setupRangeChips() {
        binding.chipGroupRange.setOnCheckedStateChangeListener { _, checkedIds ->
            when (checkedIds.firstOrNull()) {
                R.id.chipAll -> viewModel.setReportRange(null, null)
                R.id.chipThisMonth -> applyJalaliMonth(monthsBack = 0)
                R.id.chipLastMonth -> applyJalaliMonth(monthsBack = 1)
                R.id.chipCustom -> openCustomRangePicker()
            }
        }
    }

    /** بازهٔ یک ماه شمسی کامل (از روز اول تا روز آخر همان ماه) */
    private fun applyJalaliMonth(monthsBack: Int) {
        val today = JalaliCalendar.today()
        var year = today.year
        var month = today.month - monthsBack
        while (month < 1) {
            month += 12
            year -= 1
        }

        val from = JalaliDate(year, month, 1).toTimestamp()
        val lastDay = JalaliCalendar.monthLength(year, month)
        val to = JalaliDate(year, month, lastDay).toTimestamp() + END_OF_DAY_OFFSET

        viewModel.setReportRange(from, to)
    }

    private fun setupCustomRangePickers() {
        childFragmentManager.setFragmentResultListener(REQUEST_FROM, viewLifecycleOwner) { _, bundle ->
            customFrom = bundle.getLong(JalaliDatePickerDialog.RESULT_TIMESTAMP)
            // بلافاصله تاریخ پایان را بپرس
            JalaliDatePickerDialog.show(
                childFragmentManager,
                customTo ?: System.currentTimeMillis(),
                REQUEST_TO
            )
        }

        childFragmentManager.setFragmentResultListener(REQUEST_TO, viewLifecycleOwner) { _, bundle ->
            customTo = bundle.getLong(JalaliDatePickerDialog.RESULT_TIMESTAMP) + END_OF_DAY_OFFSET
            val from = customFrom
            val to = customTo
            if (from != null && to != null) {
                // اگر کاربر ترتیب را برعکس وارد کرد، خودمان اصلاح می‌کنیم.
                viewModel.setReportRange(minOf(from, to), maxOf(from, to))
            }
        }
    }

    private fun openCustomRangePicker() {
        JalaliDatePickerDialog.show(
            childFragmentManager,
            customFrom ?: System.currentTimeMillis(),
            REQUEST_FROM
        )
    }

    // ---------------------------------------------------------------- نمایش

    private fun render(report: FinancialReport) = with(binding) {
        val currency = viewModel.currency
        val summary = report.summary

        tvReportPurchases.text = Format.money(summary.totalPurchaseCost, currency)
        tvReportSales.text = Format.money(summary.totalSaleRevenue, currency)
        tvReportCogs.text = Format.money(summary.totalCogs, currency)
        tvReportProfit.text = Format.signed(summary.totalProfit, currency)
        tvReportProfit.setTextColor(
            ContextCompat.getColor(
                requireContext(),
                if (summary.totalProfit >= 0) R.color.profit else R.color.loss
            )
        )

        tvReportMeta.text = buildString {
            append(getString(R.string.dashboard_counts,
                Format.number(summary.purchaseCount.toDouble(), 0),
                Format.number(summary.saleCount.toDouble(), 0)))
            append(" • ")
            append(getString(R.string.profit_margin))
            append(" ")
            append(Format.percent(summary.marginPercent))
        }

        tvRangeLabel.text = rangeLabel(report)

        sellerAdapter.submitList(report.topSellers)
        buyerAdapter.submitList(report.topBuyers)

        val isEmpty = report.purchases.isEmpty() && report.salesWithProfit.isEmpty()
        tvReportEmpty.visibility = if (isEmpty) View.VISIBLE else View.GONE
        tvSellersTitle.visibility = if (report.topSellers.isEmpty()) View.GONE else View.VISIBLE
        tvBuyersTitle.visibility = if (report.topBuyers.isEmpty()) View.GONE else View.VISIBLE
        btnShare.isEnabled = !isEmpty
    }

    private fun rangeLabel(report: FinancialReport): String {
        if (binding.chipAll.isChecked) return getString(R.string.report_range_all)
        val from = JalaliCalendar.fromTimestamp(report.fromDate).formatLong()
        val to = JalaliCalendar.fromTimestamp(report.toDate).formatLong()
        return "${getString(R.string.report_from)} $from ${getString(R.string.report_to)} $to"
    }

    // ---------------------------------------------------------------- اشتراک‌گذاری

    /** گزارش را به‌صورت متن ساده برای واتس‌اپ، ایمیل یا هر برنامهٔ دیگری می‌فرستد */
    private fun shareReport() {
        val report = latestReport ?: return
        val currency = viewModel.currency
        val summary = report.summary
        val liter = getString(R.string.unit_liter)

        val text = buildString {
            appendLine(viewModel.businessName)
            appendLine(getString(R.string.report_title))
            appendLine(rangeLabel(report))
            appendLine("──────────────")
            appendLine("${getString(R.string.total_purchase_cost)}: ${Format.money(summary.totalPurchaseCost, currency)}")
            appendLine("${getString(R.string.total_sale_revenue)}: ${Format.money(summary.totalSaleRevenue, currency)}")
            appendLine("${getString(R.string.cost_basis)}: ${Format.money(summary.totalCogs, currency)}")
            appendLine("${getString(R.string.total_profit)}: ${Format.signed(summary.totalProfit, currency)}")
            appendLine("${getString(R.string.current_stock)}: ${Format.quantity(summary.stockLiters, liter)}")
            appendLine("──────────────")

            if (report.topSellers.isNotEmpty()) {
                appendLine(getString(R.string.report_top_sellers))
                report.topSellers.forEach {
                    appendLine("• ${it.name}: ${Format.money(it.totalAmount, currency)}")
                }
            }
            if (report.topBuyers.isNotEmpty()) {
                appendLine(getString(R.string.report_top_buyers))
                report.topBuyers.forEach {
                    appendLine("• ${it.name}: ${Format.money(it.totalAmount, currency)} (${getString(R.string.profit)} ${Format.number(it.profit)})")
                }
            }
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, getString(R.string.report_title))
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.report_share)))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding.rvSellers.adapter = null
        binding.rvBuyers.adapter = null
        _binding = null
    }

    private companion object {
        const val REQUEST_FROM = "report_range_from"
        const val REQUEST_TO = "report_range_to"

        /** تا پایان همان روز (۲۳:۵۹:۵۹) — چون تاریخ‌ها ساعت ۱۲ ظهر ذخیره می‌شوند */
        const val END_OF_DAY_OFFSET = 12L * 60 * 60 * 1000 - 1
    }
}
