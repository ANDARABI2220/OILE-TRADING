package com.ninjatech.oiltrading.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ninjatech.oiltrading.data.crypto.AndroidKeystoreEncryptor
import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.dao.AssetDao
import com.ninjatech.oiltrading.data.dao.PurchaseDao
import com.ninjatech.oiltrading.data.dao.SaleDao
import com.ninjatech.oiltrading.data.dao.TradeAlertDao
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale
import com.ninjatech.oiltrading.data.entity.TradeAlert

@Database(
    entities = [Purchase::class, Sale::class, Asset::class, TradeAlert::class],
    version = 2,
    exportSchema = true
)
@TypeConverters(CryptoConverters::class)
abstract class OilDatabase : RoomDatabase() {

    abstract fun purchaseDao(): PurchaseDao
    abstract fun saleDao(): SaleDao
    abstract fun assetDao(): AssetDao
    abstract fun alertDao(): TradeAlertDao

    companion object {
        const val DB_NAME = "oil_trading.db"

        @Volatile
        private var instance: OilDatabase? = null

        fun getInstance(context: Context): OilDatabase =
            instance ?: synchronized(this) {
                instance ?: build(context, AndroidKeystoreEncryptor()).also { instance = it }
            }

        /**
         * سازندهٔ اصلی پایگاه داده.
         *
         * تست‌ها همین متد را صدا می‌زنند (با رمزنگار درون‌حافظه‌ای و نام دیگر)
         * تا دقیقاً همان پیکربندی نسخهٔ تولید سنجیده شود، نه نسخه‌ای موازی.
         */
        fun build(
            context: Context,
            encryptor: FieldEncryptor,
            name: String = DB_NAME
        ): OilDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                OilDatabase::class.java,
                name
            )
                .addTypeConverter(CryptoConverters(encryptor))
                .addMigrations(MigrationV1ToV2(encryptor))
                .addCallback(AssetSeedCallback)
                .build()
    }
}

/** کالاهای پیش‌فرض هنگام ساخت پایگاه داده روی نصب تازه */
object AssetSeedCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        Asset.defaults().forEach { asset ->
            db.execSQL(
                "INSERT OR IGNORE INTO `assets` " +
                    "(`id`, `name`, `grade`, `liters_per_ton`, `active`, `created_at`) " +
                    "VALUES (?, ?, ?, ?, ?, ?)",
                arrayOf(
                    asset.id,
                    asset.name,
                    asset.grade,
                    asset.litersPerTon,
                    if (asset.active) 1 else 0,
                    asset.createdAt
                )
            )
        }
    }

    override fun onOpen(db: SupportSQLiteDatabase) {
        super.onOpen(db)
        db.execSQL("PRAGMA foreign_keys = ON")
    }
}
