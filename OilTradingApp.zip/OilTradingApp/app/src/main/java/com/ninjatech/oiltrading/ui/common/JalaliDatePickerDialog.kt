package com.ninjatech.oiltrading.ui.common

import android.app.Dialog
import android.os.Bundle
import android.widget.NumberPicker
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.setFragmentResult
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.databinding.DialogJalaliDatePickerBinding
import com.ninjatech.oiltrading.util.JalaliCalendar
import com.ninjatech.oiltrading.util.JalaliDate
import com.ninjatech.oiltrading.util.toPersianDigits

/**
 * انتخابگر تاریخ هجری شمسی با نام ماه‌های افغانی.
 *
 * انتخابگر پیش‌فرض اندروید فقط میلادی است، بنابراین یک دیالوگ سه‌بخشی
 * (روز / ماه / سال) ساخته شده است. نتیجه به‌صورت timestamp از طریق
 * Fragment Result برگردانده می‌شود.
 */
class JalaliDatePickerDialog : DialogFragment() {

    private var _binding: DialogJalaliDatePickerBinding? = null
    private val binding get() = _binding!!

    private var selected: JalaliDate = JalaliCalendar.today()

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogJalaliDatePickerBinding.inflate(layoutInflater)

        val initialTimestamp = requireArguments().getLong(ARG_TIMESTAMP, System.currentTimeMillis())
        selected = JalaliCalendar.fromTimestamp(initialTimestamp)

        setupPickers()
        updatePreview()

        binding.btnToday.setOnClickListener {
            selected = JalaliCalendar.today()
            applySelectionToPickers()
            updatePreview()
        }

        return MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.select_date)
            .setView(binding.root)
            .setPositiveButton(R.string.ok) { _, _ ->
                setFragmentResult(
                    requireArguments().getString(ARG_REQUEST_KEY) ?: REQUEST_KEY,
                    Bundle().apply { putLong(RESULT_TIMESTAMP, selected.toTimestamp()) }
                )
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
    }

    private fun setupPickers() = with(binding) {
        val currentYear = JalaliCalendar.today().year

        pickerYear.minValue = currentYear - 10
        pickerYear.maxValue = currentYear + 5
        pickerYear.displayedValues =
            (pickerYear.minValue..pickerYear.maxValue)
                .map { it.toString().toPersianDigits() }
                .toTypedArray()
        pickerYear.wrapSelectorWheel = false

        pickerMonth.minValue = 1
        pickerMonth.maxValue = 12
        pickerMonth.displayedValues = JalaliCalendar.AFGHAN_MONTHS
        pickerMonth.wrapSelectorWheel = true

        pickerDay.minValue = 1
        pickerDay.maxValue = 31
        pickerDay.wrapSelectorWheel = true

        applySelectionToPickers()

        val listener = NumberPicker.OnValueChangeListener { _, _, _ ->
            val year = pickerYear.value
            val month = pickerMonth.value
            val maxDay = JalaliCalendar.monthLength(year, month)

            if (pickerDay.maxValue != maxDay) {
                // ترتیب مهم است: اول مقدار را در محدودهٔ جدید قرار بده، بعد سقف را تغییر بده.
                if (pickerDay.value > maxDay) pickerDay.value = maxDay
                pickerDay.maxValue = maxDay
                refreshDayLabels(maxDay)
            }

            selected = JalaliDate(year, month, pickerDay.value)
            updatePreview()
        }

        pickerYear.setOnValueChangedListener(listener)
        pickerMonth.setOnValueChangedListener(listener)
        pickerDay.setOnValueChangedListener(listener)
    }

    private fun applySelectionToPickers() = with(binding) {
        val maxDay = JalaliCalendar.monthLength(selected.year, selected.month)
        pickerDay.maxValue = maxDay
        refreshDayLabels(maxDay)

        pickerYear.value = selected.year.coerceIn(pickerYear.minValue, pickerYear.maxValue)
        pickerMonth.value = selected.month
        pickerDay.value = selected.day.coerceAtMost(maxDay)
    }

    private fun refreshDayLabels(maxDay: Int) {
        binding.pickerDay.displayedValues =
            (1..maxDay).map { it.toString().toPersianDigits() }.toTypedArray()
    }

    private fun updatePreview() {
        val weekDay = JalaliCalendar.weekDayName(selected.toTimestamp())
        binding.tvPreview.text = "$weekDay ${selected.formatLong()}"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val REQUEST_KEY = "jalali_date_request"
        const val RESULT_TIMESTAMP = "timestamp"

        private const val ARG_TIMESTAMP = "arg_timestamp"
        private const val ARG_REQUEST_KEY = "arg_request_key"
        private const val TAG = "JalaliDatePicker"

        fun show(
            manager: FragmentManager,
            currentTimestamp: Long,
            requestKey: String = REQUEST_KEY
        ) {
            JalaliDatePickerDialog().apply {
                arguments = Bundle().apply {
                    putLong(ARG_TIMESTAMP, currentTimestamp)
                    putString(ARG_REQUEST_KEY, requestKey)
                }
            }.show(manager, TAG)
        }
    }
}
