package com.ninjatech.oiltrading.data.db

import androidx.room.ProvidedTypeConverter
import androidx.room.TypeConverter
import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.crypto.Secret

/**
 * هر فیلدی که نوعش [Secret] باشد، هنگام نوشتن رمز و هنگام خواندن باز می‌شود.
 *
 * `@ProvidedTypeConverter` است چون به یک [FieldEncryptor] زنده نیاز دارد؛
 * نمونهٔ آن موقع ساخت پایگاه داده با `addTypeConverter` تزریق می‌شود.
 */
@ProvidedTypeConverter
class CryptoConverters(private val encryptor: FieldEncryptor) {

    /** متن ساده ← رمزشده. مقادیر non-null هستند تا Room ستون را NOT NULL بسازد. */
    @TypeConverter
    fun fromSecret(secret: Secret): String = encryptor.encrypt(secret.value)

    @TypeConverter
    fun toSecret(stored: String): Secret = Secret(encryptor.decrypt(stored))
}
