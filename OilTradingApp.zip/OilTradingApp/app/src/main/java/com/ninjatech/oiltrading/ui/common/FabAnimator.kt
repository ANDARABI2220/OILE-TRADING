package com.ninjatech.oiltrading.ui.common

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.provider.Settings
import android.util.TypedValue
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.animation.doOnEnd
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

/**
 * انیمیشن‌های دکمهٔ شناور ثبت معامله.
 *
 * چهار رفتار دارد:
 *  ۱. **ورود**: دکمه با بزرگ‌شدن و کمی بالا آمدن ظاهر می‌شود.
 *  ۲. **جمع و باز شدن با اسکرول**: هنگام پایین رفتن فهرست به آیکون جمع می‌شود
 *     تا جلوی محتوا را نگیرد و با بالا آمدن دوباره باز می‌شود.
 *  ۳. **تپش توجه**: وقتی فهرست خالی است دکمه چند بار آرام نبض می‌زند تا کاربر تازه
 *     بفهمد ثبت معامله از همین‌جاست.
 *  ۴. **بازخورد فشار**: یک فشردگی کوتاه هنگام کلیک.
 *
 * **اصل حاکم بر این کلاس:** دکمه هرگز نباید نامرئی بماند. هر مسیر خروجی —
 * لغو انیمیشن، خاموش بودن انیمیشن‌های سیستم، نابود شدن نما — دکمه را به حالت
 * کاملاً دیدنی برمی‌گرداند. باگی که این کلاس برای رفعش نوشته شده دقیقاً
 * «دکمه‌ای که دیده نمی‌شود» بود؛ خودِ انیمیشن نباید همان باگ را برگرداند.
 *
 * **دسترسی‌پذیری:** اگر کاربر انیمیشن‌های سیستم را خاموش کرده باشد
 * (Animator duration scale = 0) هیچ انیمیشنی اجرا نمی‌شود.
 */
class FabAnimator(private val fab: ExtendedFloatingActionButton) {

    private var attentionAnimator: ObjectAnimator? = null
    private var scrollListener: RecyclerView.OnScrollListener? = null
    private var boundList: RecyclerView? = null
    private var hasPlayedEntrance = false

    /** آیا کاربر انیمیشن‌های سیستم را روشن گذاشته است؟ */
    private val animationsEnabled: Boolean
        get() = try {
            Settings.Global.getFloat(
                fab.context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f
            ) != 0f
        } catch (e: Exception) {
            true
        }

    private fun dp(value: Float): Float = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value,
        fab.resources.displayMetrics
    )

    /** حالت نهایی و کاملاً دیدنی دکمه */
    private fun applyVisibleState() {
        fab.alpha = 1f
        fab.scaleX = 1f
        fab.scaleY = 1f
        fab.translationY = 0f
    }

    // ---------------------------------------------------------------- ورود

    /**
     * ظاهر شدن دکمه هنگام باز شدن صفحه.
     *
     * انیمیشن در `doOnLayout` اجرا می‌شود، نه بلافاصله: اگر روی نمایی که هنوز
     * به پنجره وصل نشده `animate()` صدا زده شود، ممکن است هرگز اجرا نشود و
     * دکمه با alpha صفر نامرئی بماند.
     */
    fun playEntrance() {
        if (hasPlayedEntrance) return
        hasPlayedEntrance = true

        if (!animationsEnabled) {
            applyVisibleState()
            return
        }

        fab.alpha = 0f
        fab.scaleX = ENTRANCE_START_SCALE
        fab.scaleY = ENTRANCE_START_SCALE
        fab.translationY = dp(ENTRANCE_OFFSET_DP)

        fab.doOnLayout {
            fab.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setStartDelay(ENTRANCE_DELAY_MS)
                .setDuration(ENTRANCE_DURATION_MS)
                .setInterpolator(OvershootInterpolator(OVERSHOOT_TENSION))
                // تضمین حالت نهایی، حتی اگر انیمیشن ناتمام بماند
                .withEndAction { applyVisibleState() }
                .start()
        }
    }

    // ---------------------------------------------------------------- اسکرول

    /**
     * جمع و باز شدن دکمه همراه با اسکرول فهرست.
     *
     * آستانهٔ [SCROLL_THRESHOLD_PX] جلوی لرزش دکمه در اسکرول‌های ریز را می‌گیرد.
     */
    fun bindToList(recyclerView: RecyclerView) {
        unbindFromList()

        val listener = object : RecyclerView.OnScrollListener() {
            override fun onScrolled(view: RecyclerView, dx: Int, dy: Int) {
                when {
                    dy > SCROLL_THRESHOLD_PX && fab.isExtended -> {
                        stopAttention()
                        fab.shrink()
                    }
                    dy < -SCROLL_THRESHOLD_PX && !fab.isExtended -> fab.extend()
                }
            }
        }

        recyclerView.addOnScrollListener(listener)
        scrollListener = listener
        boundList = recyclerView
    }

    private fun unbindFromList() {
        scrollListener?.let { boundList?.removeOnScrollListener(it) }
        scrollListener = null
        boundList = null
    }

    // ---------------------------------------------------------------- تپش توجه

    /**
     * وقتی فهرست خالی است دکمه آرام نبض می‌زند.
     *
     * همین نشانه بود که نبودنش باعث می‌شد کاربر فکر کند اصلاً راهی برای ثبت
     * معامله وجود ندارد.
     *
     * نگهبانِ تکرار روی `attentionAnimator != null` است و نه `isRunning`:
     * در طول [ATTENTION_DELAY_MS] اولیه، `isRunning` هنوز false است و با آن
     * شرط، هر فراخوانی دوباره یک انیماتور جدید می‌ساخت و قبلی رها می‌شد.
     */
    fun setAttentionEnabled(enabled: Boolean) {
        // تپش محدود است، نه بی‌پایان: چند بار توجه را جلب می‌کند و بعد آرام
        // می‌گیرد. حرکت خودکارِ بی‌پایان هم آزاردهنده است و هم خلاف معیار
        // دسترسی‌پذیری WCAG 2.2.2 (Pause, Stop, Hide).
        if (!enabled || !animationsEnabled) {
            stopAttention()
            return
        }
        if (attentionAnimator != null) return

        if (!fab.isExtended) fab.extend()

        attentionAnimator = ObjectAnimator.ofPropertyValuesHolder(
            fab,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, ATTENTION_SCALE, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, ATTENTION_SCALE, 1f)
        ).apply {
            duration = ATTENTION_DURATION_MS
            startDelay = ATTENTION_DELAY_MS
            repeatCount = ATTENTION_REPEATS
            repeatMode = ValueAnimator.RESTART
            interpolator = DecelerateInterpolator()
            // بعد از پایان، مرجع را آزاد کن تا دفعهٔ بعد که کاربر به این تب
            // برگردد بتوان دوباره مسلحش کرد.
            doOnEnd {
                fab.scaleX = 1f
                fab.scaleY = 1f
                attentionAnimator = null
            }
            start()
        }
    }

    private fun stopAttention() {
        attentionAnimator?.let { animator ->
            animator.cancel()
            // مقیاس را به حالت عادی برگردان تا دکمه وسط تپش گیر نکند
            fab.scaleX = 1f
            fab.scaleY = 1f
        }
        attentionAnimator = null
    }

    // ---------------------------------------------------------------- فشار

    /**
     * یک فشردگی کوتاه هنگام کلیک.
     *
     * عمداً هیچ callback ای ندارد و باز شدن فرم به پایان انیمیشن گره نخورده
     * است: اگر انیمیشن لغو شود، نباید کلیک کاربر بی‌اثر بماند. هر دو همزمان
     * اجرا می‌شوند و خوب هم به نظر می‌رسد، چون خودِ فرم هم با انیمیشن بالا می‌آید.
     */
    fun playPress() {
        if (!animationsEnabled) return

        stopAttention()
        fab.animate()
            .scaleX(PRESS_SCALE)
            .scaleY(PRESS_SCALE)
            .setDuration(PRESS_DOWN_MS)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                fab.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(PRESS_UP_MS)
                    .setInterpolator(OvershootInterpolator(OVERSHOOT_TENSION))
                    .withEndAction { applyVisibleState() }
                    .start()
            }
            .start()
    }

    // ---------------------------------------------------------------- دیده شدن

    /**
     * تپش توجه فقط وقتی باید اجرا شود که کاربر واقعاً صفحه را می‌بیند.
     *
     * دو حالت آن را قطع می‌کند و هر دو باید پوشش داده شوند:
     *  - رفتن به تب دیگر (`onHiddenChanged`، چون فرگمنت‌ها با hide/show
     *    مدیریت می‌شوند و `onPause` صدا زده نمی‌شود)
     *  - رفتن کل برنامه به پس‌زمینه (`onPause` / `onResume`)
     *
     * بدون این، یک انیمیشن بی‌پایان روی صفحه‌ای که دیده نمی‌شود تا ابد
     * پردازنده و باتری مصرف می‌کرد.
     */
    fun onVisibilityChanged(visible: Boolean, listIsEmpty: Boolean) {
        if (visible) setAttentionEnabled(listIsEmpty) else stopAttention()
    }

    // ---------------------------------------------------------------- پاک‌سازی

    /** همهٔ انیمیشن‌ها و شنونده‌ها را آزاد می‌کند — از `onDestroyView` صدا زده می‌شود */
    fun release() {
        stopAttention()
        unbindFromList()
        fab.animate().cancel()
        applyVisibleState()
    }

    private companion object {
        const val ENTRANCE_START_SCALE = 0.5f

        /** بر حسب dp، نه پیکسل — وگرنه روی صفحه‌های پرتراکم جابه‌جایی دیده نمی‌شد */
        const val ENTRANCE_OFFSET_DP = 24f
        const val ENTRANCE_DELAY_MS = 120L
        const val ENTRANCE_DURATION_MS = 380L
        const val OVERSHOOT_TENSION = 1.4f

        const val SCROLL_THRESHOLD_PX = 8

        /** چند بار نبض بزند و بعد بایستد */
        const val ATTENTION_REPEATS = 3
        const val ATTENTION_SCALE = 1.08f
        const val ATTENTION_DURATION_MS = 1400L
        const val ATTENTION_DELAY_MS = 700L

        const val PRESS_SCALE = 0.92f
        const val PRESS_DOWN_MS = 90L
        const val PRESS_UP_MS = 180L
    }
}
