package com.ninjatech.oiltrading.ui.common

import android.app.TimePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.activityViewModels
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.ninjatech.oiltrading.OilTradingApplication
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.OilUnit
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.repo.TradeRepository.TradeInput
import com.ninjatech.oiltrading.databinding.DialogTradeFormBinding
import com.ninjatech.oiltrading.domain.FollowUpPolicy
import com.ninjatech.oiltrading.domain.TradeType
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModel
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModelFactory
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.JalaliCalendar
import com.ninjatech.oiltrading.util.parseAmountOrNull
import com.ninjatech.oiltrading.util.toPersianDigits
import java.util.Calendar

/**
 * فرم مشترک ثبت و ویرایش معامله.
 *
 * همان فرم هم برای خرید و هم برای فروش استفاده می‌شود؛ فقط عنوان‌ها،
 * برچسب فیلد نام و مقصد ذخیره‌سازی فرق می‌کند.
 */
class TradeFormSheet : BottomSheetDialogFragment() {

    enum class Mode(val tradeType: TradeType) {
        PURCHASE(TradeType.PURCHASE),
        SALE(TradeType.SALE)
    }

    private var _binding: DialogTradeFormBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TradeViewModel by activityViewModels {
        val app = requireActivity().application as OilTradingApplication
        TradeViewModelFactory(app.repository, app.alertRepository, app.prefs)
    }

    private lateinit var mode: Mode
    private var recordId: Long? = null

    private var tradedAt: Long = System.currentTimeMillis()
    private var followUpDate: Long? = null
    private var selectedUnit: OilUnit = OilUnit.LITER
    private var selectedAssetId: String = Asset.DIESEL
    private var selectedCurrency: String = Purchase.DEFAULT_CURRENCY
    private var availableAssets: List<Asset> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogTradeFormBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val args = requireArguments()
        mode = Mode.valueOf(args.getString(ARG_MODE) ?: Mode.PURCHASE.name)
        recordId = args.getLong(ARG_ID, 0L).takeIf { it != 0L }

        applyLabels()
        setupUnitDropdown()
        setupCurrencyDropdown()
        setupAssetDropdown()
        setupNameSuggestions()
        setupDateAndTimePickers()
        setupFollowUpPicker()
        setupLiveTotal()
        prefillIfEditing(args)

        binding.btnCancel.setOnClickListener { dismiss() }
        binding.btnSave.setOnClickListener { submit() }
    }

    // ---------------------------------------------------------------- تنظیم فرم

    private fun applyLabels() {
        val isPurchase = mode == Mode.PURCHASE
        binding.tvTitle.setText(
            when {
                isPurchase && recordId == null -> R.string.purchase_new
                isPurchase -> R.string.purchase_edit
                recordId == null -> R.string.sale_new
                else -> R.string.sale_edit
            }
        )
        binding.tilName.hint = getString(if (isPurchase) R.string.seller_name else R.string.buyer_name)
        binding.tilPrice.hint = getString(if (isPurchase) R.string.purchase_price else R.string.sale_price)
        binding.tilDate.hint = getString(if (isPurchase) R.string.purchase_date else R.string.sale_date)
    }

    private fun setupUnitDropdown() {
        val labels = OilUnit.entries.map { it.label }
        binding.etUnit.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, labels)
        )
        binding.etUnit.setText(selectedUnit.label, false)
        binding.etUnit.setOnItemClickListener { _, _, position, _ ->
            selectedUnit = OilUnit.entries[position]
            updateTotalPreview()
        }
    }

    private fun setupCurrencyDropdown() {
        selectedCurrency = viewModel.currency.takeIf { it.isNotBlank() } ?: Purchase.DEFAULT_CURRENCY
        binding.etCurrency.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, CURRENCIES)
        )
        binding.etCurrency.setText(selectedCurrency, false)
        binding.etCurrency.setOnItemClickListener { _, _, position, _ ->
            selectedCurrency = CURRENCIES[position]
            updateTotalPreview()
        }
    }

    /** فهرست کالاها از پایگاه داده می‌آید — شناسهٔ یکتای هر معامله به اینجا وصل می‌شود */
    private fun setupAssetDropdown() {
        viewModel.assets.observe(viewLifecycleOwner) { assets ->
            availableAssets = assets
            binding.etAsset.setAdapter(
                ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_list_item_1,
                    assets.map { it.displayName }
                )
            )
            val current = assets.firstOrNull { it.id == selectedAssetId } ?: assets.firstOrNull()
            current?.let {
                selectedAssetId = it.id
                binding.etAsset.setText(it.displayName, false)
            }
        }

        binding.etAsset.setOnItemClickListener { _, _, position, _ ->
            availableAssets.getOrNull(position)?.let { selectedAssetId = it.id }
        }
    }

    /** نام‌هایی که قبلاً وارد شده‌اند به‌عنوان پیشنهاد ظاهر می‌شوند */
    private fun setupNameSuggestions() {
        val source = if (mode == Mode.PURCHASE) viewModel.sellerNames else viewModel.buyerNames
        source.observe(viewLifecycleOwner) { names ->
            binding.etName.setAdapter(
                ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, names)
            )
        }
    }

    // ---------------------------------------------------------------- تاریخ و ساعت

    private fun setupDateAndTimePickers() {
        updateDateField()
        updateTimeField()

        val dateKey = "$REQUEST_KEY_DATE:${mode.name}"
        // دیالوگ روی childFragmentManager باز می‌شود، پس نتیجه هم باید از همان‌جا خوانده شود.
        childFragmentManager.setFragmentResultListener(dateKey, viewLifecycleOwner) { _, bundle ->
            val picked = bundle.getLong(JalaliDatePickerDialog.RESULT_TIMESTAMP, tradedAt)
            // ساعتی که کاربر انتخاب کرده حفظ می‌شود؛ فقط بخش تاریخ عوض می‌شود.
            tradedAt = combineDateAndTime(datePart = picked, timePart = tradedAt)
            updateDateField()
        }

        val openDate = View.OnClickListener {
            JalaliDatePickerDialog.show(childFragmentManager, tradedAt, dateKey)
        }
        binding.etDate.setOnClickListener(openDate)
        binding.tilDate.setEndIconOnClickListener(openDate)

        val openTime = View.OnClickListener { showTimePicker() }
        binding.etTime.setOnClickListener(openTime)
        binding.tilTime.setEndIconOnClickListener(openTime)
    }

    private fun showTimePicker() {
        val calendar = Calendar.getInstance().apply { timeInMillis = tradedAt }
        TimePickerDialog(
            requireContext(),
            { _, hour, minute ->
                tradedAt = Calendar.getInstance().apply {
                    timeInMillis = tradedAt
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                updateTimeField()
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        ).show()
    }

    /** بخش تاریخ را از یک timestamp و بخش ساعت را از دیگری می‌گیرد */
    private fun combineDateAndTime(datePart: Long, timePart: Long): Long {
        val date = Calendar.getInstance().apply { timeInMillis = datePart }
        val time = Calendar.getInstance().apply { timeInMillis = timePart }
        return Calendar.getInstance().apply {
            clear()
            set(
                date.get(Calendar.YEAR),
                date.get(Calendar.MONTH),
                date.get(Calendar.DAY_OF_MONTH),
                time.get(Calendar.HOUR_OF_DAY),
                time.get(Calendar.MINUTE),
                0
            )
        }.timeInMillis
    }

    private fun updateDateField() {
        binding.etDate.setText(JalaliCalendar.fromTimestamp(tradedAt).formatLong())
    }

    private fun updateTimeField() {
        val calendar = Calendar.getInstance().apply { timeInMillis = tradedAt }
        val text = "%02d:%02d".format(
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE)
        )
        binding.etTime.setText(text.toPersianDigits())
    }

    // ---------------------------------------------------------------- سررسید پیگیری

    private fun setupFollowUpPicker() {
        updateFollowUpField()

        val followUpKey = "$REQUEST_KEY_FOLLOW_UP:${mode.name}"
        childFragmentManager.setFragmentResultListener(followUpKey, viewLifecycleOwner) { _, bundle ->
            followUpDate = bundle.getLong(JalaliDatePickerDialog.RESULT_TIMESTAMP)
            updateFollowUpField()
        }

        val openFollowUp = View.OnClickListener {
            JalaliDatePickerDialog.show(
                childFragmentManager,
                followUpDate ?: FollowUpPolicy.suggestedFollowUpDate(tradedAt),
                followUpKey
            )
        }
        binding.etFollowUp.setOnClickListener(openFollowUp)
        binding.tilFollowUp.setEndIconOnClickListener(openFollowUp)

        binding.btnClearFollowUp.setOnClickListener {
            followUpDate = null
            updateFollowUpField()
        }
    }

    private fun updateFollowUpField() {
        val date = followUpDate
        if (date == null) {
            binding.etFollowUp.setText("")
            binding.etFollowUp.hint = getString(R.string.follow_up_none)
            binding.btnClearFollowUp.visibility = View.GONE
        } else {
            binding.etFollowUp.setText(JalaliCalendar.fromTimestamp(date).formatLong())
            binding.btnClearFollowUp.visibility = View.VISIBLE
        }
    }

    // ---------------------------------------------------------------- مبلغ زنده

    private fun setupLiveTotal() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) = updateTotalPreview()
        }
        binding.etQuantity.addTextChangedListener(watcher)
        binding.etPrice.addTextChangedListener(watcher)
        updateTotalPreview()
    }

    private fun updateTotalPreview() {
        val quantity = binding.etQuantity.text?.toString()?.parseAmountOrNull() ?: 0.0
        val price = binding.etPrice.text?.toString()?.parseAmountOrNull() ?: 0.0
        binding.tvTotalPreview.text = Format.money(quantity * price, selectedCurrency)
    }

    // ---------------------------------------------------------------- پر کردن فرم

    private fun prefillIfEditing(args: Bundle) {
        if (recordId == null) return

        binding.etName.setText(args.getString(ARG_NAME).orEmpty())
        binding.etQuantity.setText(Format.number(args.getDouble(ARG_QUANTITY), 3, persianDigits = false))
        binding.etPrice.setText(Format.number(args.getDouble(ARG_PRICE), 2, persianDigits = false))
        binding.etReference.setText(args.getString(ARG_REFERENCE).orEmpty())
        binding.etNote.setText(args.getString(ARG_NOTE).orEmpty())

        selectedUnit = OilUnit.fromDb(args.getString(ARG_UNIT))
        binding.etUnit.setText(selectedUnit.label, false)

        selectedAssetId = args.getString(ARG_ASSET_ID) ?: Asset.DIESEL
        selectedCurrency = args.getString(ARG_CURRENCY) ?: Purchase.DEFAULT_CURRENCY
        binding.etCurrency.setText(selectedCurrency, false)

        tradedAt = args.getLong(ARG_DATE, System.currentTimeMillis())
        followUpDate = args.getLong(ARG_FOLLOW_UP, 0L).takeIf { it != 0L }

        updateDateField()
        updateTimeField()
        updateFollowUpField()
        updateTotalPreview()
    }

    // ---------------------------------------------------------------- ثبت

    private fun submit() {
        val name = binding.etName.text?.toString()?.trim().orEmpty()
        val quantity = binding.etQuantity.text?.toString()?.parseAmountOrNull()
        val price = binding.etPrice.text?.toString()?.parseAmountOrNull()

        binding.tilName.error = null
        binding.tilQuantity.error = null
        binding.tilPrice.error = null
        binding.tilFollowUp.error = null

        var valid = true

        if (name.isEmpty()) {
            binding.tilName.error = getString(R.string.error_required)
            valid = false
        } else if (name.length < 2) {
            binding.tilName.error = getString(R.string.error_name_short)
            valid = false
        }

        when {
            quantity == null -> {
                binding.tilQuantity.error = getString(R.string.error_invalid_number)
                valid = false
            }
            quantity <= 0.0 -> {
                binding.tilQuantity.error = getString(R.string.error_must_be_positive)
                valid = false
            }
        }

        when {
            price == null -> {
                binding.tilPrice.error = getString(R.string.error_invalid_number)
                valid = false
            }
            price <= 0.0 -> {
                binding.tilPrice.error = getString(R.string.error_must_be_positive)
                valid = false
            }
        }

        followUpDate?.let { due ->
            if (due < tradedAt) {
                binding.tilFollowUp.error = getString(R.string.error_follow_up_before_trade)
                valid = false
            }
        }

        if (!valid) return

        viewModel.saveTrade(
            type = mode.tradeType,
            existingId = recordId,
            input = TradeInput(
                counterparty = name,
                assetId = selectedAssetId,
                quantity = quantity!!,
                unit = selectedUnit,
                pricePerUnit = price!!,
                currency = selectedCurrency,
                tradedAt = tradedAt,
                followUpDate = followUpDate,
                referenceNo = binding.etReference.text?.toString()?.trim().orEmpty(),
                note = binding.etNote.text?.toString()?.trim().orEmpty()
            )
        )
        dismiss()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val TAG = "TradeFormSheet"
        private const val REQUEST_KEY_DATE = "trade_form_date"
        private const val REQUEST_KEY_FOLLOW_UP = "trade_form_follow_up"

        private val CURRENCIES = listOf("AFN", "USD", "IRR", "PKR", "UZS")

        private const val ARG_MODE = "mode"
        private const val ARG_ID = "id"
        private const val ARG_NAME = "name"
        private const val ARG_ASSET_ID = "asset_id"
        private const val ARG_QUANTITY = "quantity"
        private const val ARG_UNIT = "unit"
        private const val ARG_PRICE = "price"
        private const val ARG_CURRENCY = "currency"
        private const val ARG_DATE = "date"
        private const val ARG_FOLLOW_UP = "follow_up"
        private const val ARG_REFERENCE = "reference"
        private const val ARG_NOTE = "note"

        /** ثبت معاملهٔ جدید */
        fun showNew(manager: FragmentManager, mode: Mode) {
            TradeFormSheet().apply {
                arguments = Bundle().apply { putString(ARG_MODE, mode.name) }
            }.show(manager, TAG)
        }

        /** ویرایش معاملهٔ موجود */
        @Suppress("LongParameterList")
        fun showEdit(
            manager: FragmentManager,
            mode: Mode,
            id: Long,
            name: String,
            assetId: String,
            quantity: Double,
            unit: String,
            pricePerUnit: Double,
            currency: String,
            tradedAt: Long,
            followUpDate: Long?,
            referenceNo: String,
            note: String
        ) {
            TradeFormSheet().apply {
                arguments = Bundle().apply {
                    putString(ARG_MODE, mode.name)
                    putLong(ARG_ID, id)
                    putString(ARG_NAME, name)
                    putString(ARG_ASSET_ID, assetId)
                    putDouble(ARG_QUANTITY, quantity)
                    putString(ARG_UNIT, unit)
                    putDouble(ARG_PRICE, pricePerUnit)
                    putString(ARG_CURRENCY, currency)
                    putLong(ARG_DATE, tradedAt)
                    putLong(ARG_FOLLOW_UP, followUpDate ?: 0L)
                    putString(ARG_REFERENCE, referenceNo)
                    putString(ARG_NOTE, note)
                }
            }.show(manager, TAG)
        }
    }
}
