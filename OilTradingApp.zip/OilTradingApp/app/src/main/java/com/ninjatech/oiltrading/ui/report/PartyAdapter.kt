package com.ninjatech.oiltrading.ui.report

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.databinding.ItemPartyBinding
import com.ninjatech.oiltrading.domain.PartyTotals
import com.ninjatech.oiltrading.util.Format

/** فهرست طرف‌های حساب (فروشندگان یا خریداران) در صفحهٔ گزارش */
class PartyAdapter(
    private val currency: () -> String,
    /** برای خریداران true تا ستون مفاد هم نمایش داده شود */
    private val showProfit: Boolean
) : ListAdapter<PartyTotals, PartyAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPartyBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemPartyBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: PartyTotals) = with(binding) {
            val context = root.context

            tvPartyName.text = item.name
            tvPartyAmount.text = Format.money(item.totalAmount, currency())

            val transactions = context.getString(
                R.string.report_transactions,
                Format.number(item.transactionCount.toDouble(), 0)
            )
            tvPartyMeta.text = "$transactions • ${Format.quantity(item.totalLiters, context.getString(R.string.unit_liter))}"

            if (showProfit) {
                tvPartyProfit.visibility = View.VISIBLE
                val isProfit = item.profit >= 0
                tvPartyProfit.setTextColor(
                    ContextCompat.getColor(context, if (isProfit) R.color.profit else R.color.loss)
                )
                val label = context.getString(if (isProfit) R.string.profit else R.string.loss)
                tvPartyProfit.text = "$label ${Format.number(kotlin.math.abs(item.profit))}"
            } else {
                tvPartyProfit.visibility = View.GONE
            }
        }
    }

    private companion object {
        val DIFF = object : DiffUtil.ItemCallback<PartyTotals>() {
            override fun areItemsTheSame(oldItem: PartyTotals, newItem: PartyTotals) =
                oldItem.name == newItem.name

            override fun areContentsTheSame(oldItem: PartyTotals, newItem: PartyTotals) =
                oldItem == newItem
        }
    }
}
