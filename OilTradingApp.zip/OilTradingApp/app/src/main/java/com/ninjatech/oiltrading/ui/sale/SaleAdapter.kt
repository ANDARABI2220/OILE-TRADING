package com.ninjatech.oiltrading.ui.sale

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.databinding.ItemSaleBinding
import com.ninjatech.oiltrading.domain.SaleWithProfit
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.JalaliCalendar

class SaleAdapter(
    private val currency: () -> String,
    private val onMoreClick: (SaleWithProfit, View) -> Unit
) : ListAdapter<SaleWithProfit, SaleAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemSaleBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemSaleBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: SaleWithProfit) = with(binding) {
            val sale = item.sale
            val context = root.context

            tvBuyer.text = sale.buyerName.value
            tvDate.text = JalaliCalendar.fromTimestamp(sale.tradedAt).formatLong()
            tvTotal.text = Format.money(sale.totalPrice, currency())
            tvUnitPrice.text = "${Format.number(sale.pricePerUnit)} × ${sale.oilUnit.label}"
            tvQuantity.text = Format.quantity(sale.quantity, sale.oilUnit.label)

            // نشان مفاد: سبز برای سود، قرمز برای ضرر
            val isProfit = item.profit >= 0
            tvProfit.setBackgroundResource(
                if (isProfit) R.drawable.bg_pill_profit else R.drawable.bg_pill_loss
            )
            tvProfit.setTextColor(
                ContextCompat.getColor(
                    context,
                    if (isProfit) R.color.on_profit_container else R.color.on_loss_container
                )
            )
            val profitLabel = context.getString(if (isProfit) R.string.profit else R.string.loss)
            tvProfit.text = "$profitLabel ${Format.number(kotlin.math.abs(item.profit))}"

            tvOversold.visibility = if (item.oversold) View.VISIBLE else View.GONE

            tvCostBasis.text = context.getString(R.string.cost_basis) +
                    ": ${Format.money(item.costOfGoodsSold, currency())}" +
                    " • ${Format.percent(item.marginPercent)}"

            if (sale.note.value.isBlank()) {
                tvNote.visibility = View.GONE
            } else {
                tvNote.visibility = View.VISIBLE
                tvNote.text = sale.note.value
            }

            btnMore.setOnClickListener { onMoreClick(item, it) }
            root.setOnClickListener { onMoreClick(item, btnMore) }
        }
    }

    private companion object {
        val DIFF = object : DiffUtil.ItemCallback<SaleWithProfit>() {
            override fun areItemsTheSame(oldItem: SaleWithProfit, newItem: SaleWithProfit) =
                oldItem.sale.id == newItem.sale.id

            override fun areContentsTheSame(oldItem: SaleWithProfit, newItem: SaleWithProfit) =
                oldItem == newItem
        }
    }
}
