package com.ninjatech.oiltrading.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * کالا / دارایی مورد معامله — «شناسهٔ یکتای کالا» که هر خرید و فروش به آن وصل می‌شود.
 *
 * چون چگالی هر نوع تیل فرق می‌کند، ضریب تبدیل تن به لیتر روی خودِ کالا نگه
 * داشته می‌شود؛ این دقیق‌تر از یک ضریب سراسری در تنظیمات است.
 */
@Entity(tableName = "assets")
data class Asset(
    /** شناسهٔ یکتا و پایدار، مثلاً `diesel` — کلید خارجی معاملات به همین اشاره می‌کند */
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "name")
    val name: String,

    /** درجه یا مشخصات فنی، مثلاً «L-0.2-62» */
    @ColumnInfo(name = "grade")
    val grade: String = "",

    /** چند لیتر در هر تن — بر اساس چگالی همین کالا */
    @ColumnInfo(name = "liters_per_ton")
    val litersPerTon: Double,

    @ColumnInfo(name = "active")
    val active: Boolean = true,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
) {
    /** برچسب نمایشی در فهرست‌های انتخاب */
    val displayName: String
        get() = if (grade.isBlank()) name else "$name ($grade)"

    companion object {
        const val DIESEL = "diesel"
        const val PETROL = "petrol"
        const val LPG = "lpg"
        const val KEROSENE = "kerosene"

        /** کالاهایی که هنگام اولین اجرا در پایگاه داده ساخته می‌شوند */
        fun defaults(): List<Asset> = listOf(
            Asset(id = DIESEL, name = "دیزل", litersPerTon = 1190.0),
            Asset(id = PETROL, name = "پترول", litersPerTon = 1333.0),
            Asset(id = LPG, name = "گاز مایع", litersPerTon = 1960.0),
            Asset(id = KEROSENE, name = "تیل خاک", litersPerTon = 1235.0)
        )
    }
}
