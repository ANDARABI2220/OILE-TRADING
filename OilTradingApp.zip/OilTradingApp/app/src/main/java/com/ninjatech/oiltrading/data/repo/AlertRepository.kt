package com.ninjatech.oiltrading.data.repo

import com.ninjatech.oiltrading.data.dao.PurchaseDao
import com.ninjatech.oiltrading.data.dao.SaleDao
import com.ninjatech.oiltrading.data.dao.TradeAlertDao
import com.ninjatech.oiltrading.data.entity.AlertType
import com.ninjatech.oiltrading.data.entity.TradeAlert
import com.ninjatech.oiltrading.data.entity.TradeEntity
import com.ninjatech.oiltrading.data.entity.TradeKind
import com.ninjatech.oiltrading.domain.FollowUpPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * ساخت، خواندن و علامت‌گذاری هشدارهای پیگیری.
 *
 * جلوگیری از اعلان تکراری روی سه لایه انجام می‌شود:
 *  ۱. پرس‌وجوی DAO معاملاتی را که قبلاً هشدار گرفته‌اند کنار می‌گذارد.
 *  ۲. ایندکس یکتای پایگاه داده درج تکراری را رد می‌کند.
 *  ۳. ستون `notified_at` مشخص می‌کند اعلان کدام هشدار قبلاً ارسال شده.
 */
class AlertRepository(
    private val purchaseDao: PurchaseDao,
    private val saleDao: SaleDao,
    private val alertDao: TradeAlertDao
) {

    /** هشدارهایی که کاربر هنوز نبسته است — ورودی نوار هشدار داخل برنامه */
    val activeAlerts: Flow<List<TradeAlert>> = alertDao.observeUnacknowledged()

    val allAlerts: Flow<List<TradeAlert>> = alertDao.observeAll()

    /**
     * معاملاتی را که تا سررسیدشان [FollowUpPolicy.ALERT_WINDOW_DAYS] روز یا
     * کمتر مانده پیدا می‌کند و برایشان هشدار می‌سازد.
     *
     * فروش‌ها هم بررسی می‌شوند: اگر کاربر برای یک فروش تاریخ سررسید بگذارد و
     * ما فقط خریدها را بخوانیم، آن فیلد بی‌اثر و گمراه‌کننده می‌شود.
     *
     * @return هشدارهای تازه‌ساخته‌شده (تکراری‌ها در خروجی نیستند)
     */
    suspend fun scanAndCreateAlerts(now: Long): List<TradeAlert> = withContext(Dispatchers.IO) {
        val window = FollowUpPolicy.alertWindow(now)
        val alertType = AlertType.FOLLOW_UP_DUE.dbValue
        val created = mutableListOf<TradeAlert>()

        purchaseDao.findDueForFollowUp(window.first, window.last, alertType).forEach { purchase ->
            createAlert(
                kind = TradeKind.PURCHASE,
                trade = purchase,
                counterparty = purchase.sellerName.value,
                now = now
            )?.let { created += it }
        }

        saleDao.findDueForFollowUp(window.first, window.last, alertType).forEach { sale ->
            createAlert(
                kind = TradeKind.SALE,
                trade = sale,
                counterparty = sale.buyerName.value,
                now = now
            )?.let { created += it }
        }

        created
    }

    private suspend fun createAlert(
        kind: TradeKind,
        trade: TradeEntity,
        counterparty: String,
        now: Long
    ): TradeAlert? {
        val dueDate = trade.followUpDate ?: return null

        val alert = TradeAlert(
            tradeKind = kind.dbValue,
            tradeId = trade.id,
            alertType = AlertType.FOLLOW_UP_DUE.dbValue,
            dueDate = dueDate,
            counterparty = counterparty,
            amount = trade.totalPrice,
            currency = trade.currency,
            createdAt = now
        )

        // ‎-1 یعنی ایندکس یکتا درج را رد کرده؛ یعنی هشدار از قبل وجود داشته است.
        val id = alertDao.insert(alert)
        return if (id > 0) alert.copy(id = id) else null
    }

    /** هشدارهایی که ساخته شده‌اند ولی هنوز اعلانشان به کاربر نرسیده */
    suspend fun pendingNotifications(): List<TradeAlert> = withContext(Dispatchers.IO) {
        alertDao.findPendingNotification()
    }

    /** ثبت اینکه اعلان این هشدارها ارسال شد — تضمین می‌کند دوباره ارسال نشوند */
    suspend fun markNotified(alerts: List<TradeAlert>, now: Long) = withContext(Dispatchers.IO) {
        if (alerts.isNotEmpty()) {
            alertDao.markNotified(alerts.map { it.id }, now)
        }
    }

    suspend fun acknowledge(alertId: Long) = withContext(Dispatchers.IO) {
        alertDao.acknowledge(alertId)
    }

    suspend fun acknowledgeAll() = withContext(Dispatchers.IO) {
        alertDao.acknowledgeAll()
    }

    suspend fun alertCount(): Int = withContext(Dispatchers.IO) { alertDao.count() }
}
