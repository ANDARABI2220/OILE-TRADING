package com.ninjatech.oiltrading.alerts

import android.content.Context
import android.util.Log
import androidx.annotation.VisibleForTesting
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.ninjatech.oiltrading.OilTradingApplication
import com.ninjatech.oiltrading.data.repo.AlertRepository
import java.util.concurrent.TimeUnit

/**
 * سرویس پس‌زمینهٔ سیستم هشدار.
 *
 * هر بار که اجرا می‌شود:
 *  ۱. معاملاتی را که تا سررسیدشان ۲۸ روز یا کمتر مانده پیدا و هشدارشان را ثبت می‌کند.
 *  ۲. برای هشدارهایی که هنوز اعلان نگرفته‌اند اعلان می‌فرستد.
 *  ۳. زمان ارسال را در پایگاه داده ثبت می‌کند تا اعلان تکراری نرود.
 *
 * چرا WorkManager و نه Service یا AlarmManager؟ چون اجرای کار را حتی بعد از
 * ری‌استارت دستگاه، بسته‌شدن برنامه یا کشته‌شدن پروسه تضمین می‌کند و با
 * محدودیت‌های Doze و بهینه‌سازی باتری اندروید سازگار است. هیچ محدودیت شبکه‌ای
 * هم نگذاشته‌ایم چون کار کاملاً آفلاین است و نباید منتظر اینترنت بماند.
 */
class FollowUpWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val dependencies = dependencyProvider(applicationContext)
            ?: return Result.success() // خارج از برنامهٔ واقعی، کاری برای انجام نیست

        return runCatching { execute(dependencies.alerts, dependencies.notifier) }
            .getOrElse { error ->
                Log.e(TAG, "بررسی هشدارها ناموفق بود", error)
                // خطای گذرا (مثلاً قفل بودن پایگاه داده) — دفعهٔ بعد دوباره تلاش می‌شود
                if (runAttemptCount < MAX_ATTEMPTS) Result.retry() else Result.failure()
            }
    }

    private suspend fun execute(
        alertRepository: AlertRepository,
        notifier: AlertNotifier
    ): Result {
        val now = System.currentTimeMillis()

        val created = alertRepository.scanAndCreateAlerts(now)
        val pending = alertRepository.pendingNotifications()

        val delivered = pending.filter { notifier.notify(it, now) }
        alertRepository.markNotified(delivered, now)

        Log.i(TAG, "هشدار جدید: ${created.size} | اعلان ارسال‌شده: ${delivered.size}")

        return Result.success(
            workDataOf(
                KEY_CREATED to created.size,
                KEY_NOTIFIED to delivered.size
            )
        )
    }

    /** آنچه سرویس برای کارش لازم دارد */
    data class Dependencies(
        val alerts: AlertRepository,
        val notifier: AlertNotifier
    )

    companion object {
        private const val TAG = "FollowUpWorker"
        private const val MAX_ATTEMPTS = 3

        /**
         * از کجا وابستگی‌ها را بگیریم.
         *
         * به‌صورت پیش‌فرض از [OilTradingApplication] خوانده می‌شود؛ تست‌ها آن را
         * با پایگاه دادهٔ درون‌حافظه‌ای و اعلان‌رسان ساختگی جایگزین می‌کنند تا
         * بدون دستگاه یا شبیه‌ساز قابل اجرا باشد.
         */
        @VisibleForTesting
        var dependencyProvider: (Context) -> Dependencies? = { context ->
            (context as? OilTradingApplication)?.let {
                Dependencies(it.alertRepository, it.notifier)
            }
        }

        /** بازگرداندن رفتار پیش‌فرض بعد از تست */
        @VisibleForTesting
        fun resetDependencyProvider() {
            dependencyProvider = { context ->
                (context as? OilTradingApplication)?.let {
                    Dependencies(it.alertRepository, it.notifier)
                }
            }
        }

        const val PERIODIC_WORK_NAME = "follow_up_periodic_scan"
        const val ONE_SHOT_WORK_NAME = "follow_up_immediate_scan"

        const val KEY_CREATED = "created_alerts"
        const val KEY_NOTIFIED = "sent_notifications"

        /** هر روز یک بار بررسی می‌شود — برای سررسیدهای روزشمار کافی است */
        val REPEAT_INTERVAL_HOURS = 24L

        /**
         * زمان‌بندی خودکار.
         *
         * `KEEP` یعنی اگر کار از قبل زمان‌بندی شده باشد دست نمی‌خوریم، پس با
         * هر بار باز شدن برنامه شمارش از نو شروع نمی‌شود. هیچ اقدام دستی از
         * سمت کاربر لازم نیست — این متد از `Application.onCreate` صدا زده می‌شود.
         */
        fun schedule(context: Context) {
            val periodic = PeriodicWorkRequestBuilder<FollowUpWorker>(
                REPEAT_INTERVAL_HOURS, TimeUnit.HOURS
            )
                .setBackoffCriteria(
                    androidx.work.BackoffPolicy.EXPONENTIAL,
                    BACKOFF_MINUTES, TimeUnit.MINUTES
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                PERIODIC_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                periodic
            )
        }

        /**
         * یک بررسی فوری — وقتی برنامه باز می‌شود تا کاربر برای دیدن هشدار
         * تازه تا اجرای بعدیِ کار دوره‌ای منتظر نماند.
         */
        fun runNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<FollowUpWorker>().build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                ONE_SHOT_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        private const val BACKOFF_MINUTES = 15L
    }
}
