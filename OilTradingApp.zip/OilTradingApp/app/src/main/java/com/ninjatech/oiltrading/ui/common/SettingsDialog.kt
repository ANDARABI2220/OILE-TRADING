package com.ninjatech.oiltrading.ui.common

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.activityViewModels
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.ninjatech.oiltrading.OilTradingApplication
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.databinding.DialogSettingsBinding
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModel
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModelFactory
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.parseAmountOrNull

/** تنظیمات: نام تجارت‌خانه، واحد پول و ضریب تبدیل تن به لیتر */
class SettingsDialog : DialogFragment() {

    private var _binding: DialogSettingsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TradeViewModel by activityViewModels {
        val app = requireActivity().application as OilTradingApplication
        TradeViewModelFactory(app.repository, app.alertRepository, app.prefs)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogSettingsBinding.inflate(layoutInflater)

        binding.etBusiness.setText(viewModel.businessName)
        binding.etCurrency.setText(viewModel.currency)
        binding.etLitersPerTon.setText(Format.number(viewModel.litersPerTon, 0, persianDigits = false))

        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.settings)
            .setView(binding.root)
            .setPositiveButton(R.string.save, null) // رفتارش در setOnShowListener جایگزین می‌شود
            .setNegativeButton(R.string.cancel, null)
            .create()

        // دکمهٔ ذخیره نباید دیالوگ را ببندد مگر اینکه ورودی معتبر باشد.
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (saveIfValid()) dialog.dismiss()
            }
        }

        return dialog
    }

    private fun saveIfValid(): Boolean {
        val business = binding.etBusiness.text?.toString()?.trim().orEmpty()
        val currency = binding.etCurrency.text?.toString()?.trim().orEmpty()
        val litersPerTon = binding.etLitersPerTon.text?.toString()?.parseAmountOrNull()

        binding.tilBusiness.error = null
        binding.tilCurrency.error = null
        binding.tilLitersPerTon.error = null

        var valid = true

        if (business.isEmpty()) {
            binding.tilBusiness.error = getString(R.string.error_required)
            valid = false
        }
        if (currency.isEmpty()) {
            binding.tilCurrency.error = getString(R.string.error_required)
            valid = false
        }
        if (litersPerTon == null || litersPerTon < 100 || litersPerTon > 5000) {
            binding.tilLitersPerTon.error = getString(R.string.error_liters_per_ton)
            valid = false
        }

        if (!valid) return false

        viewModel.updateSettings(litersPerTon!!, currency, business)
        return true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val TAG = "SettingsDialog"

        fun show(manager: FragmentManager) {
            SettingsDialog().show(manager, TAG)
        }
    }
}
