package com.ninjatech.oiltrading.ui.alerts

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.ninjatech.oiltrading.OilTradingApplication
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.alerts.FollowUpWorker
import com.ninjatech.oiltrading.databinding.FragmentAlertsBinding
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModel
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModelFactory
import com.ninjatech.oiltrading.util.Format

/**
 * فهرست یادآوری‌های پیگیری — اعلان درون‌برنامه‌ای.
 *
 * این صفحه بدون وابستگی به مجوز اعلان کار می‌کند: هشدارها در پایگاه داده ثبت
 * می‌شوند و همیشه اینجا دیده می‌شوند، حتی اگر کاربر اعلان سیستمی را رد کرده باشد.
 */
class AlertsFragment : Fragment() {

    private var _binding: FragmentAlertsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TradeViewModel by activityViewModels {
        val app = requireActivity().application as OilTradingApplication
        TradeViewModelFactory(app.repository, app.alertRepository, app.prefs)
    }

    private lateinit var adapter: AlertAdapter

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        renderPermissionBanner()
        if (granted) {
            // حالا که اجازه داریم، هشدارهای منتظر اعلان را بفرست
            FollowUpWorker.runNow(requireContext())
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAlertsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = AlertAdapter(onAcknowledge = { viewModel.acknowledgeAlert(it.id) })
        binding.rvAlerts.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@AlertsFragment.adapter
        }

        binding.emptyState.tvEmptyTitle.setText(R.string.alerts_empty_title)
        binding.emptyState.tvEmptyBody.setText(R.string.alerts_empty_body)
        binding.emptyState.ivEmptyIcon.setImageResource(R.drawable.ic_bell)

        binding.btnAcknowledgeAll.setOnClickListener { viewModel.acknowledgeAllAlerts() }
        binding.btnGrantPermission.setOnClickListener { requestNotificationPermission() }

        viewModel.activeAlerts.observe(viewLifecycleOwner) { alerts ->
            adapter.submitList(alerts)

            val isEmpty = alerts.isEmpty()
            binding.emptyState.root.visibility = if (isEmpty) View.VISIBLE else View.GONE
            binding.rvAlerts.visibility = if (isEmpty) View.GONE else View.VISIBLE
            binding.btnAcknowledgeAll.visibility = if (isEmpty) View.GONE else View.VISIBLE
            binding.tvHeader.text = getString(
                R.string.alert_banner_title,
                Format.number(alerts.size.toDouble(), 0)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        renderPermissionBanner()
    }

    private fun renderPermissionBanner() {
        val app = requireActivity().application as OilTradingApplication
        val needsPermission = !app.notifier.canPostNotifications()
        binding.permissionCard.visibility = if (needsPermission) View.VISIBLE else View.GONE
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding.rvAlerts.adapter = null
        _binding = null
    }
}
