package com.ninjatech.oiltrading.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale
import com.ninjatech.oiltrading.data.entity.TradeAlert
import com.ninjatech.oiltrading.data.repo.AlertRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository.TradeInput
import com.ninjatech.oiltrading.domain.FinancialReport
import com.ninjatech.oiltrading.domain.ProfitCalculator
import com.ninjatech.oiltrading.domain.SaleWithProfit
import com.ninjatech.oiltrading.domain.TradeSummary
import com.ninjatech.oiltrading.domain.TradeType
import com.ninjatech.oiltrading.util.AppPrefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * ViewModel مشترک بین همهٔ صفحه‌ها (داشبورد، خریدها، فروش‌ها، گزارش، هشدارها).
 *
 * چون همهٔ صفحه‌ها به یک مجموعه داده نگاه می‌کنند، یک ViewModel در دامنهٔ
 * Activity نگه داشته می‌شود تا محاسبات تکراری انجام نشود.
 */
class TradeViewModel(
    private val repository: TradeRepository,
    private val alertRepository: AlertRepository,
    private val prefs: AppPrefs
) : ViewModel() {

    /** پیام‌های یک‌بارمصرف برای نمایش در Snackbar */
    private val _message = MutableLiveData<Event<String>>()
    val message: LiveData<Event<String>> = _message

    private val purchaseQuery = MutableStateFlow("")
    private val saleQuery = MutableStateFlow("")

    /** بازهٔ زمانی گزارش (شروع، پایان) — null یعنی «از ابتدا تا کنون» */
    private val reportRange = MutableStateFlow<Pair<Long, Long>?>(null)

    val litersPerTon: Double get() = prefs.litersPerTon
    val currency: String get() = prefs.currency
    val businessName: String get() = prefs.businessName

    // ------------------------------------------------------------ داشبورد

    val summary: LiveData<TradeSummary> =
        repository.calculation.map { it.summary }.asLiveData()

    // ------------------------------------------------------------ کالاها

    val assets: LiveData<List<Asset>> = repository.assets.asLiveData()

    // ------------------------------------------------------------ هشدارها

    /** هشدارهای بازِ پیگیری — نوار اعلان درون‌برنامه‌ای از این تغذیه می‌شود */
    val activeAlerts: LiveData<List<TradeAlert>> = alertRepository.activeAlerts.asLiveData()

    fun acknowledgeAlert(alertId: Long) = viewModelScope.launch {
        alertRepository.acknowledge(alertId)
    }

    fun acknowledgeAllAlerts() = viewModelScope.launch {
        alertRepository.acknowledgeAll()
        _message.value = Event(MSG_ALERTS_CLEARED)
    }

    // ------------------------------------------------------------ خریدها

    val purchases: LiveData<List<Purchase>> =
        combine(repository.purchases, purchaseQuery) { list, query ->
            if (query.isBlank()) list else list.filter { it.matches(query) }
        }.asLiveData()

    val sellerNames: LiveData<List<String>> = repository.sellerNames.asLiveData()

    fun setPurchaseQuery(query: String) {
        purchaseQuery.value = query
    }

    // ------------------------------------------------------------ فروش‌ها

    val salesWithProfit: LiveData<List<SaleWithProfit>> =
        combine(repository.salesWithProfit, saleQuery) { list, query ->
            if (query.isBlank()) list else list.filter { it.sale.matches(query) }
        }.asLiveData()

    val buyerNames: LiveData<List<String>> = repository.buyerNames.asLiveData()

    fun setSaleQuery(query: String) {
        saleQuery.value = query
    }

    // ------------------------------------------------------------ گزارش

    val report: LiveData<FinancialReport> = combine(
        repository.purchases,
        repository.calculation,
        reportRange
    ) { allPurchases, calculation, range ->
        val from = range?.first ?: Long.MIN_VALUE
        val to = range?.second ?: Long.MAX_VALUE

        val purchases = allPurchases.filter { it.tradedAt in from..to }
        val sales = calculation.salesWithProfit.filter { it.sale.tradedAt in from..to }

        // خلاصهٔ بازه: خریدها و فروش‌های داخل بازه، اما بهای تمام‌شده از
        // محاسبهٔ سراسری می‌آید تا مفاد هر فروش درست بماند.
        val rangeSummary = if (range == null) {
            calculation.summary
        } else {
            calculation.summary.copy(
                totalPurchasedLiters = purchases.sumOf { it.quantityLiters },
                totalSoldLiters = sales.sumOf { it.sale.quantityLiters },
                totalPurchaseCost = purchases.sumOf { it.totalPrice },
                totalSaleRevenue = sales.sumOf { it.sale.totalPrice },
                totalCogs = sales.sumOf { it.costOfGoodsSold },
                totalProfit = sales.sumOf { it.profit },
                purchaseCount = purchases.size,
                saleCount = sales.size,
                hasOversell = sales.any { it.oversold }
            )
        }

        FinancialReport(
            fromDate = range?.first ?: (purchases.minOfOrNull { it.tradedAt } ?: 0L),
            toDate = range?.second ?: System.currentTimeMillis(),
            purchases = purchases,
            salesWithProfit = sales,
            summary = rangeSummary,
            topSellers = ProfitCalculator.sellerTotals(purchases),
            topBuyers = ProfitCalculator.buyerTotals(sales)
        )
    }.asLiveData()

    fun setReportRange(from: Long?, to: Long?) {
        reportRange.value = if (from == null || to == null) null else from to to
    }

    // ------------------------------------------------------------ ثبت معامله

    /**
     * ثبت یا ویرایش یک معامله. نوع معامله تعیین می‌کند به کدام جدول می‌رود.
     */
    fun saveTrade(
        type: TradeType,
        existingId: Long?,
        input: TradeInput
    ) = viewModelScope.launch {
        runCatching {
            when {
                type == TradeType.PURCHASE && existingId == null -> repository.addPurchase(input)
                type == TradeType.PURCHASE -> repository.updatePurchaseById(existingId!!, input)
                existingId == null -> repository.addSale(input)
                else -> repository.updateSaleById(existingId, input)
            }
        }.onSuccess {
            _message.value = Event(successMessage(type, existingId == null))
        }.onFailure {
            _message.value = Event("$MSG_ERROR ${it.message ?: ""}".trim())
        }
    }

    fun deletePurchase(purchase: Purchase) = viewModelScope.launch {
        runCatching { repository.deletePurchase(purchase) }
            .onSuccess { _message.value = Event(MSG_PURCHASE_DELETED) }
            .onFailure { _message.value = Event("$MSG_ERROR ${it.message ?: ""}".trim()) }
    }

    fun deleteSale(sale: Sale) = viewModelScope.launch {
        runCatching { repository.deleteSale(sale) }
            .onSuccess { _message.value = Event(MSG_SALE_DELETED) }
            .onFailure { _message.value = Event("$MSG_ERROR ${it.message ?: ""}".trim()) }
    }

    // ------------------------------------------------------------ تنظیمات

    fun updateSettings(litersPerTon: Double, currency: String, businessName: String) {
        prefs.litersPerTon = litersPerTon
        prefs.currency = currency
        prefs.businessName = businessName
        _message.value = Event(MSG_SETTINGS_SAVED)
    }

    // ------------------------------------------------------------ کمکی

    private fun successMessage(type: TradeType, isNew: Boolean): String = when {
        type == TradeType.PURCHASE && isNew -> MSG_PURCHASE_ADDED
        type == TradeType.PURCHASE -> MSG_PURCHASE_UPDATED
        isNew -> MSG_SALE_ADDED
        else -> MSG_SALE_UPDATED
    }

    private fun Purchase.matches(query: String): Boolean {
        val q = query.trim()
        return sellerName.value.contains(q, ignoreCase = true) ||
            note.value.contains(q, ignoreCase = true) ||
            referenceNo.value.contains(q, ignoreCase = true)
    }

    private fun Sale.matches(query: String): Boolean {
        val q = query.trim()
        return buyerName.value.contains(q, ignoreCase = true) ||
            note.value.contains(q, ignoreCase = true) ||
            referenceNo.value.contains(q, ignoreCase = true)
    }

    /** پیام یک‌بارمصرف — از نمایش دوبارهٔ Snackbar بعد از چرخش صفحه جلوگیری می‌کند */
    class Event<T>(private val content: T) {
        private var handled = false

        fun getIfNotHandled(): T? = if (handled) null else {
            handled = true
            content
        }
    }

    companion object {
        const val MSG_PURCHASE_ADDED = "خرید ثبت شد"
        const val MSG_PURCHASE_UPDATED = "خرید ویرایش شد"
        const val MSG_PURCHASE_DELETED = "خرید حذف شد"
        const val MSG_SALE_ADDED = "فروش ثبت شد"
        const val MSG_SALE_UPDATED = "فروش ویرایش شد"
        const val MSG_SALE_DELETED = "فروش حذف شد"
        const val MSG_SETTINGS_SAVED = "تنظیمات ذخیره شد"
        const val MSG_ALERTS_CLEARED = "همهٔ هشدارها بسته شد"
        const val MSG_ERROR = "خطا:"
    }
}

/** سازندهٔ ViewModel — وابستگی‌ها را از Application می‌گیرد */
class TradeViewModelFactory(
    private val repository: TradeRepository,
    private val alertRepository: AlertRepository,
    private val prefs: AppPrefs
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        require(modelClass.isAssignableFrom(TradeViewModel::class.java)) {
            "ViewModel ناشناخته: ${modelClass.name}"
        }
        return TradeViewModel(repository, alertRepository, prefs) as T
    }
}
