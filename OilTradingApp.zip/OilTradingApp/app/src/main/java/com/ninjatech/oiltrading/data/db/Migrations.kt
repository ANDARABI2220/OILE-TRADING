package com.ninjatech.oiltrading.data.db

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ninjatech.oiltrading.data.crypto.FieldEncryptor
import com.ninjatech.oiltrading.data.entity.Asset

/**
 * مهاجرت نسخهٔ ۱ به ۲ — افزودن ماژول کامل معاملات و سیستم هشدار.
 *
 * چه چیزی عوض می‌شود:
 *  - جدول جدید `assets` (شناسهٔ یکتای کالا) + مقادیر پیش‌فرض
 *  - جدول جدید `trade_alerts` با ایندکس یکتا برای جلوگیری از هشدار تکراری
 *  - ستون‌های جدید روی `purchases` و `sales`:
 *    `asset_id` (کلید خارجی)، `currency`، `follow_up_date`، `reference_no`، `updated_at`
 *  - رمزنگاری داده‌های موجودِ `seller_name` / `buyer_name` / `note`
 *
 * چون SQLite اجازهٔ افزودن کلید خارجی به جدول موجود را نمی‌دهد، جدول‌ها
 * بازسازی و داده‌ها منتقل می‌شوند. این کار داخل همان تراکنشی انجام می‌شود که
 * Room برای مهاجرت باز می‌کند، پس یا همه‌اش انجام می‌شود یا هیچ‌کدام.
 */
class MigrationV1ToV2(private val encryptor: FieldEncryptor) : Migration(1, 2) {

    override fun migrate(db: SupportSQLiteDatabase) {
        createAssets(db)
        createTradeAlerts(db)
        rebuildPurchases(db)
        rebuildSales(db)
        encryptExistingRows(db)
    }

    // ------------------------------------------------------------ جدول‌های جدید

    private fun createAssets(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `assets` (
                `id` TEXT NOT NULL,
                `name` TEXT NOT NULL,
                `grade` TEXT NOT NULL,
                `liters_per_ton` REAL NOT NULL,
                `active` INTEGER NOT NULL,
                `created_at` INTEGER NOT NULL,
                PRIMARY KEY(`id`)
            )
            """.trimIndent()
        )
        seedAssets(db)
    }

    private fun createTradeAlerts(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `trade_alerts` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `trade_kind` TEXT NOT NULL,
                `trade_id` INTEGER NOT NULL,
                `alert_type` TEXT NOT NULL,
                `due_date` INTEGER NOT NULL,
                `counterparty` TEXT NOT NULL,
                `amount` REAL NOT NULL,
                `currency` TEXT NOT NULL,
                `created_at` INTEGER NOT NULL,
                `notified_at` INTEGER,
                `acknowledged` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS " +
                "`index_trade_alerts_trade_kind_trade_id_alert_type` " +
                "ON `trade_alerts` (`trade_kind`, `trade_id`, `alert_type`)"
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_trade_alerts_notified_at` " +
                "ON `trade_alerts` (`notified_at`)"
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_trade_alerts_due_date` " +
                "ON `trade_alerts` (`due_date`)"
        )
    }

    // ------------------------------------------------------------ بازسازی جدول‌ها

    private fun rebuildPurchases(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `purchases_new` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `seller_name` TEXT NOT NULL,
                `asset_id` TEXT NOT NULL,
                `quantity` REAL NOT NULL,
                `unit` TEXT NOT NULL,
                `quantity_liters` REAL NOT NULL,
                `price_per_unit` REAL NOT NULL,
                `total_price` REAL NOT NULL,
                `currency` TEXT NOT NULL,
                `purchase_date` INTEGER NOT NULL,
                `follow_up_date` INTEGER,
                `reference_no` TEXT NOT NULL,
                `note` TEXT NOT NULL,
                `created_at` INTEGER NOT NULL,
                `updated_at` INTEGER NOT NULL,
                FOREIGN KEY(`asset_id`) REFERENCES `assets`(`id`)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            INSERT INTO `purchases_new` (
                id, seller_name, asset_id, quantity, unit, quantity_liters,
                price_per_unit, total_price, currency, purchase_date,
                follow_up_date, reference_no, note, created_at, updated_at
            )
            SELECT
                id, seller_name, '${Asset.DIESEL}', quantity, unit, quantity_liters,
                price_per_unit, total_price, '$DEFAULT_CURRENCY', purchase_date,
                NULL, '', note, created_at, created_at
            FROM `purchases`
            """.trimIndent()
        )
        db.execSQL("DROP TABLE `purchases`")
        db.execSQL("ALTER TABLE `purchases_new` RENAME TO `purchases`")

        db.execSQL("CREATE INDEX IF NOT EXISTS `index_purchases_purchase_date` ON `purchases` (`purchase_date`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_purchases_asset_id` ON `purchases` (`asset_id`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_purchases_follow_up_date` ON `purchases` (`follow_up_date`)")
    }

    private fun rebuildSales(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `sales_new` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `buyer_name` TEXT NOT NULL,
                `asset_id` TEXT NOT NULL,
                `quantity` REAL NOT NULL,
                `unit` TEXT NOT NULL,
                `quantity_liters` REAL NOT NULL,
                `price_per_unit` REAL NOT NULL,
                `total_price` REAL NOT NULL,
                `currency` TEXT NOT NULL,
                `sale_date` INTEGER NOT NULL,
                `follow_up_date` INTEGER,
                `reference_no` TEXT NOT NULL,
                `note` TEXT NOT NULL,
                `created_at` INTEGER NOT NULL,
                `updated_at` INTEGER NOT NULL,
                FOREIGN KEY(`asset_id`) REFERENCES `assets`(`id`)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            INSERT INTO `sales_new` (
                id, buyer_name, asset_id, quantity, unit, quantity_liters,
                price_per_unit, total_price, currency, sale_date,
                follow_up_date, reference_no, note, created_at, updated_at
            )
            SELECT
                id, buyer_name, '${Asset.DIESEL}', quantity, unit, quantity_liters,
                price_per_unit, total_price, '$DEFAULT_CURRENCY', sale_date,
                NULL, '', note, created_at, created_at
            FROM `sales`
            """.trimIndent()
        )
        db.execSQL("DROP TABLE `sales`")
        db.execSQL("ALTER TABLE `sales_new` RENAME TO `sales`")

        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sales_sale_date` ON `sales` (`sale_date`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sales_asset_id` ON `sales` (`asset_id`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sales_follow_up_date` ON `sales` (`follow_up_date`)")
    }

    // ------------------------------------------------------------ رمزنگاری داده‌های قدیمی

    /**
     * مقادیر متن‌سادهٔ نسخهٔ ۱ را رمز می‌کند.
     *
     * رکوردهایی که به هر دلیل قبلاً رمز شده‌اند رد می‌شوند، بنابراین اجرای
     * دوبارهٔ این مرحله بی‌خطر است.
     */
    private fun encryptExistingRows(db: SupportSQLiteDatabase) {
        encryptColumns(db, "purchases", listOf("seller_name", "note"))
        encryptColumns(db, "sales", listOf("buyer_name", "note"))
    }

    private fun encryptColumns(
        db: SupportSQLiteDatabase,
        table: String,
        columns: List<String>
    ) {
        val projection = (listOf("id") + columns).joinToString(", ") { "`$it`" }
        db.query("SELECT $projection FROM `$table`").use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                val updates = mutableListOf<String>()
                val values = mutableListOf<Any?>()

                columns.forEachIndexed { index, column ->
                    val current = cursor.getString(index + 1) ?: ""
                    if (!FieldEncryptor.isEncrypted(current)) {
                        updates += "`$column` = ?"
                        values += encryptor.encrypt(current)
                    }
                }

                if (updates.isNotEmpty()) {
                    values += id
                    db.execSQL(
                        "UPDATE `$table` SET ${updates.joinToString(", ")} WHERE `id` = ?",
                        values.toTypedArray()
                    )
                }
            }
        }
    }

    private companion object {
        const val DEFAULT_CURRENCY = "AFN"

        fun seedAssets(db: SupportSQLiteDatabase) {
            Asset.defaults().forEach { asset ->
                db.execSQL(
                    "INSERT OR IGNORE INTO `assets` " +
                        "(`id`, `name`, `grade`, `liters_per_ton`, `active`, `created_at`) " +
                        "VALUES (?, ?, ?, ?, ?, ?)",
                    arrayOf(
                        asset.id,
                        asset.name,
                        asset.grade,
                        asset.litersPerTon,
                        if (asset.active) 1 else 0,
                        asset.createdAt
                    )
                )
            }
        }
    }
}
