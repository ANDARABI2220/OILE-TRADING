package com.ninjatech.oiltrading.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.ninjatech.oiltrading.data.entity.Asset
import com.ninjatech.oiltrading.data.entity.TradeAlert
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(assets: List<Asset>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(asset: Asset)

    @Query("SELECT * FROM assets WHERE active = 1 ORDER BY name ASC")
    fun observeActive(): Flow<List<Asset>>

    @Query("SELECT * FROM assets ORDER BY name ASC")
    suspend fun getAll(): List<Asset>

    @Query("SELECT * FROM assets WHERE id = :id")
    suspend fun findById(id: String): Asset?

    @Query("SELECT COUNT(*) FROM assets")
    suspend fun count(): Int
}

@Dao
interface TradeAlertDao {

    /**
     * ثبت هشدار جدید.
     *
     * `IGNORE` به‌همراه ایندکس یکتای (trade_kind, trade_id, alert_type) یعنی
     * تلاش دوم برای ثبت هشدارِ همان معامله بی‌سروصدا نادیده گرفته می‌شود و
     * `-1` برمی‌گرداند — سنگ‌بنای جلوگیری از اعلان تکراری.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(alert: TradeAlert): Long

    @Query("SELECT * FROM trade_alerts ORDER BY due_date ASC, id ASC")
    fun observeAll(): Flow<List<TradeAlert>>

    /** هشدارهایی که کاربر هنوز نبسته است — همان چیزی که در برنامه نشان داده می‌شود */
    @Query("SELECT * FROM trade_alerts WHERE acknowledged = 0 ORDER BY due_date ASC, id ASC")
    fun observeUnacknowledged(): Flow<List<TradeAlert>>

    /** هشدارهایی که ساخته شده‌اند ولی هنوز اعلانشان ارسال نشده */
    @Query("SELECT * FROM trade_alerts WHERE notified_at IS NULL ORDER BY due_date ASC, id ASC")
    suspend fun findPendingNotification(): List<TradeAlert>

    @Query("SELECT * FROM trade_alerts WHERE id = :id")
    suspend fun findById(id: Long): TradeAlert?

    @Query(
        """
        SELECT COUNT(*) FROM trade_alerts
        WHERE trade_kind = :kind AND trade_id = :tradeId AND alert_type = :alertType
        """
    )
    suspend fun countFor(kind: String, tradeId: Long, alertType: String): Int

    @Query("UPDATE trade_alerts SET notified_at = :timestamp WHERE id IN (:ids)")
    suspend fun markNotified(ids: List<Long>, timestamp: Long)

    @Query("UPDATE trade_alerts SET acknowledged = 1 WHERE id = :id")
    suspend fun acknowledge(id: Long)

    @Query("UPDATE trade_alerts SET acknowledged = 1 WHERE acknowledged = 0")
    suspend fun acknowledgeAll()

    /** پاک‌کردن هشدارهای معامله‌ای که حذف شده است */
    @Query("DELETE FROM trade_alerts WHERE trade_kind = :kind AND trade_id = :tradeId")
    suspend fun deleteForTrade(kind: String, tradeId: Long)

    @Query("SELECT COUNT(*) FROM trade_alerts")
    suspend fun count(): Int

    @Query("DELETE FROM trade_alerts")
    suspend fun deleteAll()
}
