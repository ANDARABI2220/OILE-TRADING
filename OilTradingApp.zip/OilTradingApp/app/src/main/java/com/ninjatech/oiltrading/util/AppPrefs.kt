package com.ninjatech.oiltrading.util

import android.content.Context
import android.content.SharedPreferences

/**
 * تنظیمات اپلیکیشن.
 *
 * مهم‌ترین تنظیم، **ضریب تبدیل تن به لیتر** است. چون چگالی تیل بسته به نوع آن
 * فرق می‌کند (دیزل حدود ۰٫۸۴، پترول حدود ۰٫۷۵)، اگر معامله‌ای با واحد «تن» و
 * معامله‌ای دیگر با واحد «لیتر» ثبت شود، بدون این ضریب محاسبهٔ موجودی غلط
 * خواهد بود. مقدار پیش‌فرض برای دیزل تنظیم شده است.
 */
class AppPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    /** چند لیتر در یک تن — قابل تغییر توسط کاربر بر اساس نوع تیل */
    var litersPerTon: Double
        get() = prefs.getFloat(KEY_LITERS_PER_TON, DEFAULT_LITERS_PER_TON.toFloat()).toDouble()
        set(value) = prefs.edit().putFloat(KEY_LITERS_PER_TON, value.toFloat()).apply()

    /** واحد پول نمایشی */
    var currency: String
        get() = prefs.getString(KEY_CURRENCY, DEFAULT_CURRENCY) ?: DEFAULT_CURRENCY
        set(value) = prefs.edit().putString(KEY_CURRENCY, value).apply()

    /** نام کسب‌وکار — در گزارش‌ها استفاده می‌شود */
    var businessName: String
        get() = prefs.getString(KEY_BUSINESS, DEFAULT_BUSINESS) ?: DEFAULT_BUSINESS
        set(value) = prefs.edit().putString(KEY_BUSINESS, value).apply()

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    companion object {
        private const val FILE_NAME = "oil_trading_prefs"
        private const val KEY_LITERS_PER_TON = "liters_per_ton"
        private const val KEY_CURRENCY = "currency"
        private const val KEY_BUSINESS = "business_name"

        /** دیزل: چگالی ≈ ۰٫۸۴ kg/L → ۱ تن ≈ ۱۱۹۰ لیتر */
        const val DEFAULT_LITERS_PER_TON = 1190.0
        const val DEFAULT_CURRENCY = "افغانی"
        const val DEFAULT_BUSINESS = "تجارت تیل حیرتان"
    }
}
