package com.ninjatech.oiltrading.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** کدام نوع معامله این هشدار را ساخته است */
enum class TradeKind(val dbValue: String) {
    PURCHASE("purchase"),
    SALE("sale");

    companion object {
        fun fromDb(value: String?): TradeKind =
            entries.firstOrNull { it.dbValue == value } ?: PURCHASE
    }
}

/** نوع هشدار — فعلاً فقط یادآوری سررسید پیگیری، اما ساختار برای انواع بعدی باز است */
enum class AlertType(val dbValue: String) {
    FOLLOW_UP_DUE("follow_up_due");

    companion object {
        fun fromDb(value: String?): AlertType =
            entries.firstOrNull { it.dbValue == value } ?: FOLLOW_UP_DUE
    }
}

/**
 * یک هشدار ثبت‌شده برای یک معاملهٔ مشخص.
 *
 * ایندکس **یکتا** روی (`trade_kind`, `trade_id`, `alert_type`) تضمین می‌کند که
 * برای یک معامله بیش از یک بار هشدار ساخته نشود — این همان سازوکار جلوگیری از
 * اعلان تکراری است و چون در سطح پایگاه داده اعمال می‌شود، حتی اگر سرویس
 * پس‌زمینه دوبار همزمان اجرا شود هم تکراری ثبت نمی‌شود.
 */
@Entity(
    tableName = "trade_alerts",
    indices = [
        Index(value = ["trade_kind", "trade_id", "alert_type"], unique = true),
        Index("notified_at"),
        Index("due_date")
    ]
)
data class TradeAlert(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "trade_kind")
    val tradeKind: String,

    /** شناسهٔ خرید یا فروش مرتبط */
    @ColumnInfo(name = "trade_id")
    val tradeId: Long,

    @ColumnInfo(name = "alert_type")
    val alertType: String = AlertType.FOLLOW_UP_DUE.dbValue,

    /** تاریخ سررسیدی که این هشدار دربارهٔ آن است */
    @ColumnInfo(name = "due_date")
    val dueDate: Long,

    /** نام طرف حساب در لحظهٔ ساخت هشدار — برای نمایش بدون نیاز به join */
    @ColumnInfo(name = "counterparty")
    val counterparty: String,

    /** مبلغ معامله در لحظهٔ ساخت هشدار */
    @ColumnInfo(name = "amount")
    val amount: Double,

    @ColumnInfo(name = "currency")
    val currency: String,

    /** زمان ساخت رکورد هشدار */
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    /** زمان ارسال اعلان — null یعنی هنوز به کاربر نشان داده نشده */
    @ColumnInfo(name = "notified_at")
    val notifiedAt: Long? = null,

    /** کاربر هشدار را دیده و بسته است */
    @ColumnInfo(name = "acknowledged")
    val acknowledged: Boolean = false
) {
    val kind: TradeKind get() = TradeKind.fromDb(tradeKind)
    val type: AlertType get() = AlertType.fromDb(alertType)

    /** هنوز اعلانی برایش فرستاده نشده است */
    val isPending: Boolean get() = notifiedAt == null
}
