package com.ninjatech.oiltrading.domain

import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale

/**
 * محاسبهٔ موجودی و مفاد با روش **میانگین متحرک موزون** (Moving Weighted Average).
 *
 * چرا این روش؟ اگر مفاد را صرفاً «کل فروش منهای کل خرید» حساب کنیم، هر بار که
 * جنس می‌خریم و هنوز نفروخته‌ایم اپلیکیشن ضرر نشان می‌دهد — که غلط است.
 * در این روش هر معاملهٔ خرید میانگین بهای تمام‌شدهٔ انبار را به‌روز می‌کند و
 * مفاد هر فروش برابر است با: مبلغ فروش منهای (مقدار فروخته‌شده × میانگین بهای
 * تمام‌شدهٔ همان لحظه).
 *
 * همهٔ محاسبات روی واحد پایه (**لیتر**) انجام می‌شود تا معاملات تن و لیتر با هم
 * قابل جمع باشند.
 */
object ProfitCalculator {

    private const val EPSILON = 1e-9

    private sealed interface Event {
        val time: Long
        val seq: Long

        data class Buy(val purchase: Purchase) : Event {
            override val time: Long get() = purchase.tradedAt
            override val seq: Long get() = purchase.id
        }

        data class Sell(val sale: Sale) : Event {
            override val time: Long get() = sale.tradedAt
            override val seq: Long get() = sale.id
        }
    }

    data class Result(
        val summary: TradeSummary,
        /** به ترتیب نزولی تاریخ — آمادهٔ نمایش در لیست */
        val salesWithProfit: List<SaleWithProfit>
    )

    /**
     * معاملات را به ترتیب زمانی پردازش می‌کند و خلاصه به‌همراه مفاد هر فروش را برمی‌گرداند.
     */
    fun calculate(purchases: List<Purchase>, sales: List<Sale>): Result {
        val events = ArrayList<Event>(purchases.size + sales.size)
        purchases.mapTo(events) { Event.Buy(it) }
        sales.mapTo(events) { Event.Sell(it) }

        // خریدِ همان روز پیش از فروشِ همان روز پردازش می‌شود تا موجودی منفیِ کاذب نداشته باشیم.
        events.sortWith(
            compareBy<Event> { it.time }
                .thenBy { if (it is Event.Buy) 0 else 1 }
                .thenBy { it.seq }
        )

        var stockLiters = 0.0
        var inventoryValue = 0.0
        var totalPurchasedLiters = 0.0
        var totalSoldLiters = 0.0
        var totalPurchaseCost = 0.0
        var totalRevenue = 0.0
        var totalCogs = 0.0
        var hasOversell = false
        var lastKnownUnitCost = 0.0

        val salesWithProfit = ArrayList<SaleWithProfit>(sales.size)

        for (event in events) {
            when (event) {
                is Event.Buy -> {
                    val p = event.purchase
                    stockLiters += p.quantityLiters
                    inventoryValue += p.totalPrice
                    totalPurchasedLiters += p.quantityLiters
                    totalPurchaseCost += p.totalPrice
                    if (stockLiters > EPSILON) {
                        lastKnownUnitCost = inventoryValue / stockLiters
                    }
                }

                is Event.Sell -> {
                    val s = event.sale

                    // موجودی صفر است؟ آخرین بهای تمام‌شدهٔ شناخته‌شده را مبنا می‌گیریم.
                    val unitCost =
                        if (stockLiters > EPSILON) inventoryValue / stockLiters
                        else lastKnownUnitCost

                    val oversold = s.quantityLiters > stockLiters + EPSILON
                    if (oversold) hasOversell = true

                    val cogs = unitCost * s.quantityLiters
                    val profit = s.totalPrice - cogs

                    stockLiters -= s.quantityLiters
                    inventoryValue -= cogs

                    // اگر انبار خالی (یا منفی) شد، ارزش باقیمانده را صفر می‌کنیم
                    // تا خطای ممیز شناور انباشته نشود.
                    if (stockLiters <= EPSILON) {
                        inventoryValue = 0.0
                    }

                    totalSoldLiters += s.quantityLiters
                    totalRevenue += s.totalPrice
                    totalCogs += cogs
                    if (unitCost > 0.0) lastKnownUnitCost = unitCost

                    salesWithProfit += SaleWithProfit(
                        sale = s,
                        costOfGoodsSold = cogs,
                        profit = profit,
                        unitCostPerLiter = unitCost,
                        oversold = oversold
                    )
                }
            }
        }

        val summary = TradeSummary(
            totalPurchasedLiters = totalPurchasedLiters,
            totalSoldLiters = totalSoldLiters,
            stockLiters = stockLiters,
            totalPurchaseCost = totalPurchaseCost,
            totalSaleRevenue = totalRevenue,
            totalCogs = totalCogs,
            totalProfit = totalRevenue - totalCogs,
            inventoryValue = inventoryValue,
            averageCostPerLiter =
                if (stockLiters > EPSILON) inventoryValue / stockLiters else lastKnownUnitCost,
            purchaseCount = purchases.size,
            saleCount = sales.size,
            hasOversell = hasOversell
        )

        val ordered = salesWithProfit.sortedWith(
            compareByDescending<SaleWithProfit> { it.sale.tradedAt }
                .thenByDescending { it.sale.id }
        )

        return Result(summary, ordered)
    }

    /** جمع‌بندی خریدها بر اساس نام فروشنده */
    fun sellerTotals(purchases: List<Purchase>): List<PartyTotals> =
        purchases.groupBy { it.sellerName.value.trim() }
            .map { (name, items) ->
                PartyTotals(
                    name = name,
                    transactionCount = items.size,
                    totalLiters = items.sumOf { it.quantityLiters },
                    totalAmount = items.sumOf { it.totalPrice }
                )
            }
            .sortedByDescending { it.totalAmount }

    /** جمع‌بندی فروش‌ها بر اساس نام خریدار، به‌همراه مفاد */
    fun buyerTotals(sales: List<SaleWithProfit>): List<PartyTotals> =
        sales.groupBy { it.sale.buyerName.value.trim() }
            .map { (name, items) ->
                PartyTotals(
                    name = name,
                    transactionCount = items.size,
                    totalLiters = items.sumOf { it.sale.quantityLiters },
                    totalAmount = items.sumOf { it.sale.totalPrice },
                    profit = items.sumOf { it.profit }
                )
            }
            .sortedByDescending { it.totalAmount }
}
