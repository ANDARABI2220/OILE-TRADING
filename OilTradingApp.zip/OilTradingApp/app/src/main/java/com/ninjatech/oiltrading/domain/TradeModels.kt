package com.ninjatech.oiltrading.domain

import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale

/** یک فروش به‌همراه مفاد محاسبه‌شدهٔ آن */
data class SaleWithProfit(
    val sale: Sale,
    /** بهای تمام‌شدهٔ کالای فروخته‌شده (COGS) */
    val costOfGoodsSold: Double,
    /** مفاد = مبلغ فروش − بهای تمام‌شده */
    val profit: Double,
    /** میانگین بهای تمام‌شدهٔ هر لیتر در لحظهٔ این فروش */
    val unitCostPerLiter: Double,
    /** اگر در زمان این فروش موجودی کافی نبوده باشد true است */
    val oversold: Boolean
) {
    /** حاشیهٔ مفاد بر حسب درصد */
    val marginPercent: Double
        get() = if (sale.totalPrice != 0.0) profit / sale.totalPrice * 100.0 else 0.0
}

/** خلاصهٔ کل کسب‌وکار — ورودی داشبورد */
data class TradeSummary(
    val totalPurchasedLiters: Double = 0.0,
    val totalSoldLiters: Double = 0.0,
    val stockLiters: Double = 0.0,
    val totalPurchaseCost: Double = 0.0,
    val totalSaleRevenue: Double = 0.0,
    /** بهای تمام‌شدهٔ کالاهای فروخته‌شده */
    val totalCogs: Double = 0.0,
    /** مفاد واقعی = درآمد فروش − بهای تمام‌شدهٔ همان فروش‌ها */
    val totalProfit: Double = 0.0,
    /** ارزش پولی موجودی انبار */
    val inventoryValue: Double = 0.0,
    /** میانگین بهای تمام‌شدهٔ هر لیتر موجودی فعلی */
    val averageCostPerLiter: Double = 0.0,
    val purchaseCount: Int = 0,
    val saleCount: Int = 0,
    /** آیا جایی بیش از موجودی فروخته شده است؟ */
    val hasOversell: Boolean = false
) {
    val marginPercent: Double
        get() = if (totalSaleRevenue != 0.0) totalProfit / totalSaleRevenue * 100.0 else 0.0

    /** موجودی بر حسب تن، با ضریب تبدیل داده‌شده */
    fun stockInTons(litersPerTon: Double): Double =
        if (litersPerTon > 0) stockLiters / litersPerTon else 0.0
}

/** جمع‌بندی معاملات یک طرف حساب (فروشنده یا خریدار) */
data class PartyTotals(
    val name: String,
    val transactionCount: Int,
    val totalLiters: Double,
    val totalAmount: Double,
    /** فقط برای خریداران پر می‌شود */
    val profit: Double = 0.0
)

/** گزارش مالی یک بازهٔ زمانی */
data class FinancialReport(
    val fromDate: Long,
    val toDate: Long,
    val purchases: List<Purchase>,
    val salesWithProfit: List<SaleWithProfit>,
    val summary: TradeSummary,
    val topSellers: List<PartyTotals>,
    val topBuyers: List<PartyTotals>
)
