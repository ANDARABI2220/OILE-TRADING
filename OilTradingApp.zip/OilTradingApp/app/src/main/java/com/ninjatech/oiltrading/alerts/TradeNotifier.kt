package com.ninjatech.oiltrading.alerts

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ninjatech.oiltrading.MainActivity
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.data.entity.TradeAlert
import com.ninjatech.oiltrading.data.entity.TradeKind
import com.ninjatech.oiltrading.domain.FollowUpPolicy
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.JalaliCalendar

/**
 * ارسال اعلان یادآوری پیگیری.
 *
 * اعلان سیستمی «مکمل» نوار هشدار داخل برنامه است، نه جایگزین آن: هشدار در
 * پایگاه داده ثبت می‌شود و همیشه در برنامه دیده می‌شود، حتی اگر کاربر اجازهٔ
 * اعلان نداده باشد یا اعلان‌ها را خاموش کرده باشد.
 */
class TradeNotifier(private val context: Context) : AlertNotifier {

    private val manager = NotificationManagerCompat.from(context)

    init {
        createChannel()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.alert_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.alert_channel_description)
            setShowBadge(true)
        }
        manager.createNotificationChannel(channel)
    }

    /** آیا اجازهٔ ارسال اعلان داریم؟ روی اندروید ۱۳ به بالا مجوز زمان اجرا لازم است. */
    override fun canPostNotifications(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return manager.areNotificationsEnabled()
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED && manager.areNotificationsEnabled()
    }

    /**
     * اعلان یک هشدار را می‌فرستد.
     *
     * @return true اگر اعلان واقعاً ارسال شد
     */
    override fun notify(alert: TradeAlert, now: Long): Boolean {
        if (!canPostNotifications()) return false

        val days = FollowUpPolicy.daysUntil(alert.dueDate, now)
        val dueDate = JalaliCalendar.fromTimestamp(alert.dueDate).formatLong()
        val amount = Format.money(alert.amount, alert.currency)

        val kindLabel = context.getString(
            if (alert.kind == TradeKind.PURCHASE) R.string.alert_kind_purchase
            else R.string.alert_kind_sale
        )

        val title = context.getString(R.string.alert_notification_title)
        val body = if (days >= 0) {
            context.getString(
                R.string.alert_notification_body,
                kindLabel,
                alert.counterparty,
                amount,
                Format.number(days.toDouble(), 0),
                dueDate
            )
        } else {
            context.getString(
                R.string.alert_notification_body_overdue,
                kindLabel,
                alert.counterparty,
                amount,
                dueDate
            )
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_OPEN_ALERTS, true)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            alert.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        return try {
            manager.notify(NOTIFICATION_ID_BASE + alert.id.toInt(), notification)
            true
        } catch (e: SecurityException) {
            // مجوز بین بررسی و ارسال لغو شده — هشدار در برنامه باقی می‌ماند.
            false
        }
    }

    companion object {
        const val CHANNEL_ID = "trade_follow_up"
        private const val NOTIFICATION_ID_BASE = 1000
    }
}
