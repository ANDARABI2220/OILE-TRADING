package com.ninjatech.oiltrading.ui.purchase

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.databinding.ItemPurchaseBinding
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.JalaliCalendar

class PurchaseAdapter(
    private val currency: () -> String,
    private val onMoreClick: (Purchase, android.view.View) -> Unit
) : ListAdapter<Purchase, PurchaseAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPurchaseBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemPurchaseBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Purchase) = with(binding) {
            tvSeller.text = item.sellerName.value
            tvDate.text = JalaliCalendar.fromTimestamp(item.tradedAt).formatLong()
            tvTotal.text = Format.money(item.totalPrice, currency())
            tvUnitPrice.text = "${Format.number(item.pricePerUnit)} × ${item.oilUnit.label}"
            tvQuantity.text = Format.quantity(item.quantity, item.oilUnit.label)

            if (item.note.value.isBlank()) {
                tvNote.visibility = android.view.View.GONE
            } else {
                tvNote.visibility = android.view.View.VISIBLE
                tvNote.text = item.note.value
            }

            btnMore.setOnClickListener { onMoreClick(item, it) }
            root.setOnClickListener { onMoreClick(item, btnMore) }
        }
    }

    private companion object {
        val DIFF = object : DiffUtil.ItemCallback<Purchase>() {
            override fun areItemsTheSame(oldItem: Purchase, newItem: Purchase) =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Purchase, newItem: Purchase) =
                oldItem == newItem
        }
    }
}
