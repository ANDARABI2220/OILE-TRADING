package com.ninjatech.oiltrading.util

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * تقویم هجری شمسی (خورشیدی) با نام ماه‌های افغانی.
 *
 * پیاده‌سازی بر اساس الگوریتم دقیق «جلالی» (Borkowski) است و برای بازهٔ
 * سال‌های ۱۱۷۸ تا ۱۶۳۳ هجری شمسی نتیجهٔ درست می‌دهد.
 *
 * توجه: SimpleDateFormat با Locale("fa") تاریخ میلادی می‌دهد، نه شمسی؛
 * به همین دلیل تبدیل به‌صورت دستی انجام شده است.
 */
data class JalaliDate(val year: Int, val month: Int, val day: Int) {

    /** شمارهٔ روز در سال (۱ تا ۳۶۵/۳۶۶) */
    val dayOfYear: Int
        get() = if (month <= 6) (month - 1) * 31 + day else 186 + (month - 7) * 30 + day

    /** تبدیل به timestamp میلی‌ثانیه‌ای (ساعت ۱۲ ظهر تا از مشکل منطقهٔ زمانی در امان باشیم) */
    fun toTimestamp(): Long {
        val (gy, gm, gd) = JalaliCalendar.jalaliToGregorian(year, month, day)
        val cal = Calendar.getInstance(TimeZone.getDefault())
        cal.clear()
        cal.set(gy, gm - 1, gd, 12, 0, 0)
        return cal.timeInMillis
    }

    /** خروجی مثل «۱۴۰۴/۰۶/۲۲» */
    fun formatNumeric(persianDigits: Boolean = true): String {
        // Locale.US تا ارقام همیشه لاتین تولید شوند و تبدیل به فارسی در اختیار خودمان باشد
        val s = String.format(Locale.US, "%04d/%02d/%02d", year, month, day)
        return if (persianDigits) s.toPersianDigits() else s
    }

    /** خروجی مثل «۲۲ سنبله ۱۴۰۴» */
    fun formatLong(persianDigits: Boolean = true): String {
        val s = "$day ${JalaliCalendar.monthName(month)} $year"
        return if (persianDigits) s.toPersianDigits() else s
    }

    override fun toString(): String = formatNumeric()
}

object JalaliCalendar {

    /** نام ماه‌های افغانی (رایج در حیرتان و مزارشریف) */
    val AFGHAN_MONTHS = arrayOf(
        "حمل", "ثور", "جوزا", "سرطان", "اسد", "سنبله",
        "میزان", "عقرب", "قوس", "جدی", "دلو", "حوت"
    )

    /** نام ماه‌های ایرانی — در صورت نیاز قابل استفاده است */
    val IRANIAN_MONTHS = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    val WEEK_DAYS = arrayOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")

    fun monthName(month: Int): String = AFGHAN_MONTHS[(month - 1).coerceIn(0, 11)]

    /** تعداد روزهای ماه شمسی */
    fun monthLength(year: Int, month: Int): Int = when {
        month <= 6 -> 31
        month <= 11 -> 30
        isLeapYear(year) -> 30
        else -> 29
    }

    fun isLeapYear(jy: Int): Boolean = jalCal(jy).leap == 0

    // ---------------------------------------------------------------- تبدیل‌ها

    fun fromTimestamp(timestamp: Long): JalaliDate {
        val cal = Calendar.getInstance(TimeZone.getDefault())
        cal.timeInMillis = timestamp
        return gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun today(): JalaliDate = fromTimestamp(System.currentTimeMillis())

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): JalaliDate = d2j(g2d(gy, gm, gd))

    /** خروجی: Triple(سال، ماه، روز) میلادی */
    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Triple<Int, Int, Int> = d2g(j2d(jy, jm, jd))

    /** نام روز هفته برای یک timestamp */
    fun weekDayName(timestamp: Long): String {
        val cal = Calendar.getInstance()
        cal.timeInMillis = timestamp
        // Calendar.SATURDAY = 7 → اندیس ۰ (هفته از شنبه شروع می‌شود)
        val index = cal.get(Calendar.DAY_OF_WEEK) % 7
        return WEEK_DAYS[index]
    }

    // ------------------------------------------------- الگوریتم داخلی (Borkowski)

    private data class JalCal(val leap: Int, val gy: Int, val march: Int)

    private val BREAKS = intArrayOf(
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181,
        1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    )

    private fun jalCal(jy: Int): JalCal {
        val gy = jy + 621
        var leapJ = -14
        var jp = BREAKS[0]

        require(jy >= BREAKS[0] && jy < BREAKS[BREAKS.size - 1]) { "سال شمسی خارج از محدودهٔ پشتیبانی: $jy" }

        var jump = 0
        for (i in 1 until BREAKS.size) {
            val jm = BREAKS[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += (jump / 33) * 8 + (jump % 33) / 4
            jp = jm
        }
        var n = jy - jp
        leapJ += (n / 33) * 8 + (n % 33 + 3) / 4
        if (jump % 33 == 4 && jump - n == 4) leapJ += 1

        val leapG = gy / 4 - ((gy / 100 + 1) * 3) / 4 - 150
        val march = 20 + leapJ - leapG

        if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33
        var leap = ((n + 1) % 33 - 1) % 4
        if (leap == -1) leap = 4

        return JalCal(leap, gy, march)
    }

    /** تاریخ شمسی → شمارهٔ روز ژولیَن */
    private fun j2d(jy: Int, jm: Int, jd: Int): Long {
        val r = jalCal(jy)
        return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - (jm / 7) * (jm - 7) + jd - 1
    }

    /** شمارهٔ روز ژولیَن → تاریخ شمسی */
    private fun d2j(jdn: Long): JalaliDate {
        val gy = d2g(jdn).first
        var jy = gy - 621
        val r = jalCal(jy)
        val jdn1f = g2d(r.gy, 3, r.march)
        var k = jdn - jdn1f

        if (k >= 0) {
            if (k <= 185) {
                return JalaliDate(jy, 1 + (k / 31).toInt(), (k % 31).toInt() + 1)
            }
            k -= 186
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1) k += 1
        }
        return JalaliDate(jy, 7 + (k / 30).toInt(), (k % 30).toInt() + 1)
    }

    /** تاریخ میلادی → شمارهٔ روز ژولیَن */
    private fun g2d(gy: Int, gm: Int, gd: Int): Long {
        var d = ((gy + (gm - 8) / 6 + 100100).toLong() * 1461) / 4 +
                (153L * ((gm + 9) % 12) + 2) / 5 + gd - 34840408L
        d -= ((((gy + 100100 + (gm - 8) / 6) / 100).toLong() * 3) / 4) - 752
        return d
    }

    /** شمارهٔ روز ژولیَن → Triple(سال، ماه، روز) میلادی */
    private fun d2g(jdn: Long): Triple<Int, Int, Int> {
        var j = 4 * jdn + 139361631
        j += (((4 * jdn + 183187720) / 146097) * 3) / 4 * 4 - 3908
        val i = ((j % 1461) / 4) * 5 + 308
        val gd = ((i % 153) / 5) + 1
        val gm = ((i / 153) % 12) + 1
        val gy = (j / 1461) - 100100 + (8 - gm) / 6
        return Triple(gy.toInt(), gm.toInt(), gd.toInt())
    }
}
