package com.ninjatech.oiltrading.data.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * رمزنگاری AES-256-GCM با کلیدی که در **Android Keystore** ساخته و نگهداری می‌شود.
 *
 * کلید هرگز از سخت‌افزار امن خارج نمی‌شود؛ حتی اگر کسی فایل پایگاه داده را از
 * دستگاه بیرون بکشد، فیلدهای حساس بدون همان دستگاه قابل خواندن نیستند.
 *
 * قالب خروجی: `enc1:<Base64 IV>:<Base64 Ciphertext>`
 * برای هر عملیات یک IV تازه ساخته می‌شود (الزام امنیتی GCM).
 */
class AndroidKeystoreEncryptor(
    private val keyAlias: String = DEFAULT_ALIAS
) : FieldEncryptor {

    private val keyStore: KeyStore by lazy {
        KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
    }

    override fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey())

            val iv = cipher.iv
            val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

            FieldEncryptor.PREFIX + iv.toBase64() + SEPARATOR + encrypted.toBase64()
        } catch (e: Exception) {
            // اگر Keystore در دسترس نباشد، نوشتنِ متن ساده بهتر از از دست دادن
            // دادهٔ کاربر است. این حالت در عمل تقریباً رخ نمی‌دهد.
            Log.e(TAG, "رمزنگاری ناموفق بود؛ مقدار بدون رمز ذخیره می‌شود", e)
            plainText
        }
    }

    override fun decrypt(cipherText: String): String {
        if (cipherText.isEmpty()) return ""
        // دادهٔ قدیمیِ پیش از نسخهٔ ۲ رمز نشده است
        if (!FieldEncryptor.isEncrypted(cipherText)) return cipherText

        return try {
            val body = cipherText.removePrefix(FieldEncryptor.PREFIX)
            val separator = body.indexOf(SEPARATOR)
            if (separator <= 0) return FieldEncryptor.FALLBACK

            val iv = body.substring(0, separator).fromBase64()
            val payload = body.substring(separator + 1).fromBase64()

            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(TAG_BITS, iv))
            String(cipher.doFinal(payload), Charsets.UTF_8)
        } catch (e: Exception) {
            // کلید عوض شده (مثلاً بازگردانی پشتیبان روی دستگاه دیگر) —
            // فقط همین فیلد از دست می‌رود، نه کل رکورد.
            Log.w(TAG, "رمزگشایی ناموفق بود", e)
            FieldEncryptor.FALLBACK
        }
    }

    private fun secretKey(): SecretKey {
        (keyStore.getEntry(keyAlias, null) as? KeyStore.SecretKeyEntry)?.let {
            return it.secretKey
        }
        return generateKey()
    }

    private fun generateKey(): SecretKey {
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(KEY_BITS)
                // قفل صفحه لازم نیست: سرویس پس‌زمینهٔ هشدار باید وقتی دستگاه
                // قفل است هم بتواند تاریخ سررسید معاملات را بخواند.
                .setUserAuthenticationRequired(false)
                .build()
        )
        return generator.generateKey()
    }

    private fun ByteArray.toBase64(): String = Base64.encodeToString(this, Base64.NO_WRAP)

    private fun String.fromBase64(): ByteArray = Base64.decode(this, Base64.NO_WRAP)

    private companion object {
        const val TAG = "FieldEncryptor"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val DEFAULT_ALIAS = "oil_trading_field_key"
        const val SEPARATOR = ':'
        const val KEY_BITS = 256
        const val TAG_BITS = 128
    }
}
