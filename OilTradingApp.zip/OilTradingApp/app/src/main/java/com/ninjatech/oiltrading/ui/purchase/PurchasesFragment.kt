package com.ninjatech.oiltrading.ui.purchase

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.PopupMenu
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.ninjatech.oiltrading.OilTradingApplication
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.databinding.FragmentPurchasesBinding
import com.ninjatech.oiltrading.ui.common.FabAnimator
import com.ninjatech.oiltrading.ui.common.TradeFormSheet
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModel
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModelFactory
import com.ninjatech.oiltrading.util.Format

/** فهرست خریدها با امکان ثبت، ویرایش، حذف و جستجو */
class PurchasesFragment : Fragment() {

    private var _binding: FragmentPurchasesBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TradeViewModel by activityViewModels {
        val app = requireActivity().application as OilTradingApplication
        TradeViewModelFactory(app.repository, app.alertRepository, app.prefs)
    }

    private var fabAnimator: FabAnimator? = null
    private var listIsEmpty = true

    private lateinit var adapter: PurchaseAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPurchasesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupList()
        setupSearch()
        setupFab()

        viewModel.purchases.observe(viewLifecycleOwner) { items ->
            adapter.submitList(items)
            renderEmptyState(items.isEmpty())
            renderSummaryBar(items)
        }
    }

    private fun setupList() {
        adapter = PurchaseAdapter(
            currency = { viewModel.currency },
            onMoreClick = ::showItemMenu
        )
        binding.rvPurchases.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@PurchasesFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun setupSearch() {
        binding.etSearch.doAfterTextChanged { text ->
            viewModel.setPurchaseQuery(text?.toString().orEmpty())
        }
    }

    private fun setupFab() {
        val animator = FabAnimator(binding.fabAdd).also { fabAnimator = it }

        animator.playEntrance()
        animator.bindToList(binding.rvPurchases)

        binding.fabAdd.setOnClickListener {
            animator.playPress()
            openTradeForm()
        }
    }

    /** تنها راه باز کردن فرم — هم دکمهٔ شناور و هم دکمهٔ حالت خالی از اینجا می‌گذرند */
    private fun openTradeForm() {
        TradeFormSheet.showNew(parentFragmentManager, TradeFormSheet.Mode.PURCHASE)
    }

    // ---------------------------------------------------------------- نمایش

    /**
     * دو حالتِ خالی که نباید با هم اشتباه شوند:
     *  - **هنوز چیزی ثبت نشده** → دعوت به ثبت اولین معامله
     *  - **جستجو نتیجه نداشت** → کاربر معامله دارد؛ فقط این عبارت مطابقتی ندارد.
     *    اینجا نه پیام «هنوز چیزی ثبت نشده» درست است و نه تپش دکمه.
     */
    private fun renderEmptyState(isEmpty: Boolean) {
        val query = binding.etSearch.text?.toString()?.trim().orEmpty()
        val isSearching = query.isNotEmpty()

        binding.emptyState.root.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvPurchases.visibility = if (isEmpty) View.GONE else View.VISIBLE

        if (isEmpty) {
            if (isSearching) renderNoSearchResults(query) else renderNothingRecorded()
        }

        // تپش فقط برای دفتر واقعاً خالی، و فقط وقتی کاربر این تب را می‌بیند
        listIsEmpty = isEmpty && !isSearching
        fabAnimator?.setAttentionEnabled(listIsEmpty && !isHidden)
    }

    private fun renderNothingRecorded() = with(binding.emptyState) {
        ivEmptyIcon.setImageResource(R.drawable.ic_empty_box)
        tvEmptyTitle.setText(R.string.purchases_empty_title)
        tvEmptyBody.setText(R.string.purchases_empty_body)
        btnEmptyAction.setText(R.string.purchase_new)
        btnEmptyAction.setIconResource(R.drawable.ic_add)
        btnEmptyAction.visibility = View.VISIBLE
        btnEmptyAction.setOnClickListener { openTradeForm() }
    }

    private fun renderNoSearchResults(query: String) = with(binding.emptyState) {
        ivEmptyIcon.setImageResource(R.drawable.ic_search)
        tvEmptyTitle.setText(R.string.search_empty_title)
        tvEmptyBody.text = getString(R.string.search_empty_body, query)
        btnEmptyAction.setText(R.string.search_clear)
        btnEmptyAction.setIconResource(R.drawable.ic_search)
        btnEmptyAction.visibility = View.VISIBLE
        btnEmptyAction.setOnClickListener { binding.etSearch.setText("") }
    }

    private fun renderSummaryBar(items: List<Purchase>) {
        val liter = getString(R.string.unit_liter)
        val count = Format.number(items.size.toDouble(), 0)
        val liters = Format.quantity(items.sumOf { it.quantityLiters }, liter)
        val amount = Format.money(items.sumOf { it.totalPrice }, viewModel.currency)
        binding.tvSummaryBar.text = "$count ${getString(R.string.nav_purchases)} • $liters • $amount"
    }

    // ---------------------------------------------------------------- منوی آیتم

    private fun showItemMenu(purchase: Purchase, anchor: View) {
        PopupMenu(requireContext(), anchor).apply {
            menu.add(0, MENU_EDIT, 0, R.string.edit)
            menu.add(0, MENU_DELETE, 1, R.string.delete)
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    MENU_EDIT -> {
                        openEditForm(purchase)
                        true
                    }
                    MENU_DELETE -> {
                        confirmDelete(purchase)
                        true
                    }
                    else -> false
                }
            }
            show()
        }
    }

    private fun openEditForm(purchase: Purchase) {
        TradeFormSheet.showEdit(
            manager = parentFragmentManager,
            mode = TradeFormSheet.Mode.PURCHASE,
            id = purchase.id,
            name = purchase.sellerName.value,
            assetId = purchase.assetId,
            quantity = purchase.quantity,
            unit = purchase.unit,
            pricePerUnit = purchase.pricePerUnit,
            currency = purchase.currency,
            tradedAt = purchase.tradedAt,
            followUpDate = purchase.followUpDate,
            referenceNo = purchase.referenceNo.value,
            note = purchase.note.value
        )
    }

    private fun confirmDelete(purchase: Purchase) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.delete_purchase_title)
            .setMessage(getString(R.string.delete_purchase_message, purchase.sellerName.value))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ -> viewModel.deletePurchase(purchase) }
            .show()
    }

    /**
     * فرگمنت‌ها با hide/show جابه‌جا می‌شوند، پس جابه‌جایی بین تب‌ها
     * onPause را صدا نمی‌زند؛ توقف انیمیشن باید اینجا انجام شود.
     */
    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        fabAnimator?.onVisibilityChanged(visible = !hidden, listIsEmpty = listIsEmpty)
    }

    /**
     * دروازهٔ «دیده می‌شود یا نه» روی onStart/onStop است، نه onPause/onResume.
     *
     * onPause وقتی هم صدا زده می‌شود که برنامه در حالت چندپنجره‌ای فوکوس را
     * از دست بدهد ولی همچنان روی صفحه باشد؛ با آن، تپش در حالی متوقف می‌شد
     * که کاربر دکمه را می‌دید. STARTED مرز درستِ «روی صفحه بودن» است.
     */
    override fun onStart() {
        super.onStart()
        fabAnimator?.onVisibilityChanged(visible = !isHidden, listIsEmpty = listIsEmpty)
    }

    override fun onStop() {
        super.onStop()
        fabAnimator?.onVisibilityChanged(visible = false, listIsEmpty = listIsEmpty)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        fabAnimator?.release()
        fabAnimator = null
        binding.rvPurchases.adapter = null
        _binding = null
    }

    private companion object {
        const val MENU_EDIT = 1
        const val MENU_DELETE = 2
    }
}
