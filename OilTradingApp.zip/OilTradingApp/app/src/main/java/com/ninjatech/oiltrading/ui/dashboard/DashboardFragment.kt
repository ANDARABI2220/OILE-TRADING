package com.ninjatech.oiltrading.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.ninjatech.oiltrading.OilTradingApplication
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.databinding.FragmentDashboardBinding
import com.ninjatech.oiltrading.domain.TradeSummary
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModel
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModelFactory
import com.ninjatech.oiltrading.util.Format

/** صفحهٔ اول: خلاصهٔ موجودی، مفاد و آخرین معاملات */
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TradeViewModel by activityViewModels {
        val app = requireActivity().application as OilTradingApplication
        TradeViewModelFactory(app.repository, app.alertRepository, app.prefs)
    }

    private lateinit var recentAdapter: RecentAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recentAdapter = RecentAdapter { viewModel.currency }
        binding.rvRecent.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = recentAdapter
            isNestedScrollingEnabled = false
        }

        binding.emptyState.tvEmptyTitle.setText(R.string.dashboard_empty_title)
        binding.emptyState.tvEmptyBody.setText(R.string.dashboard_empty_body)

        observeSummary()
        observeRecentActivity()
    }

    // ---------------------------------------------------------------- خلاصه

    private fun observeSummary() {
        viewModel.summary.observe(viewLifecycleOwner) { summary ->
            renderSummary(summary)
        }
    }

    private fun renderSummary(summary: TradeSummary) = with(binding) {
        val currency = viewModel.currency
        val liter = getString(R.string.unit_liter)
        val ton = getString(R.string.unit_ton)

        // ---- موجودی ----
        tvStockLiters.text = Format.quantity(summary.stockLiters, liter)
        tvStockTons.text = "معادل ${Format.quantity(summary.stockInTons(viewModel.litersPerTon), ton)}"
        tvStockValue.text = Format.money(summary.inventoryValue, currency)
        tvAverageCost.text = "${Format.money(summary.averageCostPerLiter, currency)} / $liter"

        tvCounts.text = getString(
            R.string.dashboard_counts,
            Format.number(summary.purchaseCount.toDouble(), 0),
            Format.number(summary.saleCount.toDouble(), 0)
        )

        // ---- مفاد ----
        val isProfit = summary.totalProfit >= 0
        tvProfitLabel.setText(if (isProfit) R.string.total_profit else R.string.loss)
        tvTotalProfit.text = Format.signed(summary.totalProfit, currency)
        tvMargin.text = "${getString(R.string.profit_margin)} ${Format.percent(summary.marginPercent)}"

        val containerColor = ContextCompat.getColor(
            requireContext(),
            if (isProfit) R.color.profit_container else R.color.loss_container
        )
        val onContainerColor = ContextCompat.getColor(
            requireContext(),
            if (isProfit) R.color.on_profit_container else R.color.on_loss_container
        )
        profitCard.setCardBackgroundColor(containerColor)
        tvProfitLabel.setTextColor(onContainerColor)
        tvTotalProfit.setTextColor(onContainerColor)
        tvMargin.setTextColor(onContainerColor)

        // ---- خرید و فروش ----
        tvTotalPurchasedQty.text = Format.quantity(summary.totalPurchasedLiters, liter)
        tvTotalPurchaseCost.text = Format.money(summary.totalPurchaseCost, currency)
        tvTotalSoldQty.text = Format.quantity(summary.totalSoldLiters, liter)
        tvTotalSaleRevenue.text = Format.money(summary.totalSaleRevenue, currency)

        // ---- هشدار فروش بیش از موجودی ----
        warningCard.visibility = if (summary.hasOversell) View.VISIBLE else View.GONE
    }

    // ---------------------------------------------------------------- آخرین معاملات

    /**
     * خریدها و فروش‌ها را در یک فهرست زمانی ادغام می‌کند و ۵ مورد آخر را نشان می‌دهد.
     */
    private fun observeRecentActivity() {
        viewModel.purchases.observe(viewLifecycleOwner) { rebuildRecent() }
        viewModel.salesWithProfit.observe(viewLifecycleOwner) { rebuildRecent() }
    }

    private fun rebuildRecent() {
        val purchases = viewModel.purchases.value.orEmpty().map {
            RecentEntry(
                id = it.id,
                isPurchase = true,
                name = it.sellerName.value,
                date = it.tradedAt,
                quantity = it.quantity,
                unitLabel = it.oilUnit.label,
                amount = it.totalPrice
            )
        }
        val sales = viewModel.salesWithProfit.value.orEmpty().map {
            RecentEntry(
                id = it.sale.id,
                isPurchase = false,
                name = it.sale.buyerName.value,
                date = it.sale.tradedAt,
                quantity = it.sale.quantity,
                unitLabel = it.sale.oilUnit.label,
                amount = it.sale.totalPrice
            )
        }

        val merged = (purchases + sales)
            .sortedWith(compareByDescending<RecentEntry> { it.date }.thenByDescending { it.id })
            .take(RECENT_LIMIT)

        recentAdapter.submitList(merged)

        val isEmpty = merged.isEmpty()
        binding.emptyState.root.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvRecent.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding.rvRecent.adapter = null
        _binding = null
    }

    private companion object {
        const val RECENT_LIMIT = 5
    }
}
