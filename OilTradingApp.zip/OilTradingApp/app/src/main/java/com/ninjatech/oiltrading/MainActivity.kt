package com.ninjatech.oiltrading

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.ninjatech.oiltrading.databinding.ActivityMainBinding
import com.ninjatech.oiltrading.ui.alerts.AlertsFragment
import com.ninjatech.oiltrading.ui.common.SettingsDialog
import com.ninjatech.oiltrading.ui.dashboard.DashboardFragment
import com.ninjatech.oiltrading.ui.purchase.PurchasesFragment
import com.ninjatech.oiltrading.ui.report.ReportFragment
import com.ninjatech.oiltrading.ui.sale.SalesFragment
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModel
import com.ninjatech.oiltrading.ui.viewmodel.TradeViewModelFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val viewModel: TradeViewModel by viewModels {
        val app = application as OilTradingApplication
        TradeViewModelFactory(app.repository, app.alertRepository, app.prefs)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupBottomNav(savedInstanceState)
        observeMessages()
        observeAlertBadge()

        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** باز کردن صفحهٔ هشدارها وقتی کاربر روی اعلان سیستمی ضربه می‌زند */
    private fun handleIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_OPEN_ALERTS, false) == true) {
            binding.bottomNav.selectedItemId = R.id.nav_alerts
        }
    }

    // ---------------------------------------------------------------- نوار بالا

    private fun setupToolbar() {
        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_settings -> {
                    SettingsDialog.show(supportFragmentManager)
                    true
                }
                else -> false
            }
        }
    }

    // ---------------------------------------------------------------- ناوبری

    /**
     * فرگمنت‌ها به‌جای replace با add/hide مدیریت می‌شوند تا با هر بار جابه‌جایی
     * وضعیت اسکرول و ورودی‌ها از دست نرود.
     */
    private fun setupBottomNav(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.fragmentContainer, DashboardFragment(), TAG_DASHBOARD)
                .commit()

            // پیش از ثبت شنونده انجام می‌شود تا تراکنش تکراری ساخته نشود.
            // در صورت بازسازی اکتیویتی، خودِ BottomNavigationView وضعیتش را برمی‌گرداند.
            binding.bottomNav.selectedItemId = R.id.nav_dashboard
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            val (tag, factory) = when (item.itemId) {
                R.id.nav_dashboard -> TAG_DASHBOARD to { DashboardFragment() }
                R.id.nav_purchases -> TAG_PURCHASES to { PurchasesFragment() }
                R.id.nav_sales -> TAG_SALES to { SalesFragment() }
                R.id.nav_reports -> TAG_REPORTS to { ReportFragment() }
                R.id.nav_alerts -> TAG_ALERTS to { AlertsFragment() }
                else -> return@setOnItemSelectedListener false
            }
            showFragment(tag, factory)
            true
        }
    }

    private fun showFragment(tag: String, create: () -> Fragment) {
        val manager = supportFragmentManager
        val transaction = manager.beginTransaction()

        ALL_TAGS.forEach { otherTag ->
            manager.findFragmentByTag(otherTag)?.let { fragment ->
                if (otherTag != tag) transaction.hide(fragment)
            }
        }

        val target = manager.findFragmentByTag(tag)
        if (target == null) {
            transaction.add(R.id.fragmentContainer, create(), tag)
        } else {
            transaction.show(target)
        }

        transaction.commit()
    }

    // ---------------------------------------------------------------- نشان هشدار

    /** تعداد هشدارهای باز روی آیکون ناوبری نشان داده می‌شود */
    private fun observeAlertBadge() {
        viewModel.activeAlerts.observe(this) { alerts ->
            val badge = binding.bottomNav.getOrCreateBadge(R.id.nav_alerts)
            if (alerts.isEmpty()) {
                badge.isVisible = false
                badge.clearNumber()
            } else {
                badge.isVisible = true
                badge.number = alerts.size
            }
        }
    }

    // ---------------------------------------------------------------- پیام‌ها

    private fun observeMessages() {
        viewModel.message.observe(this) { event ->
            event.getIfNotHandled()?.let { text ->
                Snackbar.make(binding.root, text, Snackbar.LENGTH_SHORT)
                    .setAnchorView(snackbarAnchor())
                    .show()
            }
        }
    }

    /**
     * Snackbar باید *بالای* دکمهٔ شناور بنشیند، نه رویش.
     *
     * دکمه داخل CoordinatorLayout خودِ فرگمنت است و نه این یکی، پس رفتار
     * خودکارِ کنار رفتن عمل نمی‌کند؛ اگر به نوار ناوبری لنگر بیندازیم، پیام
     * دقیقاً روی دکمه می‌افتد — و این پیام معمولاً همان «خرید ثبت شد» است که
     * درست بعد از زدن همان دکمه می‌آید.
     */
    private fun snackbarAnchor(): View {
        val visibleFab = supportFragmentManager.fragments
            .firstOrNull { it.isAdded && !it.isHidden }
            ?.view
            ?.findViewById<View>(R.id.fabAdd)

        return visibleFab ?: binding.bottomNav
    }

    companion object {
        /** کلید Intent برای باز کردن مستقیم صفحهٔ هشدارها از روی اعلان */
        const val EXTRA_OPEN_ALERTS = "open_alerts"

        private const val TAG_DASHBOARD = "dashboard"
        private const val TAG_PURCHASES = "purchases"
        private const val TAG_SALES = "sales"
        private const val TAG_REPORTS = "reports"
        private const val TAG_ALERTS = "alerts"

        private val ALL_TAGS = listOf(
            TAG_DASHBOARD, TAG_PURCHASES, TAG_SALES, TAG_REPORTS, TAG_ALERTS
        )
    }
}
