package com.ninjatech.oiltrading

import android.app.Application
import android.util.Log
import com.ninjatech.oiltrading.alerts.AlertNotifier
import com.ninjatech.oiltrading.alerts.FollowUpWorker
import com.ninjatech.oiltrading.alerts.TradeNotifier
import com.ninjatech.oiltrading.data.db.OilDatabase
import com.ninjatech.oiltrading.data.repo.AlertRepository
import com.ninjatech.oiltrading.data.repo.TradeRepository
import com.ninjatech.oiltrading.util.AppPrefs

/**
 * نقطهٔ ورود اپلیکیشن و ظرف سادهٔ وابستگی‌ها (Service Locator).
 *
 * برای این اندازه از پروژه، نگه‌داشتن وابستگی‌ها در Application ساده‌تر و
 * سبک‌تر از افزودن یک کتابخانهٔ تزریق وابستگی است.
 */
class OilTradingApplication : Application() {

    val prefs: AppPrefs by lazy { AppPrefs(this) }

    private val database: OilDatabase by lazy { OilDatabase.getInstance(this) }

    val repository: TradeRepository by lazy {
        TradeRepository(
            purchaseDao = database.purchaseDao(),
            saleDao = database.saleDao(),
            assetDao = database.assetDao(),
            alertDao = database.alertDao(),
            prefs = prefs
        )
    }

    val alertRepository: AlertRepository by lazy {
        AlertRepository(
            purchaseDao = database.purchaseDao(),
            saleDao = database.saleDao(),
            alertDao = database.alertDao()
        )
    }

    val notifier: AlertNotifier by lazy { TradeNotifier(this) }

    override fun onCreate() {
        super.onCreate()

        // سیستم هشدار بدون هیچ اقدامی از سمت کاربر فعال می‌شود.
        // `schedule` سیاست KEEP دارد، پس فراخوانی مکرر بی‌ضرر است.
        //
        // اگر WorkManager در دسترس نباشد (مثلاً در محیط تست یا وقتی مقداردهی
        // خودکارش غیرفعال شده)، نباید کل برنامه از کار بیفتد؛ هشدارها همچنان
        // هنگام باز کردن صفحهٔ هشدارها از پایگاه داده خوانده می‌شوند.
        runCatching {
            FollowUpWorker.schedule(this)
            FollowUpWorker.runNow(this)
        }.onFailure {
            Log.w(TAG, "زمان‌بندی سرویس هشدار ممکن نشد", it)
        }
    }

    private companion object {
        const val TAG = "OilTradingApp"
    }
}
