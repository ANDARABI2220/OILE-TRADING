package com.ninjatech.oiltrading.domain

import java.util.concurrent.TimeUnit

/** نوع معامله در لایهٔ دامنه — دو جدول جدای پایگاه داده را یکپارچه می‌کند */
enum class TradeType(val dbValue: String) {
    PURCHASE("purchase"),
    SALE("sale");

    companion object {
        fun fromDb(value: String?): TradeType =
            entries.firstOrNull { it.dbValue == value } ?: PURCHASE
    }
}

/**
 * قواعد زمان‌بندی هشدار پیگیری سود و زیان.
 *
 * این شیء عمداً هیچ وابستگی‌ای به اندروید ندارد و زمان را به‌صورت پارامتر
 * می‌گیرد، تا بتوان صد در صد رفتارش را با تست واحد سنجید.
 *
 * **قاعدهٔ اصلی:** به‌محض اینکه تا تاریخ سررسید یک معامله [ALERT_WINDOW_DAYS]
 * روز یا کمتر مانده باشد، باید یک هشدار ساخته شود.
 */
object FollowUpPolicy {

    /** هشدار وقتی این تعداد روز (یا کمتر) تا سررسید مانده باشد */
    const val ALERT_WINDOW_DAYS = 28L

    /**
     * تا این تعداد روز پس از سررسید هم هشدار ساخته می‌شود.
     *
     * چرا لازم است: اگر کاربر چند هفته برنامه را باز نکند یا دستگاه خاموش
     * باشد، سرویس پس‌زمینه اجرا نمی‌شود. بدون این مهلت، آن معامله‌ها برای
     * همیشه هشدار خود را از دست می‌دادند.
     */
    const val OVERDUE_GRACE_DAYS = 90L

    val windowMillis: Long = TimeUnit.DAYS.toMillis(ALERT_WINDOW_DAYS)
    val graceMillis: Long = TimeUnit.DAYS.toMillis(OVERDUE_GRACE_DAYS)

    /**
     * بازهٔ تاریخ‌های سررسیدی که هم‌اکنون باید هشدار بگیرند.
     *
     * کران بالا = «۲۸ روز دیگر»، کران پایین = مهلت معاملات عقب‌افتاده.
     */
    fun alertWindow(now: Long): LongRange = (now - graceMillis)..(now + windowMillis)

    /** آیا این تاریخ سررسید هم‌اکنون مستحق هشدار است؟ */
    fun shouldAlert(dueDate: Long?, now: Long): Boolean =
        dueDate != null && dueDate in alertWindow(now)

    /**
     * چند روز تا سررسید مانده است؟ عدد منفی یعنی از سررسید گذشته.
     * برای گرد کردن رو به بالا استفاده می‌شود تا «۰ روز» فقط روز خودِ سررسید باشد.
     */
    fun daysUntil(dueDate: Long, now: Long): Long {
        val diff = dueDate - now
        return if (diff >= 0) {
            (diff + TimeUnit.DAYS.toMillis(1) - 1) / TimeUnit.DAYS.toMillis(1)
        } else {
            -((-diff + TimeUnit.DAYS.toMillis(1) - 1) / TimeUnit.DAYS.toMillis(1))
        }
    }

    /**
     * تاریخ سررسید پیشنهادی هنگام ثبت معاملهٔ جدید.
     *
     * پیش‌فرض روی [ALERT_WINDOW_DAYS] گذاشته نشده؛ اگر سررسید دقیقاً ۲۸ روز
     * بعد باشد، هشدار همان لحظه فعال می‌شود که بی‌معناست. دو برابرِ پنجره
     * انتخاب شده تا کاربر یک دورهٔ کامل فرصت داشته باشد.
     */
    fun suggestedFollowUpDate(tradedAt: Long): Long =
        tradedAt + TimeUnit.DAYS.toMillis(ALERT_WINDOW_DAYS * 2)
}
