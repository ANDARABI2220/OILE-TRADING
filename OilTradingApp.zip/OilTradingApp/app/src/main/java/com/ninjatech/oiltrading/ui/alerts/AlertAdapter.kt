package com.ninjatech.oiltrading.ui.alerts

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ninjatech.oiltrading.R
import com.ninjatech.oiltrading.data.entity.TradeAlert
import com.ninjatech.oiltrading.data.entity.TradeKind
import com.ninjatech.oiltrading.databinding.ItemAlertBinding
import com.ninjatech.oiltrading.domain.FollowUpPolicy
import com.ninjatech.oiltrading.util.Format
import com.ninjatech.oiltrading.util.JalaliCalendar

/** فهرست یادآوری‌های پیگیری — اعلان درون‌برنامه‌ای */
class AlertAdapter(
    private val now: () -> Long = { System.currentTimeMillis() },
    private val onAcknowledge: (TradeAlert) -> Unit
) : ListAdapter<TradeAlert, AlertAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAlertBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemAlertBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: TradeAlert) = with(binding) {
            val context = root.context

            val kindLabel = context.getString(
                if (item.kind == TradeKind.PURCHASE) R.string.alert_kind_purchase
                else R.string.alert_kind_sale
            )
            tvCounterparty.text = "$kindLabel — ${item.counterparty}"
            tvAmount.text = Format.money(item.amount, item.currency)

            val dueLabel = JalaliCalendar.fromTimestamp(item.dueDate).formatLong()
            tvDueDate.text = "${context.getString(R.string.follow_up_date)}: $dueLabel"

            val days = FollowUpPolicy.daysUntil(item.dueDate, now())
            tvCountdown.text = when {
                days > 0 -> context.getString(
                    R.string.alert_due_in_days,
                    Format.number(days.toDouble(), 0)
                )
                days == 0L -> context.getString(R.string.alert_due_today)
                else -> context.getString(
                    R.string.alert_overdue,
                    Format.number((-days).toDouble(), 0)
                )
            }
            tvCountdown.setBackgroundResource(
                if (days < 0) R.drawable.bg_pill_loss else R.drawable.bg_pill_warning
            )

            btnAcknowledge.setOnClickListener { onAcknowledge(item) }
        }
    }

    private companion object {
        val DIFF = object : DiffUtil.ItemCallback<TradeAlert>() {
            override fun areItemsTheSame(oldItem: TradeAlert, newItem: TradeAlert) =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: TradeAlert, newItem: TradeAlert) =
                oldItem == newItem
        }
    }
}
