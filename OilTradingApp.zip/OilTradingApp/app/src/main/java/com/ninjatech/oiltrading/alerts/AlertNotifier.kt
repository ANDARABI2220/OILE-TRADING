package com.ninjatech.oiltrading.alerts

import com.ninjatech.oiltrading.data.entity.TradeAlert

/**
 * ارسال اعلان یک هشدار.
 *
 * پشت یک واسط قرار گرفته تا سرویس پس‌زمینه بدون نیاز به دستگاه یا شبیه‌ساز
 * قابل تست باشد؛ پیاده‌سازی واقعی [TradeNotifier] است.
 */
interface AlertNotifier {

    /** آیا امکان ارسال اعلان سیستمی وجود دارد؟ */
    fun canPostNotifications(): Boolean

    /**
     * اعلان این هشدار را می‌فرستد.
     *
     * @return true اگر اعلان واقعاً ارسال شد. مقدار false یعنی هشدار در
     * پایگاه داده «ارسال‌نشده» می‌ماند و دفعهٔ بعد دوباره تلاش می‌شود.
     */
    fun notify(alert: TradeAlert, now: Long): Boolean
}
