package com.ninjatech.oiltrading.data.crypto

/**
 * رمزنگاری فیلدهای حساس پیش از نوشتن در پایگاه داده.
 *
 * پیاده‌سازی اصلی [AndroidKeystoreEncryptor] است که کلید را در Android Keystore
 * نگه می‌دارد؛ برای تست‌ها [InMemoryAesEncryptor] استفاده می‌شود چون Keystore
 * روی JVM در دسترس نیست.
 */
interface FieldEncryptor {

    /** متن ساده را به رشتهٔ رمزشدهٔ قابل ذخیره در ستون TEXT تبدیل می‌کند */
    fun encrypt(plainText: String): String

    /**
     * رشتهٔ رمزشده را باز می‌کند.
     *
     * اگر رشته رمز نشده باشد (دادهٔ قدیمیِ پیش از نسخهٔ ۲) همان مقدار برگردانده
     * می‌شود، و اگر رمزگشایی شکست بخورد [FALLBACK] برمی‌گردد تا برنامه به‌جای
     * کرش‌کردن، فقط همان یک فیلد را از دست بدهد.
     */
    fun decrypt(cipherText: String): String

    companion object {
        /** پیشوند نسخه — اجازه می‌دهد بعداً الگوریتم عوض شود بدون شکستن داده‌های قدیمی */
        const val PREFIX = "enc1:"

        /** مقدار جایگزین وقتی رمزگشایی ممکن نیست */
        const val FALLBACK = "—"

        /** آیا این رشته با این طرح رمز شده است؟ */
        fun isEncrypted(value: String): Boolean = value.startsWith(PREFIX)
    }
}

/**
 * رشتهٔ حساسی که در پایگاه داده به‌صورت رمزشده ذخیره می‌شود.
 *
 * عمداً data class است و نه value class: Room برای اعمال TypeConverter باید
 * نوع را یک نوع مستقل ببیند، در حالی که value class در بایت‌کد به String
 * تبدیل می‌شود و مبدل نادیده گرفته می‌شود.
 */
data class Secret(val value: String) {
    override fun toString(): String = value

    companion object {
        val EMPTY = Secret("")
    }
}

fun String.asSecret(): Secret = Secret(this)
