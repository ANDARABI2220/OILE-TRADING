package com.ninjatech.oiltrading.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.ninjatech.oiltrading.data.crypto.Secret

/** واحد اندازه‌گیری تیل */
enum class OilUnit(val dbValue: String, val label: String) {
    TON("ton", "تن"),
    LITER("liter", "لیتر");

    companion object {
        fun fromDb(value: String?): OilUnit = entries.firstOrNull { it.dbValue == value } ?: LITER
        fun fromLabel(label: String?): OilUnit = entries.firstOrNull { it.label == label } ?: LITER
    }
}

/**
 * فیلدهای مشترک میان خرید و فروش.
 *
 * نگهداشتن دو جدول جدا (به‌جای یک جدول با ستون «نوع») عمدی است: اسکیمای موجود
 * برنامه همین است و قواعد کسب‌وکار خرید و فروش هم متفاوت‌اند. نوع معامله در
 * لایهٔ دامنه با `TradeType` یکپارچه می‌شود.
 *
 * **رمزنگاری:** فیلدهای [Secret] (نام طرف حساب، شمارهٔ سند، توضیحات) رمزشده
 * ذخیره می‌شوند. مبالغ، تاریخ‌ها و شناسهٔ کالا عمداً بدون رمز می‌مانند چون
 * پایگاه داده باید بتواند روی آن‌ها مرتب‌سازی، بازه‌گیری و پیوند انجام دهد؛
 * گروه‌بندی و جستجو روی نام‌ها در لایهٔ Kotlin و روی مقادیر رمزگشایی‌شده انجام
 * می‌شود.
 */
interface TradeEntity {
    val id: Long
    val assetId: String
    val quantity: Double
    val unit: String
    val quantityLiters: Double
    val pricePerUnit: Double
    val totalPrice: Double
    val currency: String

    /** زمان دقیق انجام معامله (تاریخ + ساعت) بر حسب میلی‌ثانیه */
    val tradedAt: Long

    /** تاریخ سررسید پیگیری سود و زیان — پایهٔ سیستم هشدار */
    val followUpDate: Long?

    val referenceNo: Secret
    val note: Secret
    val createdAt: Long
    val updatedAt: Long

    val oilUnit: OilUnit get() = OilUnit.fromDb(unit)
}

/** یک معاملهٔ خرید */
@Entity(
    tableName = "purchases",
    foreignKeys = [
        ForeignKey(
            entity = Asset::class,
            parentColumns = ["id"],
            childColumns = ["asset_id"],
            onDelete = ForeignKey.RESTRICT,
            onUpdate = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("purchase_date"),
        Index("asset_id"),
        Index("follow_up_date")
    ]
)
data class Purchase(
    @PrimaryKey(autoGenerate = true)
    override val id: Long = 0,

    /** از کی خریدی؟ — رمزشده ذخیره می‌شود */
    @ColumnInfo(name = "seller_name")
    val sellerName: Secret,

    @ColumnInfo(name = "asset_id")
    override val assetId: String = Asset.DIESEL,

    /** چند خریدی؟ (به واحد انتخاب‌شده) */
    @ColumnInfo(name = "quantity")
    override val quantity: Double,

    @ColumnInfo(name = "unit")
    override val unit: String,

    /** همان مقدار، نرمال‌شده به لیتر */
    @ColumnInfo(name = "quantity_liters")
    override val quantityLiters: Double,

    /** قیمت خرید هر واحد */
    @ColumnInfo(name = "price_per_unit")
    override val pricePerUnit: Double,

    /** مبلغ کل = مقدار × قیمت واحد */
    @ColumnInfo(name = "total_price")
    override val totalPrice: Double,

    @ColumnInfo(name = "currency")
    override val currency: String = DEFAULT_CURRENCY,

    /** تاریخ و ساعت دقیق خرید */
    @ColumnInfo(name = "purchase_date")
    override val tradedAt: Long,

    /** تاریخ سررسید پیگیری سود و زیان این خرید */
    @ColumnInfo(name = "follow_up_date")
    override val followUpDate: Long? = null,

    /** شمارهٔ بارنامه / فاکتور — رمزشده */
    @ColumnInfo(name = "reference_no")
    override val referenceNo: Secret = Secret.EMPTY,

    /** توضیحات اختیاری کاربر — رمزشده */
    @ColumnInfo(name = "note")
    override val note: Secret = Secret.EMPTY,

    @ColumnInfo(name = "created_at")
    override val createdAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "updated_at")
    override val updatedAt: Long = System.currentTimeMillis()
) : TradeEntity {

    companion object {
        const val DEFAULT_CURRENCY = "AFN"
    }
}

/** یک معاملهٔ فروش */
@Entity(
    tableName = "sales",
    foreignKeys = [
        ForeignKey(
            entity = Asset::class,
            parentColumns = ["id"],
            childColumns = ["asset_id"],
            onDelete = ForeignKey.RESTRICT,
            onUpdate = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("sale_date"),
        Index("asset_id"),
        Index("follow_up_date")
    ]
)
data class Sale(
    @PrimaryKey(autoGenerate = true)
    override val id: Long = 0,

    /** به کی فروختی؟ — رمزشده ذخیره می‌شود */
    @ColumnInfo(name = "buyer_name")
    val buyerName: Secret,

    @ColumnInfo(name = "asset_id")
    override val assetId: String = Asset.DIESEL,

    @ColumnInfo(name = "quantity")
    override val quantity: Double,

    @ColumnInfo(name = "unit")
    override val unit: String,

    @ColumnInfo(name = "quantity_liters")
    override val quantityLiters: Double,

    /** قیمت فروش هر واحد */
    @ColumnInfo(name = "price_per_unit")
    override val pricePerUnit: Double,

    @ColumnInfo(name = "total_price")
    override val totalPrice: Double,

    @ColumnInfo(name = "currency")
    override val currency: String = Purchase.DEFAULT_CURRENCY,

    /** تاریخ و ساعت دقیق فروش */
    @ColumnInfo(name = "sale_date")
    override val tradedAt: Long,

    @ColumnInfo(name = "follow_up_date")
    override val followUpDate: Long? = null,

    @ColumnInfo(name = "reference_no")
    override val referenceNo: Secret = Secret.EMPTY,

    @ColumnInfo(name = "note")
    override val note: Secret = Secret.EMPTY,

    @ColumnInfo(name = "created_at")
    override val createdAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "updated_at")
    override val updatedAt: Long = System.currentTimeMillis()
) : TradeEntity
