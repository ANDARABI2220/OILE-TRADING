package com.ninjatech.oiltrading.data.crypto

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * همان الگوریتم [AndroidKeystoreEncryptor] (AES-256-GCM) اما با کلیدی در حافظه.
 *
 * برای تست‌های واحد و یکپارچه روی JVM استفاده می‌شود، جایی که Android Keystore
 * وجود ندارد. رفتار بیرونی‌اش دقیقاً یکسان است تا تست‌ها همان مسیر واقعی را
 * بسنجند.
 *
 * کدگذاری هگز به‌جای Base64 انتخاب شده تا به `android.util.Base64` (فقط اندروید)
 * یا `java.util.Base64` (فقط API 26+) وابسته نباشد.
 */
class InMemoryAesEncryptor(
    private val key: SecretKey = generateKey()
) : FieldEncryptor {

    override fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""

        val iv = ByteArray(IV_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_BITS, iv))
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        return FieldEncryptor.PREFIX + iv.toHex() + SEPARATOR + encrypted.toHex()
    }

    override fun decrypt(cipherText: String): String {
        if (cipherText.isEmpty()) return ""
        if (!FieldEncryptor.isEncrypted(cipherText)) return cipherText

        return try {
            val body = cipherText.removePrefix(FieldEncryptor.PREFIX)
            val separator = body.indexOf(SEPARATOR)
            if (separator <= 0) return FieldEncryptor.FALLBACK

            val iv = body.substring(0, separator).fromHex()
            val payload = body.substring(separator + 1).fromHex()

            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, iv))
            String(cipher.doFinal(payload), Charsets.UTF_8)
        } catch (e: Exception) {
            FieldEncryptor.FALLBACK
        }
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun String.fromHex(): ByteArray =
        ByteArray(length / 2) { substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    companion object {
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val SEPARATOR = ':'
        private const val IV_BYTES = 12
        private const val TAG_BITS = 128
        private const val KEY_BITS = 256

        fun generateKey(): SecretKey =
            KeyGenerator.getInstance("AES").apply { init(KEY_BITS) }.generateKey()
    }
}
