package com.ninjatech.oiltrading.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.ninjatech.oiltrading.data.entity.Purchase
import com.ninjatech.oiltrading.data.entity.Sale
import kotlinx.coroutines.flow.Flow

/**
 * توجه: نام طرف حساب و توضیحات رمزشده ذخیره می‌شوند، بنابراین هیچ پرس‌وجویی
 * روی آن ستون‌ها فیلتر، گروه‌بندی یا مرتب‌سازی نمی‌کند. این کارها در
 * `TradeRepository` و روی مقادیر رمزگشایی‌شده انجام می‌شود.
 */
@Dao
interface PurchaseDao {

    @Insert
    suspend fun insert(purchase: Purchase): Long

    @Update
    suspend fun update(purchase: Purchase)

    @Delete
    suspend fun delete(purchase: Purchase)

    @Query("SELECT * FROM purchases ORDER BY purchase_date DESC, id DESC")
    fun observeAll(): Flow<List<Purchase>>

    /** مرتب‌شده بر اساس زمان — برای محاسبهٔ بهای تمام‌شدهٔ میانگین متحرک */
    @Query("SELECT * FROM purchases ORDER BY purchase_date ASC, id ASC")
    fun observeChronological(): Flow<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE id = :id")
    suspend fun findById(id: Long): Purchase?

    @Query(
        """
        SELECT * FROM purchases
        WHERE purchase_date BETWEEN :from AND :to
        ORDER BY purchase_date DESC, id DESC
        """
    )
    fun observeBetween(from: Long, to: Long): Flow<List<Purchase>>

    /**
     * خریدهایی که تاریخ سررسید پیگیری‌شان در بازهٔ داده‌شده می‌افتد و هنوز
     * هشداری برایشان ثبت نشده است.
     *
     * فیلترِ «هشدار ثبت نشده» داخل خودِ SQL انجام می‌شود تا حتی اگر دو اجرای
     * همزمانِ سرویس پس‌زمینه رخ دهد، کار تکراری انجام نشود.
     */
    @Query(
        """
        SELECT * FROM purchases
        WHERE follow_up_date IS NOT NULL
          AND follow_up_date BETWEEN :from AND :to
          AND id NOT IN (
            SELECT trade_id FROM trade_alerts
            WHERE trade_kind = 'purchase' AND alert_type = :alertType
          )
        ORDER BY follow_up_date ASC
        """
    )
    suspend fun findDueForFollowUp(from: Long, to: Long, alertType: String): List<Purchase>

    @Query("SELECT COUNT(*) FROM purchases")
    suspend fun count(): Int

    @Query("DELETE FROM purchases")
    suspend fun deleteAll()
}

@Dao
interface SaleDao {

    @Insert
    suspend fun insert(sale: Sale): Long

    @Update
    suspend fun update(sale: Sale)

    @Delete
    suspend fun delete(sale: Sale)

    @Query("SELECT * FROM sales ORDER BY sale_date DESC, id DESC")
    fun observeAll(): Flow<List<Sale>>

    @Query("SELECT * FROM sales ORDER BY sale_date ASC, id ASC")
    fun observeChronological(): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun findById(id: Long): Sale?

    @Query(
        """
        SELECT * FROM sales
        WHERE sale_date BETWEEN :from AND :to
        ORDER BY sale_date DESC, id DESC
        """
    )
    fun observeBetween(from: Long, to: Long): Flow<List<Sale>>

    @Query(
        """
        SELECT * FROM sales
        WHERE follow_up_date IS NOT NULL
          AND follow_up_date BETWEEN :from AND :to
          AND id NOT IN (
            SELECT trade_id FROM trade_alerts
            WHERE trade_kind = 'sale' AND alert_type = :alertType
          )
        ORDER BY follow_up_date ASC
        """
    )
    suspend fun findDueForFollowUp(from: Long, to: Long, alertType: String): List<Sale>

    @Query("SELECT COUNT(*) FROM sales")
    suspend fun count(): Int

    @Query("DELETE FROM sales")
    suspend fun deleteAll()
}
