plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
    id("jacoco")
}

android {
    namespace = "com.ninjatech.oiltrading"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ninjatech.oiltrading"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // زبان‌های پشتیبانی‌شده (دری/فارسی + انگلیسی)
        resourceConfigurations += setOf("fa", "en")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isMinifyEnabled = false
            enableUnitTestCoverage = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    testOptions {
        unitTests {
            // لازم برای Robolectric — تست‌های یکپارچه به منابع اپلیکیشن دسترسی دارند
            isIncludeAndroidResources = true
            isReturnDefaultValues = true
        }
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

// خروجی گرفتن اسکیمای Room — برای تست مهاجرت پایگاه داده لازم است
kapt {
    arguments {
        arg("room.schemaLocation", "$projectDir/schemas")
        arg("room.incremental", "true")
    }
}

dependencies {
    // --- AndroidX پایه ---
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // --- Material Design 3 ---
    implementation("com.google.android.material:material:1.12.0")

    // --- Lifecycle / ViewModel / LiveData (MVVM) ---
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")

    // --- Room (پایگاه داده آفلاین) ---
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    // --- WorkManager (سرویس پس‌زمینهٔ سیستم هشدار) ---
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // --- Coroutines ---
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // --- تست واحد ---
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    testImplementation("androidx.arch.core:core-testing:2.2.0")

    // --- تست یکپارچه روی JVM (Robolectric) ---
    testImplementation("org.robolectric:robolectric:4.12.2")
    testImplementation("androidx.test:core-ktx:1.6.1")
    testImplementation("androidx.test.ext:junit-ktx:1.2.1")
    testImplementation("androidx.room:room-testing:2.6.1")
    testImplementation("androidx.work:work-testing:2.9.1")

    // --- تست روی دستگاه ---
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.room:room-testing:2.6.1")
    androidTestImplementation("androidx.work:work-testing:2.9.1")
}

// ---------------------------------------------------------------- گزارش پوشش تست

jacoco {
    toolVersion = "0.8.12"
}

/*
 * تست‌های Robolectric کلاس‌ها را در یک ClassLoader جداگانه بارگذاری می‌کنند و
 * JaCoCo به‌صورت پیش‌فرض آن‌ها را «بدون محل» می‌شمارد و نادیده می‌گیرد — نتیجه
 * این می‌شود که پوشش واقعی صفر گزارش شود. این دو تنظیم مشکل را حل می‌کنند.
 */
tasks.withType<Test>().configureEach {
    extensions.configure(JacocoTaskExtension::class) {
        isIncludeNoLocationClasses = true
        excludes = listOf("jdk.internal.*")
    }
}

tasks.register<JacocoReport>("jacocoTestReport") {
    dependsOn("testDebugUnitTest")
    group = "verification"
    description = "گزارش پوشش تست واحد برای ماژول معاملات و سیستم هشدار"

    reports {
        xml.required.set(true)
        html.required.set(true)
    }

    // کلاس‌هایی که پوشش تست برایشان معنا ندارد
    val excludes = listOf(
        "**/R.class", "**/R$*.class", "**/BuildConfig.*", "**/Manifest*.*",
        "**/*Test*.*", "android/**/*.*",
        "**/databinding/**", "**/*_Impl*.*",
        // لایهٔ نمایش با تست ابزاری پوشش داده می‌شود، نه تست واحد
        "**/ui/**", "**/*Activity*.*", "**/*Fragment*.*",
        "**/*Adapter*.*", "**/*Dialog*.*", "**/*Sheet*.*",
        // این‌ها به APIهای واقعی اندروید نیاز دارند (Keystore سخت‌افزاری،
        // NotificationManager سیستمی) و در تست ابزاری روی دستگاه سنجیده می‌شوند
        "**/AndroidKeystoreEncryptor*.*",
        "**/OilTradingApplication*.*"
    )

    classDirectories.setFrom(
        files(
            fileTree(layout.buildDirectory.dir("tmp/kotlin-classes/debug")) { exclude(excludes) },
            fileTree(layout.buildDirectory.dir("intermediates/javac/debug/classes")) { exclude(excludes) }
        )
    )
    sourceDirectories.setFrom(files("$projectDir/src/main/java"))
    executionData.setFrom(fileTree(layout.buildDirectory) { include("**/*.exec", "**/*.ec") })
}
